# V4 contracts

Sanitized frozen contracts for the fixed-budget, threshold, score-semantics, MMP-oracle, and pharmacophore analyses. Excluded inputs remain external reconstruction gates.
