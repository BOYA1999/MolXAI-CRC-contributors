import ast
import csv
import gzip
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TEXT_SUFFIXES = {"", ".md", ".txt", ".py", ".json", ".csv", ".toml", ".cff", ".yaml", ".yml", ".gitignore"}
FORBIDDEN_SUFFIXES = {
    ".7z", ".aux", ".bbl", ".bib", ".bin", ".bmp", ".ckpt", ".doc", ".docx",
    ".eps", ".feather", ".gif", ".h5", ".hdf5", ".inchi", ".jpeg", ".jpg",
    ".log", ".mol", ".mol2", ".npy", ".npz", ".onnx", ".parquet", ".pdf",
    ".pickle", ".pkl", ".png", ".ppt", ".pptx", ".pt", ".pth", ".rar", ".rtf",
    ".sdf", ".smi", ".svg", ".tex", ".tif", ".tiff", ".xlsx",
}
FORBIDDEN_DIRS = {
    ".git", ".ipynb_checkpoints", ".pytest_cache", "__pycache__", "cache", "checkpoints",
    "failed", "fig", "figure", "figures", "images", "lightning_logs", "log", "logs",
    "manuscript", "model_0", "paper", "raw", "source_repositories", "sources", "weights", "private_diagnostics",
}
TOP_LEVEL = {
    ".gitignore", "configs", "contracts", "data", "DATA_SOURCES.md", "ENVIRONMENT.md",
    "LICENSE", "MANIFEST_SHA256.txt", "README.md", "REPRODUCIBILITY.md", "requirements.txt",
    "results", "scripts", "SECURITY_AND_PRIVACY.md", "src", "THIRD_PARTY_NOTICES.md",
}
MOLECULAR_FIELDS = {"canonical_smiles", "inchi", "inchikey", "isomeric_smiles", "molblock", "smiles", "source_smiles", "structure_smiles"}
FORBIDDEN_RESULT_BASENAMES = {"attributions.json", "molecule_results_no_structures.csv", "predictions_no_structures.csv", "splits.json"}
ROW_IDENTIFIERS = {"mol_id", "molecule_id", "pair_id", "source_index", "test_index", "id", "source_row_index", "selection_rank", "scaffold"}


def sha256(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def text_of(path):
    if path.suffix.lower() == ".gz":
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
            return handle.read()
    return path.read_text(encoding="utf-8", errors="replace")


def json_keys(value):
    if isinstance(value, dict):
        for key, item in value.items():
            yield str(key).lower()
            yield from json_keys(item)
    elif isinstance(value, list):
        for item in value:
            yield from json_keys(item)


failures = []
files = sorted(path for path in ROOT.rglob("*") if path.is_file())
if {path.name for path in ROOT.iterdir()} != TOP_LEVEL:
    failures.append("top-level allowlist mismatch")

privacy_patterns = {
    "Windows absolute path": re.compile(r"(?<![A-Za-z0-9])[A-Za-z]:[\\/]"),
    "UNC path": re.compile(r"(?:^|[\"'])\\\\{2,}[A-Za-z0-9_.-]+\\"),
    "home directory": re.compile(r"/(?:home|Users)/[^/\s]+/", re.IGNORECASE),
    "email address": re.compile(r"(?<![A-Za-z0-9_.+-])[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}(?![A-Za-z0-9_.-])"),
    "private key": re.compile("BEGIN " + "PRIVATE KEY"),
    "GitHub token": re.compile("gh" + r"[pousr]_[A-Za-z0-9]{20,}"),
    "AWS access key": re.compile("AKIA" + r"[A-Z0-9]{16}"),
    "OpenAI key": re.compile("sk" + r"-[A-Za-z0-9_-]{20,}"),
}
private_terms = [
    "BOYA" + "1999",
    "XAI" + "_Boundary",
    "revision_next" + "_journal",
    "0804" + "JCC",
    "reviewer_" + "revision_20260904",
    "AD" + "MIN",
    "J" + "C2",
    "J" + "C3",
]

for path in files:
    relative = path.relative_to(ROOT)
    lower_parts = {part.lower() for part in relative.parts}
    if path.suffix.lower() in FORBIDDEN_SUFFIXES:
        failures.append(f"forbidden suffix: {relative.as_posix()}")
    if "results" in lower_parts and path.name.lower() in FORBIDDEN_RESULT_BASENAMES:
        failures.append(f"molecule- or prediction-level result: {relative.as_posix()}")
    if lower_parts & FORBIDDEN_DIRS:
        failures.append(f"forbidden directory: {relative.as_posix()}")
    if path.suffix.lower() in TEXT_SUFFIXES or path.name == ".gitignore" or path.suffix.lower() == ".gz":
        text = text_of(path)
        for label, pattern in privacy_patterns.items():
            if pattern.search(text):
                failures.append(f"{label}: {relative.as_posix()}")
        lowered = text.lower()
        for term in private_terms:
            if term.lower() in lowered:
                failures.append(f"private identifier: {relative.as_posix()}")
    if path.suffix.lower() == ".py":
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=relative.as_posix())
        except SyntaxError as error:
            failures.append(f"Python syntax: {relative.as_posix()}: {error}")

for base in [ROOT / "data", ROOT / "results"]:
    for path in sorted(base.rglob("*.csv")) + sorted(base.rglob("*.csv.gz")):
        try:
            first = text_of(path).splitlines()[0]
            fields = {field.strip().lower() for field in next(csv.reader([first]))}
        except Exception as error:
            failures.append(f"tabular parse: {path.relative_to(ROOT).as_posix()}: {error}")
            continue
        leaked = fields & MOLECULAR_FIELDS
        if leaked:
            failures.append(f"structure-bearing fields {sorted(leaked)}: {path.relative_to(ROOT).as_posix()}")
        row_level = fields & ROW_IDENTIFIERS
        if row_level:
            failures.append(f"row-level identifiers {sorted(row_level)}: {path.relative_to(ROOT).as_posix()}")
    for path in sorted(base.rglob("*.json")):
        try:
            keys = set(json_keys(json.loads(path.read_text(encoding="utf-8"))))
        except Exception as error:
            failures.append(f"JSON parse: {path.relative_to(ROOT).as_posix()}: {error}")
            continue
        leaked = keys & MOLECULAR_FIELDS
        if leaked:
            failures.append(f"structure-bearing JSON keys {sorted(leaked)}: {path.relative_to(ROOT).as_posix()}")
        row_level = keys & ROW_IDENTIFIERS
        if row_level:
            failures.append(f"row-level JSON keys {sorted(row_level)}: {path.relative_to(ROOT).as_posix()}")

required = [
    "scripts/a_level/a1_repeated_redraw.py", "scripts/a_level/a2_mask_audit.py",
    "scripts/a_level/a3_subset_representativeness.py", "scripts/a_level/a4_gine.py",
    "scripts/a_level/a5_target_null.py", "scripts/a_level/a6_permutation_symmetry.py",
    "scripts/a_level/a7_moleculeace_mmp/build_mmp_pairs.py",
    "scripts/a_level/a7_moleculeace_mmp/train_gine.py",
    "scripts/a_level/a7_moleculeace_mmp/attribute_and_crc.py",
    "scripts/a_level/a7_moleculeace_mmp/validate_a7.py",
    "scripts/a_level/a7_moleculeace_mmp/reference/prepare_data.py",
    "scripts/a_level/a7_moleculeace_mmp/reference/prepare_splits.py",
    "results/a_level/a7_moleculeace_mmp/DATA_LICENSE.md",
]
for name in ["a1_repeated_redraw", "a2_mask_audit", "a3_subset_representativeness", "a4_gine", "a5_target_null", "a6_permutation_symmetry", "a7_moleculeace_mmp"]:
    required.extend([f"contracts/a_level/{name}/run_contract.json", f"results/a_level/{name}/summary.json", f"results/a_level/{name}/validation.json"])
required.extend([
    "scripts/v4/analyze_frozen_outputs.py",
    "scripts/v4/validate_frozen_outputs.py",
    "scripts/v4/score_semantics/run_score_semantics.py",
    "scripts/v4/score_semantics/validate_score_semantics.py",
    "scripts/v4/pharmacophore/run_pharmacophore_benchmark.py",
    "scripts/v4/pharmacophore/validate_pharmacophore_benchmark.py",
    "scripts/v4/pharmacophore/UPSTREAM_LICENSE_ADAMSULEK_PHARMACO_EXPLAINER.txt",
    "contracts/v4/analysis_contract.json",
    "contracts/v4/run_contract.json",
    "contracts/v4/score_semantics/run_contract.json",
    "contracts/v4/pharmacophore/run_contract.json",
    "contracts/v4/pharmacophore/metric_contract.json",
    "results/v4/summary.json",
    "results/v4/validation.json",
    "results/v4/fixed_budget/cell_results.csv",
    "results/v4/fixed_budget/method_summary.csv",
    "results/v4/gate_sensitivity/threshold_sensitivity.csv",
    "results/v4/mmp_oracle/cell_decomposition.csv",
    "results/v4/mmp_oracle/target_method_decomposition.csv",
    "results/v4/score_semantics/summary.json",
    "results/v4/score_semantics/validation.json",
    "results/v4/pharmacophore/evaluation_summary.json",
    "results/v4/pharmacophore/validation.json",
    "results/v4/pharmacophore/aggregate_summary.csv",
    "results/v4/pharmacophore/DATA_LICENSE.md",
])
for relative in required:
    if not (ROOT / relative).is_file():
        failures.append(f"missing required surface: {relative}")

license_text = (ROOT / "LICENSE").read_text(encoding="utf-8")
readme = (ROOT / "README.md").read_text(encoding="utf-8")
a7_license = (ROOT / "results/a_level/a7_moleculeace_mmp/DATA_LICENSE.md").read_text(encoding="utf-8")
pharmacophore_license = (ROOT / "results/v4/pharmacophore/DATA_LICENSE.md").read_text(encoding="utf-8")
pharmacophore_upstream_license = (ROOT / "scripts/v4/pharmacophore/UPSTREAM_LICENSE_ADAMSULEK_PHARMACO_EXPLAINER.txt").read_text(encoding="utf-8")
if "MIT License" not in license_text or "repository-authored code and documentation" not in readme:
    failures.append("root MIT scope is not explicit")
if "CC BY-SA 3.0" not in a7_license or "ChEMBL v29" not in a7_license or "not covered by the repository root MIT License" not in a7_license:
    failures.append("A7 data-derived license separation failed")
if "CC BY 4.0" not in pharmacophore_license or "K4_2ar" not in pharmacophore_license or "must not be relabeled as repository-authored MIT data" not in pharmacophore_license:
    failures.append("pharmacophore data-derived license separation failed")
if "MIT License" not in pharmacophore_upstream_license or "Copyright (c) 2025 AdamSulek" not in pharmacophore_upstream_license:
    failures.append("pharmacophore upstream code notice is incomplete")

established = ROOT / "results/established_explainers"
with (established / "cells.csv").open(encoding="utf-8", newline="") as handle:
    rows = list(csv.DictReader(handle))
if len(rows) != 330 or len({row["cell_id"] for row in rows}) != 66 or len({(row["family"], row["task"]) for row in rows}) != 11:
    failures.append("established-explainer invariant failed")

polaris = ROOT / "results/polaris_hclint"
for group in ["ecfp_rf", "chemeleon_seed42", "chemeleon_seed123", "chemeleon_seed2026", "chemeleon_ensemble"]:
    metrics_path = polaris / group / "polaris_metrics.json"
    if not metrics_path.is_file():
        failures.append(f"missing Polaris aggregate metrics: {group}")
    else:
        try:
            json.loads(metrics_path.read_text(encoding="utf-8"))
        except Exception as error:
            failures.append(f"invalid Polaris aggregate metrics {group}: {error}")
metadata = json.loads((ROOT / "data/polaris_hclint_metadata.json").read_text(encoding="utf-8"))
if metadata.get("n_train") != 2229 or metadata.get("n_test") != 575 or metadata.get("test_targets_accessed") is not False:
    failures.append("Polaris metadata boundary failed")
attribution_summary = json.loads((polaris / "attribution_compatibility/summary.json").read_text(encoding="utf-8"))
if attribution_summary.get("n_molecules") != 100 or attribution_summary.get("test_targets_accessed") is not False:
    failures.append("Polaris attribution aggregate boundary failed")

a7 = ROOT / "results/a_level/a7_moleculeace_mmp"
a7_summary = json.loads((a7 / "summary.json").read_text(encoding="utf-8"))
if a7_summary.get("status") != "DESCRIPTIVE_CLUSTERED_STRESS_TEST" or a7_summary.get("attribution_rows") != 9012 or a7_summary.get("crc_result_rows") != 9576:
    failures.append("A7 descriptive summary invariant failed")
if a7_summary.get("predictive_performance", {}).get("n_targets") != 11:
    failures.append("A7 target-macro invariant failed")
with (a7 / "model_metrics_no_paths.csv").open(encoding="utf-8", newline="") as handle:
    model_rows = list(csv.DictReader(handle))
if len(model_rows) != 33 or len({row["dataset"] for row in model_rows}) != 11 or {int(row["seed"]) for row in model_rows} != {17, 29, 43}:
    failures.append("A7 11-target x 3-seed model invariant failed")
with (a7 / "target_panel_eligibility.csv").open(encoding="utf-8", newline="") as handle:
    eligibility = list(csv.DictReader(handle))
selected = {row["dataset"] for row in eligibility if row["selected_for_a7"].lower() == "true"}
if len(eligibility) != 30 or len(selected) != 11:
    failures.append("A7 11-of-15 eligibility invariant failed")

v4 = ROOT / "results/v4"
v4_summary = json.loads((v4 / "summary.json").read_text(encoding="utf-8"))
v4_validation = json.loads((v4 / "validation.json").read_text(encoding="utf-8"))
if v4_summary.get("status") != "complete_validated" or v4_validation.get("status") != "PASS":
    failures.append("V4 consolidated validation status failed")
with (v4 / "fixed_budget/cell_results.csv").open(encoding="utf-8", newline="") as handle:
    v4_cells = list(csv.DictReader(handle))
if len(v4_cells) != 1386 or {row["surface"] for row in v4_cells} != {"primary_full_grid", "retrospective_matched_subset"}:
    failures.append("V4 fixed-budget cell invariant failed")
with (v4 / "fixed_budget/method_summary.csv").open(encoding="utf-8", newline="") as handle:
    v4_methods = list(csv.DictReader(handle))
if len(v4_methods) != 21:
    failures.append("V4 fixed-budget method-summary invariant failed")
with (v4 / "gate_sensitivity/threshold_sensitivity.csv").open(encoding="utf-8", newline="") as handle:
    v4_thresholds = list(csv.DictReader(handle))
if len(v4_thresholds) != 55 or {round(float(row["threshold"]), 2) for row in v4_thresholds} != {0.5, 0.6, 0.7, 0.8, 0.9}:
    failures.append("V4 threshold-sensitivity invariant failed")
if (v4 / "mmp_oracle/pair_proxy_fractions.csv").exists():
    failures.append("V4 pair-level MMP table must not be released")
with (v4 / "mmp_oracle/cell_decomposition.csv").open(encoding="utf-8", newline="") as handle:
    v4_mmp_cells = list(csv.DictReader(handle))
with (v4 / "mmp_oracle/target_method_decomposition.csv").open(encoding="utf-8", newline="") as handle:
    v4_mmp_targets = list(csv.DictReader(handle))
if len(v4_mmp_cells) != 66 or len(v4_mmp_targets) != 22 or len({row["dataset"] for row in v4_mmp_targets}) != 11:
    failures.append("V4 MMP oracle aggregate invariant failed")
score_summary = json.loads((v4 / "score_semantics/summary.json").read_text(encoding="utf-8"))
score_validation = json.loads((v4 / "score_semantics/validation.json").read_text(encoding="utf-8"))
if score_summary.get("status") != "complete_validated" or score_validation.get("status") != "PASS":
    failures.append("V4 score-semantics validation status failed")
pharmacophore_summary = json.loads((v4 / "pharmacophore/evaluation_summary.json").read_text(encoding="utf-8"))
pharmacophore_validation = json.loads((v4 / "pharmacophore/validation.json").read_text(encoding="utf-8"))
predictor = pharmacophore_summary.get("experimental_results", {}).get("predictor", {})
gradcam = pharmacophore_summary.get("experimental_results", {}).get("signed_gradcam", {})
if pharmacophore_summary.get("status") != "trusted_with_caveats" or pharmacophore_validation.get("status") != "TRUSTED_WITH_CAVEATS":
    failures.append("V4 pharmacophore validation status failed")
if abs(predictor.get("standard_continuous_probability_roc_auc", 0) - 0.9556273796737302) > 1e-12 or abs(gradcam.get("test_risk", 0) - 0.08885152110450824) > 1e-12:
    failures.append("V4 pharmacophore frozen aggregate invariant failed")

manifest = ROOT / "MANIFEST_SHA256.txt"
v5_expected = {'slice_prediction_summary.json', 'population_comparison.json', 'population_numeric_summary.csv',
               'conditional_method_summary.csv', 'equal_size_random_summary.csv', 'within_molecule_auc_summary.csv',
               'validation.json', 'independent_formula_validation.json', 'evaluation_summary.json', 'DATA_LICENSE.md'}
v5 = ROOT / 'results/v5/pharmacophore'
if not v5.is_dir() or {p.name for p in v5.iterdir()} != v5_expected:
    failures.append('V5 strict aggregate allowlist mismatch')
for relative in ['scripts/v5/pharmacophore/run_robustness.py', 'scripts/v5/pharmacophore/validate_robustness.py',
                 'scripts/v5/pharmacophore/verify_public_aggregates.py', 'scripts/v5/pharmacophore/prepare_external_run.py',
                 'scripts/v5/pharmacophore/bind_reconstructed_inputs.py', 'contracts/v5/pharmacophore/run_contract.json']:
    if not (ROOT / relative).is_file():
        failures.append('V5 missing surface: ' + relative)
if v5.is_dir() and 'CC BY 4.0' not in (v5 / 'DATA_LICENSE.md').read_text(encoding='utf-8'):
    failures.append('V5 pharmacophore license boundary failed')
v5_check = subprocess.run([sys.executable, '-B', str(ROOT / 'scripts/v5/pharmacophore/verify_public_aggregates.py')], capture_output=True, text=True)
if v5_check.returncode:
    failures.append('V5 aggregate verification failed: ' + v5_check.stdout + v5_check.stderr)
if not manifest.exists():
    failures.append("missing MANIFEST_SHA256.txt")
else:
    listed = {}
    for line in manifest.read_text(encoding="utf-8").splitlines():
        try:
            expected, relative = line.split("  ", 1)
        except ValueError:
            failures.append("malformed manifest line")
            continue
        target = (ROOT / relative).resolve()
        if ROOT not in target.parents or relative in listed:
            failures.append(f"unsafe or duplicate manifest path: {relative}")
            continue
        listed[relative] = expected
        if not target.is_file() or sha256(target) != expected:
            failures.append(f"manifest mismatch: {relative}")
    actual = {path.relative_to(ROOT).as_posix() for path in files if path != manifest}
    if set(listed) != actual:
        failures.append("manifest file list is incomplete or stale")

if failures:
    raise SystemExit("FAIL\n" + "\n".join(failures))
print(f"PASS: {len(files)} files; syntax, privacy, denylist, data boundary, licenses, evidence invariants, and manifest")
