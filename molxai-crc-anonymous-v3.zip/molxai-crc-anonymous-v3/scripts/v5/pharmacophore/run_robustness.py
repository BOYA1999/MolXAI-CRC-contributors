import argparse
import hashlib
import json
import math
import platform
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import scipy
from rdkit import Chem, RDLogger, rdBase
from rdkit.Chem.Scaffolds import MurckoScaffold
from scipy.stats import hypergeom, ks_2samp, rankdata

PACKAGE = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser(description='Recompute the fixed pharmacophore robustness audit from external V4 inputs.')
parser.add_argument('--source-dir', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, required=True)
parser.add_argument('--contract', type=Path, default=PACKAGE / 'contracts/v5/pharmacophore/run_contract.json')
args = parser.parse_args()
HERE = args.output_dir.resolve()
PARENT = args.source_dir.resolve()
if HERE == PACKAGE or PACKAGE in HERE.parents or HERE == PARENT or PARENT in HERE.parents:
    parser.error('The output directory must be outside the release and source directories.')
OUT = HERE / 'outputs'
PRIVATE = HERE / 'private_diagnostics'
CONTRACT = json.loads(args.contract.read_text(encoding='utf-8'))
REPEATS = CONTRACT['C1c']['random_repeats_per_molecule']
RDLogger.DisableLog('rdApp.*')


def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')


def distribution(values):
    a = np.asarray(values, dtype=float)
    q = np.quantile(a, [0, .025, .25, .5, .75, .975, 1])
    return dict(n=int(len(a)), mean=float(a.mean()), sd=float(a.std(ddof=1)), **dict(zip(['min', 'q025', 'q25', 'median', 'q75', 'q975', 'max'], map(float, q))))


def auc(truth, scores):
    ranks = rankdata(scores, method='average')
    r = int(truth.sum())
    return float((ranks[truth.astype(bool)].sum() - r * (r + 1) / 2) / (r * (len(truth) - r)))


def bootstrap(values, seed):
    a = np.asarray(values, dtype=float)
    rng = np.random.default_rng(seed)
    sampled = a[rng.integers(0, len(a), (5000, len(a)))]
    return {'mean_interval': list(map(float, np.quantile(sampled.mean(axis=1), [.025, .975]))), 'median_interval': list(map(float, np.quantile(np.median(sampled, axis=1), [.025, .975])))}


def main():
    started = time.time()
    HERE.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(exist_ok=True)
    PRIVATE.mkdir(exist_ok=True)
    source_hashes = {name: digest(PARENT / name) for name in CONTRACT['source_inputs']}
    assert source_hashes == CONTRACT['source_inputs'], 'source hash mismatch'
    test = pd.read_parquet(PARENT / 'outputs/attributions.parquet').query("split == 'test'").sort_values('selection_rank').reset_index(drop=True)
    frozen = pd.read_parquet(PARENT / 'outputs/selected_slice.parquet').query("split == 'test'").sort_values('selection_rank').reset_index(drop=True)
    assert len(test) == len(frozen) == 512 and test.ID.is_unique and test.ID.equals(frozen.ID)
    original = pd.read_parquet(PARENT / 'outputs/test_set_metrics.parquet')
    pred = pd.read_parquet(PARENT / 'outputs/predictor_predictions.parquet').sort_values('source_row_index')
    pred_unique = pred.drop_duplicates('ID').set_index('ID')
    assert len(pred) == 354570
    p_delta = test.probability.to_numpy() - pred_unique.loc[test.ID, 'probability'].to_numpy()
    assert np.max(np.abs(p_delta)) <= 1e-5
    correct = test.probability.to_numpy() >= .5
    assert np.array_equal(correct, pred_unique.loc[test.ID, 'probability'].to_numpy() >= .5)
    slices = {'all_test_positives': np.ones(len(test), dtype=bool), 'correctly_predicted_test_positives': correct}
    prediction = {'n': 512, 'threshold': .5, 'correctly_predicted_positives': int(correct.sum()), 'false_negatives': int((~correct).sum()), 'positive_recall': float(correct.mean()), 'probability_distribution': distribution(test.probability), 'target': 'positive-class pre-sigmoid logit for every molecule, irrespective of predicted class', 'molecule_ROC_AUC': None, 'molecule_ROC_AUC_reason': 'single class slice; ROC-AUC undefined', 'max_abs_probability_difference_from_official_test_cache': float(np.max(np.abs(p_delta))), 'hard_label_disagreements_between_caches': 0}
    save(OUT / 'slice_prediction_summary.json', prediction)
    print('Source hashes and fixed 512-molecule prediction join passed.', flush=True)

    labels = pq.read_table(PARENT / 'inputs/k4_2ar_labels.parquet', columns=['ID', 'smiles', 'y', 'y_true']).to_pandas()
    split = pq.read_table(PARENT / 'inputs/k4_2ar_split.parquet', columns=['ID', 'y', 'split'], filters=[('split', '=', 'test')]).to_pandas()
    assert len(split) == len(pred)
    counts = split.groupby('ID').size()
    test_ids = set(split.ID)
    available = labels.loc[labels.ID.isin(test_ids)]
    assert available.ID.is_unique and set(available.y) == {1}
    label_map = available.set_index('ID')
    assert all(np.array_equal(row.y_true, label_map.loc[row.ID, 'y_true']) for row in test.itertuples(index=False))
    rows, rejected = [], []
    for row in available.itertuples(index=False):
        mol = Chem.MolFromSmiles(row.smiles)
        truth = np.asarray(row.y_true)
        reason = 'invalid_smiles' if mol is None else 'atom_count_mismatch' if len(truth) != mol.GetNumAtoms() else 'constant_or_nonbinary_reference' if set(truth.tolist()) != {0, 1} else None
        if reason:
            rejected.append({'ID': row.ID, 'reason': reason})
            continue
        scaffold_mol = Chem.Mol(mol)
        Chem.RemoveStereochemistry(scaffold_mol)
        scaffold = MurckoScaffold.MurckoScaffoldSmiles(mol=scaffold_mol, includeChirality=False)
        n, r = len(truth), int(truth.sum())
        rows.append({'ID': row.ID, 'n_atoms': n, 'reference_atoms': r, 'reference_fraction': r / n, 'probability': float(pred_unique.loc[row.ID, 'probability']), 'source_row_count': int(counts[row.ID]), 'source_duplicate_id': int(counts[row.ID] > 1), 'scaffold': scaffold})
    pool = pd.DataFrame(rows).sort_values('ID').reset_index(drop=True)
    pool['selected'] = pool.ID.isin(test.ID)
    selected = pool.loc[pool.selected].copy()
    assert len(selected) == 512
    pool.to_parquet(PRIVATE / 'eligible_unique_test_positive_population.parquet', index=False)
    pd.DataFrame(rejected, columns=['ID', 'reason']).to_csv(PRIVATE / 'ineligible_test_positive_ids.csv', index=False)
    all_counts = pool.scaffold.value_counts()
    top10 = set(sorted(all_counts.index, key=lambda s: (-all_counts[s], s))[:10])
    pool['top10_scaffold'] = pool.scaffold.isin(top10).astype(int)
    selected = pool.loc[pool.selected]
    columns = ['n_atoms', 'reference_atoms', 'reference_fraction', 'probability', 'source_row_count', 'source_duplicate_id', 'top10_scaffold']
    population_summary = []
    rng = np.random.default_rng(CONTRACT['seeds']['finite_pool_reference'])
    draws = np.array([rng.choice(len(pool), 512, replace=False) for _ in range(2000)])
    for col in columns:
        full, sub = pool[col].to_numpy(float), selected[col].to_numpy(float)
        random_means = full[draws].mean(axis=1)
        row = {'feature': col, 'full_eligible': distribution(full), 'selected_512': distribution(sub), 'selected_minus_full_mean': float(sub.mean() - full.mean()), 'standardized_difference_using_full_sd': float((sub.mean() - full.mean()) / full.std(ddof=1)) if full.std(ddof=1) else 0., 'descriptive_KS_statistic': float(ks_2samp(sub, full).statistic), 'finite_pool_512_sample_mean_interval': list(map(float, np.quantile(random_means, [.025, .975]))), 'selected_mean_percentile_in_finite_pool_reference': float(np.mean(random_means <= sub.mean()))}
        population_summary.append(row)
    scaffold_codes = pd.factorize(pool.scaffold)[0]
    richness = np.array([len(np.unique(scaffold_codes[d])) for d in draws])
    sub_scaffolds = set(selected.scaffold)
    full_scaffold_proportions = all_counts / len(pool)
    selected_scaffold_proportions = selected.scaffold.value_counts().reindex(all_counts.index, fill_value=0) / 512
    scaffold_summary = {'full_unique_scaffolds': int(len(all_counts)), 'selected_unique_scaffolds': int(selected.scaffold.nunique()), 'finite_pool_512_scaffold_richness_interval': list(map(float, np.quantile(richness, [.025, .975]))), 'selected_richness_percentile': float(np.mean(richness <= selected.scaffold.nunique())), 'fraction_of_full_pool_molecules_with_scaffold_represented_in_selected_slice': float(pool.scaffold.isin(sub_scaffolds).mean()), 'selected_full_scaffold_total_variation': float(.5 * np.abs(full_scaffold_proportions - selected_scaffold_proportions).sum()), 'full_empty_scaffold_count': int((pool.scaffold == '').sum()), 'selected_empty_scaffold_count': int((selected.scaffold == '').sum()), 'interpretation': 'scaffold coverage and categorical distance are descriptive; a small finite slice cannot establish scaffold-general representativeness'}
    population = {'available_unique_reference_positive_test_ids': int(len(available)), 'eligible_unique_positive_test_ids': int(len(pool)), 'ineligible_count': int(len(rejected)), 'selected_count': 512, 'eligible_positive_source_rows': int(pool.source_row_count.sum()), 'eligible_source_duplicate_rows_after_first': int((pool.source_row_count - 1).sum()), 'selected_source_rows': int(selected.source_row_count.sum()), 'selected_source_duplicate_rows_after_first': int((selected.source_row_count - 1).sum()), 'numeric_distributions': population_summary, 'scaffolds': scaffold_summary, 'finite_pool_reference_note': '2000 uniform without-replacement samples of 512; uncertainty describes selection from this finite pool only'}
    save(OUT / 'population_comparison.json', population)
    pd.DataFrame([{'feature': r['feature'], 'full_n': r['full_eligible']['n'], 'selected_n': 512, 'full_mean': r['full_eligible']['mean'], 'selected_mean': r['selected_512']['mean'], 'full_sd': r['full_eligible']['sd'], 'selected_sd': r['selected_512']['sd'], 'full_median': r['full_eligible']['median'], 'selected_median': r['selected_512']['median'], 'standardized_difference': r['standardized_difference_using_full_sd'], 'KS': r['descriptive_KS_statistic'], 'finite_pool_mean_q025': r['finite_pool_512_sample_mean_interval'][0], 'finite_pool_mean_q975': r['finite_pool_512_sample_mean_interval'][1]} for r in population_summary]).to_csv(OUT / 'population_numeric_summary.csv', index=False)
    print(f'Eligible population comparison finished: {len(pool)} unique test positives.', flush=True)

    method_rows, random_rows = [], []
    risk_draws = np.zeros((512, REPEATS))
    iou_draws = np.zeros_like(risk_draws)
    replay_errors = []
    for i, row in enumerate(test.itertuples(index=False)):
        truth = np.asarray(row.y_true, dtype=int)
        n, r = len(truth), int(truth.sum())
        frozen_rows = original.loc[original.ID == row.ID].set_index('method')
        observed = frozen_rows.loc['gradcam']
        k = int(observed.selected_atoms)
        seed = int.from_bytes(hashlib.sha256(f'molxai-crc-v5-equal-size-20260905|{row.ID}'.encode()).digest()[:8], 'little')
        local_rng = np.random.default_rng(seed)
        hits = np.array([truth[local_rng.permutation(n)[:k]].sum() for _ in range(REPEATS)], dtype=int)
        risk_draws[i] = 1 - hits / r
        iou_draws[i] = hits / (r + k - hits)
        observed_hits = int(round((1 - observed.risk) * r))
        xs = np.arange(max(0, r + k - n), min(r, k) + 1)
        probs = hypergeom.pmf(xs, n, r, k)
        expected_iou = float(np.sum(probs * xs / (r + k - xs)))
        random_rows.append({'ID': row.ID, 'correct_positive': bool(correct[i]), 'n_atoms': n, 'reference_atoms': r, 'selected_atoms': k, 'observed_hits': observed_hits, 'analytic_expected_recall': k / n, 'analytic_expected_risk': 1 - k / n, 'analytic_expected_iou': expected_iou, 'random_risk_mean': float(risk_draws[i].mean()), 'random_risk_q025': float(np.quantile(risk_draws[i], .025)), 'random_risk_q975': float(np.quantile(risk_draws[i], .975)), 'random_iou_mean': float(iou_draws[i].mean()), 'random_iou_q025': float(np.quantile(iou_draws[i], .025)), 'random_iou_q975': float(np.quantile(iou_draws[i], .975)), 'gradcam_win_rate_over_random_draws': float((observed_hits > hits).mean()), 'gradcam_tie_rate_over_random_draws': float((observed_hits == hits).mean()), 'analytic_win_probability': float(hypergeom.cdf(observed_hits - 1, n, r, k)), 'analytic_tie_probability': float(hypergeom.pmf(observed_hits, n, r, k))})
        frozen_random = np.array([int.from_bytes(hashlib.sha256(f'{row.ID}|{j}|molxai-crc-k4_2ar-v1|random'.encode()).digest()[:8], 'big') / 2**64 for j in range(n)])
        scores = {'gradcam': np.asarray(row.gradcam), 'vanilla_gradient': np.asarray(row.vanilla_gradient), 'random': frozen_random, 'oracle': truth.astype(float)}
        for method, score in scores.items():
            values = frozen_rows.loc[method]
            fraction = float(values.nominal_fraction)
            nominal_k = min(n, max(0, int(math.ceil(fraction * n))))
            keep = score >= np.sort(score)[n - nominal_k] if nominal_k else np.zeros(n, dtype=bool)
            intersection = int(truth[keep].sum())
            checks = [int(keep.sum()) - int(values.selected_atoms), 1 - intersection / r - values.risk, intersection / (r + keep.sum() - intersection) - values.iou, auc(truth, score) - values.ph_score]
            replay_errors.extend(map(abs, checks))
            method_rows.append({'ID': row.ID, 'method': method, 'correct_positive': bool(correct[i]), 'risk': float(values.risk), 'retained_fraction': float(values.retained_fraction), 'iou': float(values.iou), 'ph_score': auc(truth, score), 'nominal_fraction': fraction})
    assert max(replay_errors) < 1e-12, max(replay_errors)
    random_frame = pd.DataFrame(random_rows)
    method_frame = pd.DataFrame(method_rows)
    test[['ID', 'probability']].assign(correct_positive=correct).to_parquet(PRIVATE / 'slice_prediction_diagnostics.parquet', index=False)
    method_frame.to_parquet(PRIVATE / 'method_molecule_metrics.parquet', index=False)
    random_frame.to_parquet(PRIVATE / 'random_molecule_diagnostics.parquet', index=False)
    np.savez_compressed(PRIVATE / 'random_equal_size_draws.npz', risk=risk_draws, iou=iou_draws)
    random_summary, method_summary, auc_summary = [], [], []
    for slice_name, mask in slices.items():
        ids = test.loc[mask, 'ID']
        observed = method_frame.loc[(method_frame.method == 'gradcam') & method_frame.ID.isin(ids)].set_index('ID').loc[ids]
        rr = random_frame.loc[mask]
        rd, jd = risk_draws[mask].mean(axis=0), iou_draws[mask].mean(axis=0)
        risk_delta = observed.risk.to_numpy() - rr.analytic_expected_risk.to_numpy()
        iou_delta = observed.iou.to_numpy() - rr.analytic_expected_iou.to_numpy()
        macro_mc_se = float(rd.std(ddof=1) / np.sqrt(REPEATS))
        assert abs(rd.mean() - rr.analytic_expected_risk.mean()) < max(6 * macro_mc_se, 1e-4)
        random_summary.append({'slice': slice_name, 'n': int(mask.sum()), 'repeats_per_molecule': REPEATS, 'gradcam_risk': float(observed.risk.mean()), 'gradcam_iou': float(observed.iou.mean()), 'retained_fraction': float(observed.retained_fraction.mean()), 'random_risk_mean': float(rd.mean()), 'random_risk_randomization_q025': float(np.quantile(rd, .025)), 'random_risk_randomization_q975': float(np.quantile(rd, .975)), 'random_iou_mean': float(jd.mean()), 'random_iou_randomization_q025': float(np.quantile(jd, .025)), 'random_iou_randomization_q975': float(np.quantile(jd, .975)), 'analytic_random_expected_risk': float(rr.analytic_expected_risk.mean()), 'analytic_random_expected_recall': float(1 - rr.analytic_expected_risk.mean()), 'analytic_random_expected_iou': float(rr.analytic_expected_iou.mean()), 'gradcam_mean_molecule_win_rate': float(rr.gradcam_win_rate_over_random_draws.mean()), 'gradcam_mean_molecule_tie_rate': float(rr.gradcam_tie_rate_over_random_draws.mean()), 'analytic_mean_molecule_win_rate': float(rr.analytic_win_probability.mean()), 'analytic_mean_molecule_tie_rate': float(rr.analytic_tie_probability.mean()), 'molecule_fraction_risk_better_than_exact_random_expectation': float((risk_delta < -1e-12).mean()), 'molecule_fraction_risk_tied_with_exact_random_expectation': float((np.abs(risk_delta) <= 1e-12).mean()), 'gradcam_minus_analytic_random_risk': float(risk_delta.mean()), 'risk_difference_bootstrap_q025': bootstrap(risk_delta, 20260905)['mean_interval'][0], 'risk_difference_bootstrap_q975': bootstrap(risk_delta, 20260905)['mean_interval'][1], 'gradcam_minus_analytic_random_iou': float(iou_delta.mean()), 'iou_difference_bootstrap_q025': bootstrap(iou_delta, 20260905)['mean_interval'][0], 'iou_difference_bootstrap_q975': bootstrap(iou_delta, 20260905)['mean_interval'][1], 'random_risk_macro_mean_MC_SE': macro_mc_se})
        for method in ['gradcam', 'vanilla_gradient', 'random', 'oracle']:
            mf = method_frame.loc[(method_frame.method == method) & method_frame.ID.isin(ids)]
            method_summary.append({'slice': slice_name, 'method': method, 'n': len(mf), **{key: float(mf[key].mean()) for key in ['risk', 'retained_fraction', 'iou', 'ph_score', 'nominal_fraction']}})
            vals = mf.ph_score.to_numpy()
            boot = bootstrap(vals, 20260905)
            auc_summary.append({'slice': slice_name, 'method': method, **distribution(vals), 'mean_bootstrap_q025': boot['mean_interval'][0], 'mean_bootstrap_q975': boot['mean_interval'][1], 'median_bootstrap_q025': boot['median_interval'][0], 'median_bootstrap_q975': boot['median_interval'][1], 'fraction_below_0_5': float((vals < .5 - 1e-12).mean()), 'fraction_equal_0_5': float((np.abs(vals - .5) <= 1e-12).mean()), 'fraction_above_0_5': float((vals > .5 + 1e-12).mean())})
    pd.DataFrame(random_summary).to_csv(OUT / 'equal_size_random_summary.csv', index=False)
    pd.DataFrame(method_summary).to_csv(OUT / 'conditional_method_summary.csv', index=False)
    pd.DataFrame(auc_summary).to_csv(OUT / 'within_molecule_auc_summary.csv', index=False)
    source_hashes_after = {name: digest(PARENT / name) for name in CONTRACT['source_inputs']}
    assert source_hashes_after == source_hashes
    validation = {'status': 'PASS', 'source_hashes_unchanged': True, 'n_source_hashes': len(source_hashes), 'test_ids_reconstructed_exactly': True, 'population_eligibility_complete': len(pool) + len(rejected) == len(available), 'calibration_and_policies_unchanged': True, 'max_abs_independent_metric_replay_error': float(max(replay_errors)), 'all_equal_size_draw_counts_exact_by_construction': True, 'simulated_risk_matches_hypergeometric_expectation': True, 'elapsed_seconds': float(time.time() - started)}
    save(OUT / 'validation.json', validation)
    result = {'status': 'complete_pending_independent_QA', 'reviewer_items': CONTRACT['reviewer_items'], 'prediction': prediction, 'population': population, 'randomization': random_summary, 'conditional_methods': method_summary, 'auc_distributions': auc_summary, 'evaluation_summary': 'Cached scores and frozen policies replay exactly; correctly predicted subset, finite-pool representativeness and repeated equal-size controls now quantified.', 'claim_update': 'Interpret measured random contrasts with conditional subset and finite-pool boundaries; no new class-conditional CRC or scaffold-general claim.', 'baseline_relation': 'V4 unchanged; this is a cached follow-up audit', 'failure_mode': 'reported in numerical comparisons without post hoc tuning', 'next_action': 'independent validation then bounded Word/TeX/SI writeback', 'environment': {'python': sys.version, 'platform': platform.platform(), 'numpy': np.__version__, 'pandas': pd.__version__, 'scipy': scipy.__version__, 'rdkit': rdBase.rdkitVersion, 'compute': 'CPU cached analysis; no training or inference'}, 'validation': validation}
    save(OUT / 'evaluation_summary.json', result)
    manifest = {str(p.relative_to(HERE)).replace('\\', '/'): digest(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name != 'MANIFEST.json'}
    save(HERE / 'MANIFEST.json', manifest)
    print(json.dumps({'prediction': prediction, 'randomization': random_summary, 'validation': validation}, indent=2), flush=True)


if __name__ == '__main__':
    main()
