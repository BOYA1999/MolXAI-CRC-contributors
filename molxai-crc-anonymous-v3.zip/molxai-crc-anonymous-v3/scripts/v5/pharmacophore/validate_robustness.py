import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

PACKAGE = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser(description='Independently validate external V5 random draws and analytic summaries.')
parser.add_argument('--source-dir', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, required=True)
parser.add_argument('--contract', type=Path, default=PACKAGE / 'contracts/v5/pharmacophore/run_contract.json')
args = parser.parse_args()
ROOT = args.output_dir.resolve()
PARENT = args.source_dir.resolve()
if ROOT == PACKAGE or PACKAGE in ROOT.parents or ROOT == PARENT or PARENT in ROOT.parents:
    parser.error('The output directory must be outside the release and source directories.')
CONTRACT = json.loads(args.contract.read_text(encoding='utf-8'))
CHECKS = []


def check(name, condition):
    CHECKS.append({'check': name, 'pass': bool(condition)})
    assert condition, name


for name, expected in CONTRACT['source_inputs'].items():
    with (PARENT / name).open('rb') as stream:
        check('source_hash:' + name, hashlib.file_digest(stream, 'sha256').hexdigest() == expected)
test = pd.read_parquet(PARENT / 'outputs/attributions.parquet').query("split == 'test'").sort_values('selection_rank')
rd = pd.read_parquet(ROOT / 'private_diagnostics/random_molecule_diagnostics.parquet').set_index('ID')
md = pd.read_parquet(ROOT / 'private_diagnostics/method_molecule_metrics.parquet')
with np.load(ROOT / 'private_diagnostics/random_equal_size_draws.npz') as archive:
    draws = {key: archive[key] for key in ['risk', 'iou']}
summary = pd.read_csv(ROOT / 'outputs/equal_size_random_summary.csv')
pool = pd.read_parquet(ROOT / 'private_diagnostics/eligible_unique_test_positive_population.parquet')
check('fixed_test_count_512_unique', len(test) == 512 and test.ID.is_unique)
check('correct_positives_472', int((test.probability >= .5).sum()) == 472)
check('eligible_pool_24069_unique_and_512_selected', len(pool) == 24069 and pool.ID.is_unique and pool.selected.sum() == 512)
check('random_draw_shapes', draws['risk'].shape == draws['iou'].shape == (512, 1000))
auc_errors, random_errors, analytic_errors = [], [], []
for index, row in enumerate(test.itertuples(index=False)):
    truth = np.asarray(row.y_true, dtype=bool)
    n, r, k = len(truth), int(truth.sum()), int(rd.loc[row.ID, 'selected_atoms'])
    for method in ['gradcam', 'vanilla_gradient']:
        score = np.asarray(getattr(row, method))
        comparisons = score[truth][:, None] - score[~truth][None, :]
        area = ((comparisons > 0).sum() + .5 * (comparisons == 0).sum()) / comparisons.size
        reported = md.loc[(md.ID == row.ID) & (md.method == method), 'ph_score'].iloc[0]
        auc_errors.append(abs(area - reported))
    possible_hits = range(max(0, k - n + r), min(k, r) + 1)
    denominator = math.comb(n, k)
    masses = [(x, math.comb(r, x) * math.comb(n - r, k - x) / denominator) for x in possible_hits]
    expected_iou = sum(x / (r + k - x) * mass for x, mass in masses)
    expected_risk = sum((1 - x / r) * mass for x, mass in masses)
    analytic_errors.extend([abs(expected_iou - rd.loc[row.ID, 'analytic_expected_iou']), abs(expected_risk - rd.loc[row.ID, 'analytic_expected_risk'])])
    seed = int.from_bytes(hashlib.sha256(f'molxai-crc-v5-equal-size-20260905|{row.ID}'.encode()).digest()[:8], 'little')
    rng = np.random.Generator(np.random.PCG64(seed))
    for repeat in range(1000):
        selection = rng.permutation(np.arange(n))[:k]
        assert len(np.unique(selection)) == k
        hit = int(np.count_nonzero(truth[selection]))
        random_errors.extend([abs(draws['risk'][index, repeat] - (1 - hit / r)), abs(draws['iou'][index, repeat] - hit / (r + k - hit))])
check('pairwise_AUC_reproduction', max(auc_errors) < 1e-12)
check('combinatorial_hypergeometric_reproduction', max(analytic_errors) < 1e-12)
check('all_512000_random_draws_exact_replay_and_unique_counts', max(random_errors) == 0)
for slice_name, mask in [('all_test_positives', np.ones(512, dtype=bool)), ('correctly_predicted_test_positives', test.probability.to_numpy() >= .5)]:
    reported = summary.loc[summary.slice == slice_name].iloc[0]
    for metric in ['risk', 'iou']:
        means = draws[metric][mask].mean(axis=0)
        check(slice_name + ':' + metric + ':random_mean', abs(means.mean() - reported['random_' + metric + '_mean']) < 1e-12)
        for name, q in [('q025', .025), ('q975', .975)]:
            check(slice_name + ':' + metric + ':' + name, abs(np.quantile(means, q) - reported['random_' + metric + '_randomization_' + name]) < 1e-12)
result = {'status': 'PASS', 'checks': CHECKS, 'max_pairwise_AUC_error': max(auc_errors), 'max_combinatorial_expectation_error': max(analytic_errors), 'random_draw_replay_max_error': max(random_errors), 'qualification': 'Independent evaluator/formulas and deterministic replay; not independent human or agent scientific review'}
(ROOT / 'outputs/independent_formula_validation.json').write_text(json.dumps(result, indent=2, allow_nan=False), encoding='utf-8')
print(json.dumps({'status': 'PASS', 'n_checks': len(CHECKS), 'max_pairwise_AUC_error': max(auc_errors), 'max_combinatorial_expectation_error': max(analytic_errors)}))
