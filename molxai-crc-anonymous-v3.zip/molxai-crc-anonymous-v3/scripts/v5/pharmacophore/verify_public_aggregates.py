import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser(description='Verify released V5 aggregate identities; optionally compare an external rerun.')
parser.add_argument('--recomputed-dir', type=Path)
args = parser.parse_args()
base = ROOT / 'results/v5/pharmacophore'
prediction = json.loads((base / 'slice_prediction_summary.json').read_text())
population = json.loads((base / 'population_comparison.json').read_text())
validation = json.loads((base / 'validation.json').read_text())
summary = json.loads((base / 'evaluation_summary.json').read_text())
methods = pd.read_csv(base / 'conditional_method_summary.csv')
random = pd.read_csv(base / 'equal_size_random_summary.csv')
auc = pd.read_csv(base / 'within_molecule_auc_summary.csv')
features = pd.read_csv(base / 'population_numeric_summary.csv')
assert validation['status'] == 'PASS' and validation['n_source_hashes'] == 11
assert validation['max_abs_independent_metric_replay_error'] < 1e-12
assert prediction['n'] == 512 and prediction['correctly_predicted_positives'] == 472
assert prediction['correctly_predicted_positives'] + prediction['false_negatives'] == 512
assert prediction['positive_recall'] == 472 / 512
assert prediction['molecule_ROC_AUC'] is None
assert population['eligible_unique_positive_test_ids'] == 24069 and population['selected_count'] == 512
assert population['available_unique_reference_positive_test_ids'] == population['eligible_unique_positive_test_ids'] + population['ineligible_count']
assert len(methods) == len(auc) == 8 and len(random) == 2 and len(features) == 7
assert methods.groupby('slice').method.nunique().eq(4).all()
assert set(methods.method) == {'gradcam', 'vanilla_gradient', 'random', 'oracle'}
for frame, key in [(methods, 'conditional_methods'), (random, 'randomization'), (auc, 'auc_distributions')]:
    expected = pd.DataFrame(summary[key])[frame.columns]
    for col in frame:
        if pd.api.types.is_numeric_dtype(frame[col]):
            assert np.allclose(frame[col], expected[col], rtol=0, atol=1e-12), (key, col)
        else:
            assert frame[col].tolist() == expected[col].tolist(), (key, col)
for row in random.itertuples():
    assert row.n == (512 if row.slice == 'all_test_positives' else 472)
    assert row.repeats_per_molecule == 1000
    assert abs(row.analytic_random_expected_risk - (1-row.retained_fraction)) < 1e-12
    assert abs(row.analytic_random_expected_recall - row.retained_fraction) < 1e-12
    assert abs(row.gradcam_minus_analytic_random_risk - (row.gradcam_risk-row.analytic_random_expected_risk)) < 1e-12
    assert abs(row.gradcam_minus_analytic_random_iou - (row.gradcam_iou-row.analytic_random_expected_iou)) < 1e-12
    assert abs(row.random_risk_mean-row.analytic_random_expected_risk) < max(6*row.random_risk_macro_mean_MC_SE, 1e-4)
    assert row.random_risk_randomization_q025 <= row.random_risk_mean <= row.random_risk_randomization_q975
    assert row.random_iou_randomization_q025 <= row.random_iou_mean <= row.random_iou_randomization_q975
    assert row.gradcam_mean_molecule_win_rate + row.gradcam_mean_molecule_tie_rate <= 1
assert np.allclose(auc.fraction_below_0_5 + auc.fraction_equal_0_5 + auc.fraction_above_0_5, 1, atol=1e-12)
prior = pd.read_csv(ROOT / 'results/v4/pharmacophore/explanation_summary.csv').set_index('method')
for row in methods[methods.slice.eq('all_test_positives')].itertuples():
    for actual, previous in [('risk', 'test_risk'), ('retained_fraction', 'mean_retained_fraction'), ('iou', 'mean_iou'), ('ph_score', 'mean_ph_score')]:
        assert abs(getattr(row, actual) - prior.loc[row.method, previous]) < 1e-12
if args.recomputed_dir:
    for name in ['conditional_method_summary.csv', 'equal_size_random_summary.csv',
                 'within_molecule_auc_summary.csv', 'population_numeric_summary.csv']:
        recorded = pd.read_csv(base / name)
        rerun = pd.read_csv(args.recomputed_dir / name)
        assert recorded.shape == rerun.shape and recorded.columns.equals(rerun.columns)
        for column in recorded:
            if pd.api.types.is_numeric_dtype(recorded[column]):
                assert np.allclose(recorded[column], rerun[column], rtol=0, atol=1e-10), (name, column)
            else:
                assert recorded[column].equals(rerun[column]), (name, column)
print('PASS: V5 denominators, source linkage, cross-format consistency, analytic random identities, intervals, and V4 unchanged-slice agreement' + ('; external rerun agrees within 1e-10' if args.recomputed_dir else ''))
