# Pharmacophore robustness reconstruction

V5 reuses the fixed K4_2ar Close checkpoint, 512 positive validation molecules, 512 positive test molecules, and already calibrated policies from V4. No new training, calibration, score transformation, slice selection, or inference is performed by the V5 runner. It computes positive-class competence, the nested 472 correctly predicted positives, finite-pool distribution/scaffold summaries, 1,000 equal-size random draws per molecule, exact hypergeometric expectations, and descriptive bootstrap summaries.

## Public source inputs

Obtain the three resources by filename from the [fixed Pharmaco-Explainer dataset revision](https://huggingface.co/datasets/klimczakjakubdev/pharmaco-explainer/tree/fb38e88acd4b486a4ba9df74dccfa701e05d01b1). Put the downloaded binary files in a separate input directory. Their filenames and exact SHA-256 values are in `contracts/v4/pharmacophore/run_contract.json` and enforced by `prepare_external_run.py`.

- `k4_2ar_split.parquet`
- `k4_2ar_labels.parquet`
- `best_model_gcn_split_close_set.pth`

The published V4 generator reconstructs graphs directly from the upstream tables and supplies the model architecture and positive-logit attribution implementation. No unavailable upstream graph pickle is required. Its SHA-256 is exactly the frozen experimental generator hash. Public code provenance is fixed at `AdamSulek/pharmaco-explainer@f40599677e52574b86d8e7ccc6dc842471519cbd`; the upstream MIT notice remains alongside the V4 adapter. The data/checkpoint release declares CC BY 4.0; no binary inputs are redistributed here.

## Stage and regenerate V4 inputs

Use a new working directory outside this release; `INPUTS` below is the separately downloaded input directory. The staging helper verifies all three input hashes before copying them and the released code/contracts. It performs no training or inference.

```bash
python scripts/v5/pharmacophore/prepare_external_run.py --work-dir ../pharma-rerun --input-dir ../INPUTS
python ../pharma-rerun/v4/run_pharmacophore_benchmark.py --stage all --predictor-batch-size 512 --attribution-batch-size 32 --attribution-device cpu
```

The predictor stage uses the existing checkpoint. Its implementation can use an available GPU for full-test predictions; explanations use single-thread deterministic CPU settings as specified above. Numerical environment versions are in `requirements.txt` and `ENVIRONMENT.md`; `pyarrow==17.0.0` is included because the route reads and writes Parquet.

V4's published validation includes a two-process explanation replay. Copy the first run's six files named in `verify_reproducibility.py` from the external `v4/outputs/` directory into external `v4/diagnostics/repro_run1/`, then execute:

```bash
python ../pharma-rerun/v4/run_pharmacophore_benchmark.py --stage explanations --attribution-batch-size 32 --attribution-device cpu
python ../pharma-rerun/v4/verify_reproducibility.py
python ../pharma-rerun/v4/diagnose_predictor_metric.py
python ../pharma-rerun/v4/validate_pharmacophore_benchmark.py
```

Only proceed if the replay reports `PASS_EXACT` and the independent validator reports `TRUSTED_WITH_CAVEATS`. The adverse localization result and source-evaluation caveats remain part of the record.

## Run V5

When regenerated file bytes match the frozen hashes, use the released contract directly:

```bash
python scripts/v5/pharmacophore/run_robustness.py --source-dir ../pharma-rerun/v4 --output-dir ../pharma-rerun/v5
python scripts/v5/pharmacophore/validate_robustness.py --source-dir ../pharma-rerun/v4 --output-dir ../pharma-rerun/v5
python scripts/v5/pharmacophore/verify_public_aggregates.py --recomputed-dir ../pharma-rerun/v5/outputs
```

The released V4 contract was sanitized for public distribution, so its hash differs from the historical local contract. `contracts/v5/pharmacophore/run_contract.json` records both hashes and binds the public one. The score-generator source and the three upstream input hashes are unchanged. The V5 runner only adds explicit source/output/contract interfaces; its statistical calculations are unchanged.

Parquet bytes or floating-point calculations may differ under a different environment. A hash mismatch is a real gate: do not silently remove it. After the full V4 independent validation above, the following optional step binds a separately validated new materialization while retaining every historical hash:

```bash
python scripts/v5/pharmacophore/bind_reconstructed_inputs.py --source-dir ../pharma-rerun/v4 --output-contract ../pharma-rerun/v5_reconstruction_contract.json
python scripts/v5/pharmacophore/run_robustness.py --source-dir ../pharma-rerun/v4 --output-dir ../pharma-rerun/v5 --contract ../pharma-rerun/v5_reconstruction_contract.json
python scripts/v5/pharmacophore/validate_robustness.py --source-dir ../pharma-rerun/v4 --output-dir ../pharma-rerun/v5 --contract ../pharma-rerun/v5_reconstruction_contract.json
python scripts/v5/pharmacophore/verify_public_aggregates.py --recomputed-dir ../pharma-rerun/v5/outputs
```

This step requires unchanged upstream binaries and generator, a passing V4 validator, and V4 numerical summary agreement within 1e-10. It does not certify historical per-molecule score byte identity. Any subsequent aggregate mismatch must be reported; it must not be relabeled a reproduction.

## Release boundary

The release contains only four aggregate CSVs, summary JSONs, and validation records. Regenerated IDs, structures, atom scores, probabilities, scaffolds, and individual random diagnostics remain in the external working directory and must not be added to the release. V5's interval meanings are explicit in the frozen contract: randomization intervals hold molecules fixed; bootstrap intervals resample the single observed slice; finite-pool reference intervals describe selection from the eligible pool. None establishes a new-population, scaffold-general, or conditional CRC guarantee.
