import argparse
import hashlib
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser(description='Stage unchanged released V4 code and verified upstream inputs outside this package.')
parser.add_argument('--work-dir', required=True, type=Path)
parser.add_argument('--input-dir', required=True, type=Path)
args = parser.parse_args()
work = args.work_dir.resolve()
if work.exists() or work == ROOT or ROOT in work.parents:
    parser.error('Use a new, nonexistent working directory outside this package.')
expected = {
    'k4_2ar_split.parquet': '42e27f2ef90e36c636018a300984f1fca09889951483236dba1f17c8dce06db7',
    'k4_2ar_labels.parquet': '2b8e6cb4bfdaa8c180695d6df405c8dde8c3c25cdeda52481fb03f0ad45114cb',
    'best_model_gcn_split_close_set.pth': '1548a2942559b3c4705f95b510cc3dba30d23107e7f8d4ef1a76c04ad23b9c4b'}
for name, digest in expected.items():
    with (args.input_dir / name).open('rb') as handle:
        assert hashlib.file_digest(handle, 'sha256').hexdigest() == digest, name
v4 = work / 'v4'
(v4 / 'inputs').mkdir(parents=True)
for name in expected:
    shutil.copy2(args.input_dir / name, v4 / 'inputs' / name)
for name in ['run_pharmacophore_benchmark.py', 'validate_pharmacophore_benchmark.py',
             'diagnose_predictor_metric.py', 'verify_reproducibility.py']:
    shutil.copy2(ROOT / 'scripts/v4/pharmacophore' / name, v4 / name)
for name in ['run_contract.json', 'contract_amendment_001.json']:
    shutil.copy2(ROOT / 'contracts/v4/pharmacophore' / name, v4 / name)
print('PASS: staged released code, contract and three SHA-256-verified inputs. No inference or training was run.')
