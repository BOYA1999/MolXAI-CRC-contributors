import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
parser = argparse.ArgumentParser(description='Bind a separately validated V4 reconstruction without claiming historical byte identity.')
parser.add_argument('--source-dir', type=Path, required=True)
parser.add_argument('--output-contract', type=Path, required=True)
args = parser.parse_args()
target = args.output_contract.resolve()
if target.exists() or target == ROOT or ROOT in target.parents:
    parser.error('Use a new contract file outside the release.')
contract = json.loads((ROOT / 'contracts/v5/pharmacophore/run_contract.json').read_text())
actual = {}
for name, expected in contract['source_inputs'].items():
    with (args.source_dir / name).open('rb') as handle:
        actual[name] = hashlib.file_digest(handle, 'sha256').hexdigest()
    if not name.startswith('outputs/'):
        assert actual[name] == expected, name
validation = json.loads((args.source_dir / 'validation.json').read_text())
assert validation['status'] == 'TRUSTED_WITH_CAVEATS'
assert all(row['status'] == 'PASS' for row in validation['checks'])
reconstructed = pd.read_csv(args.source_dir / 'outputs/explanation_summary.csv').sort_values('method')
released = pd.read_csv(ROOT / 'results/v4/pharmacophore/explanation_summary.csv').sort_values('method')
columns = ['n', 'nominal_fraction', 'test_risk', 'mean_retained_fraction', 'mean_iou', 'mean_ph_score']
assert reconstructed.method.tolist() == released.method.tolist()
assert np.allclose(reconstructed[columns], released[columns], rtol=0, atol=1e-10, equal_nan=True)
contract['historical_source_inputs'] = contract['source_inputs']
contract['source_inputs'] = actual
contract['public_reconstruction'] = {
    'status': 'new_materialization_validated',
    'historical_byte_identity': actual == contract['historical_source_inputs'],
    'boundary': 'Upstream binaries and released generator unchanged; V4 independent validator passed and aggregate values agree within 1e-10. New derived-file hashes are explicit. This is not certification of historical per-molecule score byte identity.'}
target.write_text(json.dumps(contract, indent=2) + '\n', encoding='utf-8')
print('PASS: wrote external reconstruction contract; historical hashes retained separately.')
