import hashlib
import json
import platform
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.stats import spearmanr


PROJECT = Path(__file__).resolve().parents[3]
REVISION = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
PRIMARY = PROJECT / "artifacts/experiment/gradient_grid_main/cells"
SUBSET = REVISION / "experiments/established_explainers_20260901/cells"
A7 = REVISION / "experiments/jcim_a_level_20260904/a7_moleculeace_mmp"
FRACTIONS = np.linspace(0.0, 1.0, 101)
THRESHOLDS = [0.50, 0.60, 0.70, 0.80, 0.90]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def write_json(path, payload):
    Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")


def load_surface(directory, methods, surface):
    rows = []
    for path in sorted(directory.glob("*.json")):
        cell = json.loads(path.read_text(encoding="utf-8"))
        for method in methods:
            metrics = cell["explainers" if surface == "primary_full_grid" else "methods"][method]["metrics"]
            base = {
                "surface": surface,
                "cell_id": cell["cell_id"],
                "family": cell["family"],
                "task": cell["task"],
                "model": cell["model"],
                "seed": int(cell["seed"]),
                "method": method,
            }
            for budget in ("0.20", "0.50"):
                value = metrics["fixed"][budget]
                rows.append({
                    **base,
                    "policy": f"fixed_{int(float(budget) * 100)}",
                    "nominal_fraction": float(budget),
                    "risk": float(value["risk"]),
                    "retained_fraction": float(value["mean_atom_fraction"]),
                    "precision": float(value["precision"]),
                    "iou": float(value["iou"]),
                })
            value = metrics["alpha"]["0.10"]["crc"]
            rows.append({
                **base,
                "policy": "calibrated_alpha_0.10",
                "nominal_fraction": float(value["fraction"]),
                "risk": float(value["risk"]),
                "retained_fraction": float(value["mean_atom_fraction"]),
                "precision": float(value["precision"]),
                "iou": float(value["iou"]),
            })
    frame = pd.DataFrame(rows)
    frame["risk_pass"] = frame["risk"] <= 0.10 + 1e-12
    return frame


def task_macro(frame):
    values = ["risk", "retained_fraction", "precision", "iou"]
    return frame.groupby(["surface", "method", "policy", "family", "task"], as_index=False)[values].mean()


def summarize_budgets(frame):
    task = task_macro(frame)
    rows = []
    for keys, group in frame.groupby(["surface", "method", "policy"], sort=True):
        surface, method, policy = keys
        task_group = task[(task.surface == surface) & (task.method == method) & (task.policy == policy)]
        rows.append({
            "surface": surface,
            "method": method,
            "policy": policy,
            "cells": len(group),
            "risk_pass_cells": int(group.risk_pass.sum()),
            "task_macro_risk": float(task_group.risk.mean()),
            "task_macro_retained_fraction": float(task_group.retained_fraction.mean()),
            "task_macro_precision": float(task_group.precision.mean()),
            "task_macro_iou": float(task_group.iou.mean()),
        })
    return pd.DataFrame(rows)


def method_rankings(summary):
    rows = []
    for (surface, policy), group in summary.groupby(["surface", "policy"], sort=True):
        metric = "task_macro_retained_fraction" if policy == "calibrated_alpha_0.10" else "task_macro_iou"
        ascending = policy == "calibrated_alpha_0.10"
        ranked = group.sort_values([metric, "method"], ascending=[ascending, True]).copy()
        ranked["rank"] = np.arange(1, len(ranked) + 1)
        for row in ranked.itertuples(index=False):
            rows.append({
                "surface": surface,
                "policy": policy,
                "ranking_metric": metric,
                "method": row.method,
                "value": getattr(row, metric),
                "rank": int(ranked.loc[ranked.method == row.method, "rank"].iloc[0]),
            })
    return pd.DataFrame(rows)


def pairwise_preference(frame):
    primary = frame[frame.surface == "primary_full_grid"]
    calibrated = primary[primary.policy == "calibrated_alpha_0.10"].pivot(index="cell_id", columns="method", values="risk")
    both_pass = (calibrated["ig"] <= 0.10 + 1e-12) & (calibrated["gradinput"] <= 0.10 + 1e-12)
    rows = []
    for policy in ["fixed_20", "fixed_50", "calibrated_alpha_0.10"]:
        metric = "retained_fraction" if policy == "calibrated_alpha_0.10" else "iou"
        pivot = primary[primary.policy == policy].pivot(index="cell_id", columns="method", values=metric)
        delta = pivot["ig"] - pivot["gradinput"]
        if metric == "retained_fraction":
            preference = np.where(delta < -1e-12, "ig", np.where(delta > 1e-12, "gradinput", "tie"))
        else:
            preference = np.where(delta > 1e-12, "ig", np.where(delta < -1e-12, "gradinput", "tie"))
        rows.extend({"cell_id": cell, "policy": policy, "metric": metric, "ig_minus_gradinput": float(value),
                     "preferred_method": pref, "both_calibrated_risk_pass": bool(both_pass.loc[cell])}
                    for cell, value, pref in zip(pivot.index, delta, preference))
    return pd.DataFrame(rows)


def preference_summary(preferences, direct):
    rows = []
    calibrated = preferences[preferences.policy == "calibrated_alpha_0.10"][
        ["cell_id", "preferred_method", "both_calibrated_risk_pass"]
    ].rename(columns={"preferred_method": "calibrated_preference"})
    for policy in ["fixed_20", "fixed_50"]:
        fixed = preferences[preferences.policy == policy].merge(calibrated, on=["cell_id", "both_calibrated_risk_pass"])
        for scope, subset in [("all_cells", fixed), ("both_calibrated_risk_pass", fixed[fixed.both_calibrated_risk_pass])]:
            comparable = subset[(subset.preferred_method != "tie") & (subset.calibrated_preference != "tie")]
            rows.append({"level": "cell", "scope": scope, "fixed_policy": policy, "total": len(subset),
                         "non_tie_comparable": len(comparable),
                         "ranking_reversals": int((comparable.preferred_method != comparable.calibrated_preference).sum())})

    task = task_macro(direct[direct.surface == "primary_full_grid"])
    task["task_id"] = task.family + "__" + task.task
    task_preferences = []
    for policy in ["fixed_20", "fixed_50", "calibrated_alpha_0.10"]:
        metric = "retained_fraction" if policy == "calibrated_alpha_0.10" else "iou"
        pivot = task[task.policy == policy].pivot(index="task_id", columns="method", values=metric)
        delta = pivot["ig"] - pivot["gradinput"]
        if metric == "retained_fraction":
            pref = np.where(delta < -1e-12, "ig", np.where(delta > 1e-12, "gradinput", "tie"))
        else:
            pref = np.where(delta > 1e-12, "ig", np.where(delta < -1e-12, "gradinput", "tie"))
        task_preferences.append(pd.DataFrame({"task_id": pivot.index, "policy": policy, "preference": pref}))
    task_preferences = pd.concat(task_preferences)
    calibrated_task = task_preferences[task_preferences.policy == "calibrated_alpha_0.10"][["task_id", "preference"]].rename(
        columns={"preference": "calibrated_preference"})
    for policy in ["fixed_20", "fixed_50"]:
        fixed = task_preferences[task_preferences.policy == policy].merge(calibrated_task, on="task_id")
        comparable = fixed[(fixed.preference != "tie") & (fixed.calibrated_preference != "tie")]
        rows.append({"level": "task_macro", "scope": "all_tasks", "fixed_policy": policy, "total": len(fixed),
                     "non_tie_comparable": len(comparable),
                     "ranking_reversals": int((comparable.preference != comparable.calibrated_preference).sum())})
    return pd.DataFrame(rows)


def gate_sensitivity(direct):
    rows = []
    for surface, methods, directory in [
        ("primary_full_grid", ["gradinput", "ig"], PRIMARY),
        ("retrospective_matched_subset", ["gradinput", "ig", "saliency", "atom_occlusion", "gnnexplainer"], SUBSET),
    ]:
        alpha_values = ["0.05", "0.10", "0.20"] if surface == "primary_full_grid" else ["0.10"]
        table = []
        for path in sorted(directory.glob("*.json")):
            cell = json.loads(path.read_text(encoding="utf-8"))
            for method in methods:
                metrics = cell["explainers" if surface == "primary_full_grid" else "methods"][method]["metrics"]
                for alpha in alpha_values:
                    value = metrics["alpha"][alpha]["crc"]
                    table.append({
                        "family": cell["family"], "task": cell["task"], "cell_id": cell["cell_id"],
                        "method": method, "alpha": float(alpha), "retained_fraction": float(value["mean_atom_fraction"]),
                    })
        table = pd.DataFrame(table)
        task = table.groupby(["method", "alpha", "family", "task"], as_index=False).retained_fraction.mean()
        for (method, alpha), group in table.groupby(["method", "alpha"]):
            task_group = task[(task.method == method) & np.isclose(task.alpha, alpha)]
            for threshold in THRESHOLDS:
                rows.append({
                    "surface": surface,
                    "method": method,
                    "alpha": float(alpha),
                    "threshold": threshold,
                    "cell_pass_count": int((group.retained_fraction < threshold).sum()),
                    "cell_total": len(group),
                    "task_macro_pass_count": int((task_group.retained_fraction < threshold).sum()),
                    "task_total": len(task_group),
                    "mean_cell_retained_fraction": float(group.retained_fraction.mean()),
                    "mean_task_retained_fraction": float(task_group.retained_fraction.mean()),
                })
    return pd.DataFrame(rows)


def parse_mask(value):
    if pd.isna(value) or str(value).strip() == "":
        return []
    return [int(item) for item in str(value).split(";")]


def oracle_table(frame):
    values = np.empty((len(frame), len(FRACTIONS)), dtype=float)
    for index, row in enumerate(frame.itertuples(index=False)):
        total = int(row.n_atoms_a) + int(row.n_atoms_b)
        rationale = len(parse_mask(row.main_mask_a)) + len(parse_mask(row.main_mask_b))
        retained = np.where(FRACTIONS == 0, 0, np.ceil(FRACTIONS * total)).astype(int)
        values[index] = 1.0 - np.minimum(retained, rationale) / rationale
    return values


def calibrate(table, alpha=0.10):
    corrected = (len(table) * table.mean(axis=0) + 1.0) / (len(table) + 1.0)
    feasible = np.flatnonzero(corrected <= alpha)
    if not len(feasible):
        raise RuntimeError("no feasible oracle fraction")
    index = int(feasible[0])
    return index, float(table[:, index].mean()), float(corrected[index])


def oracle_metrics(frame, index):
    rows = []
    fraction = float(FRACTIONS[index])
    for row in frame.itertuples(index=False):
        total = int(row.n_atoms_a) + int(row.n_atoms_b)
        rationale = len(parse_mask(row.main_mask_a)) + len(parse_mask(row.main_mask_b))
        retained = 0 if fraction == 0 else int(np.ceil(fraction * total))
        recovered = min(retained, rationale)
        rows.append((1.0 - recovered / rationale, retained / total, recovered / retained if retained else 0.0,
                     recovered / (retained + rationale - recovered)))
    values = np.asarray(rows)
    return {"oracle_risk": float(values[:, 0].mean()), "oracle_retained_fraction": float(values[:, 1].mean()),
            "oracle_precision": float(values[:, 2].mean()), "oracle_iou": float(values[:, 3].mean())}


def analytical_random_table(frame):
    values = np.empty((len(frame), len(FRACTIONS)), dtype=float)
    for index, row in enumerate(frame.itertuples(index=False)):
        total = int(row.n_atoms_a) + int(row.n_atoms_b)
        retained = np.where(FRACTIONS == 0, 0, np.ceil(FRACTIONS * total)).astype(int)
        values[index] = 1.0 - retained / total
    return values


def analytical_random_metrics(frame, index):
    fraction = float(FRACTIONS[index])
    retained = []
    for row in frame.itertuples(index=False):
        total = int(row.n_atoms_a) + int(row.n_atoms_b)
        retained.append((0 if fraction == 0 else int(np.ceil(fraction * total))) / total)
    retained = np.asarray(retained)
    return {"random_crc_risk": float((1.0 - retained).mean()),
            "random_crc_retained_fraction": float(retained.mean())}


def mmp_decomposition():
    pairs = pd.read_csv(A7 / "mmp_pairs.csv")
    proxy_rows = []
    for row in pairs.itertuples(index=False):
        total = int(row.n_atoms_a) + int(row.n_atoms_b)
        rationale = len(parse_mask(row.main_mask_a)) + len(parse_mask(row.main_mask_b))
        proxy_rows.append({"dataset": row.dataset, "split": row.split, "pair_id": int(row.pair_id),
                           "component_id": row.component_id, "total_atoms": total, "proxy_atoms": rationale,
                           "proxy_atom_fraction": rationale / total})
    proxy = pd.DataFrame(proxy_rows)
    oracle_rows = []
    for target, group in pairs.groupby("dataset", sort=True):
        calibration = group[group.split == "calibration"]
        test = group[group.split == "test"]
        index, empirical, corrected = calibrate(oracle_table(calibration))
        metrics = oracle_metrics(test, index)
        random_index, random_empirical, random_corrected = calibrate(analytical_random_table(calibration))
        random_metrics = analytical_random_metrics(test, random_index)
        oracle_rows.append({"dataset": target, "n_calibration_pairs": len(calibration), "n_test_pairs": len(test),
                            "oracle_nominal_fraction": float(FRACTIONS[index]),
                            "oracle_calibration_empirical_risk": empirical,
                            "oracle_calibration_corrected_risk": corrected, **metrics,
                            "random_crc_nominal_fraction": float(FRACTIONS[random_index]),
                            "random_crc_calibration_empirical_risk": random_empirical,
                            "random_crc_calibration_corrected_risk": random_corrected, **random_metrics})
    oracle = pd.DataFrame(oracle_rows)

    results = pd.read_csv(A7 / "crc_results.csv")
    keep = ((results.proxy == "main_variable_plus_attachment_symmetry_closed") &
            (results.evaluation_split == "test") & (results.stratum == "all") &
            (results.aggregation == "pair_weighted"))
    actual = results[keep & (results.policy == "pair_crc_descriptive")].copy()
    random = results[keep & (results.policy == "random_same_nominal_size")][
        ["dataset", "seed", "method", "risk", "retained_fraction", "precision", "iou"]
    ].rename(columns={"risk": "same_size_random_risk", "retained_fraction": "same_size_random_retained_fraction",
                      "precision": "same_size_random_precision", "iou": "same_size_random_iou"})
    cells = actual.merge(random, on=["dataset", "seed", "method"], validate="one_to_one").merge(
        oracle, on="dataset", validate="many_to_one")
    cells["excess_over_oracle"] = cells.retained_fraction - cells.oracle_retained_fraction
    denominator = cells.random_crc_retained_fraction - cells.oracle_retained_fraction
    cells["random_to_oracle_recoverable_efficiency"] = ((cells.random_crc_retained_fraction - cells.retained_fraction) /
                                                         denominator).where(denominator > 0)

    model = pd.read_csv(A7 / "model_metrics.csv")
    cells = cells.merge(model[["dataset", "seed", "test_rmse", "test_spearman", "test_pair_direction_accuracy"]],
                        on=["dataset", "seed"], validate="many_to_one")
    target_method = cells.groupby(["dataset", "method"], as_index=False).agg(
        test_rmse=("test_rmse", "mean"), test_spearman=("test_spearman", "mean"),
        pair_direction_accuracy=("test_pair_direction_accuracy", "mean"),
        risk=("risk", "mean"), retained_fraction=("retained_fraction", "mean"),
        oracle_risk=("oracle_risk", "first"), oracle_retained_fraction=("oracle_retained_fraction", "first"),
        excess_over_oracle=("excess_over_oracle", "mean"),
        random_crc_risk=("random_crc_risk", "first"),
        random_crc_retained_fraction=("random_crc_retained_fraction", "first"),
        same_size_random_risk=("same_size_random_risk", "mean"),
        same_size_random_retained_fraction=("same_size_random_retained_fraction", "mean"),
        random_to_oracle_recoverable_efficiency=("random_to_oracle_recoverable_efficiency", "mean"),
    )
    correlations = []
    for method, group in target_method.groupby("method"):
        for competence in ["test_spearman", "pair_direction_accuracy", "test_rmse"]:
            for outcome in ["retained_fraction", "excess_over_oracle", "random_to_oracle_recoverable_efficiency"]:
                value = spearmanr(group[competence], group[outcome])
                correlations.append({"method": method, "competence_metric": competence, "outcome": outcome,
                                     "n_targets": len(group), "spearman_rho": float(value.statistic),
                                     "two_sided_p_descriptive": float(value.pvalue)})

    distribution = proxy.groupby(["dataset", "split"]).proxy_atom_fraction.agg(
        n_pairs="size", mean="mean", median="median", minimum="min", maximum="max",
        q10=lambda x: x.quantile(0.10), q25=lambda x: x.quantile(0.25),
        q75=lambda x: x.quantile(0.75), q90=lambda x: x.quantile(0.90)).reset_index()
    return proxy, distribution, oracle, cells, target_method, pd.DataFrame(correlations)


def main():
    fixed = OUT / "fixed_budget"
    gate = OUT / "gate_sensitivity"
    mmp = OUT / "mmp_oracle"
    for directory in [fixed, gate, mmp]:
        directory.mkdir(parents=True, exist_ok=True)

    primary = load_surface(PRIMARY, ["gradinput", "ig"], "primary_full_grid")
    subset = load_surface(SUBSET, ["gradinput", "ig", "saliency", "atom_occlusion", "gnnexplainer"],
                          "retrospective_matched_subset")
    direct = pd.concat([primary, subset], ignore_index=True)
    summary = summarize_budgets(direct)
    rankings = method_rankings(summary)
    preferences = pairwise_preference(direct)
    preference_counts = preference_summary(preferences, direct)
    direct.to_csv(fixed / "cell_results.csv", index=False)
    task_macro(direct).to_csv(fixed / "task_macro_results.csv", index=False)
    summary.to_csv(fixed / "method_summary.csv", index=False)
    rankings.to_csv(fixed / "method_rankings.csv", index=False)
    preferences.to_csv(fixed / "ig_gradinput_cell_preferences.csv", index=False)
    preference_counts.to_csv(fixed / "ranking_flip_summary.csv", index=False)

    thresholds = gate_sensitivity(direct)
    thresholds.to_csv(gate / "threshold_sensitivity.csv", index=False)

    proxy, distribution, oracle, cells, target_method, correlations = mmp_decomposition()
    proxy.to_csv(mmp / "pair_proxy_fractions.csv", index=False)
    distribution.to_csv(mmp / "proxy_fraction_distribution.csv", index=False)
    oracle.to_csv(mmp / "target_oracle.csv", index=False)
    cells.to_csv(mmp / "cell_decomposition.csv", index=False)
    target_method.to_csv(mmp / "target_method_decomposition.csv", index=False)
    correlations.to_csv(mmp / "competence_associations.csv", index=False)

    selected = summary[summary.policy.isin(["fixed_20", "fixed_50", "calibrated_alpha_0.10"])]
    mmp_macro = target_method.groupby("method")[["risk", "retained_fraction", "oracle_risk",
                                                  "oracle_retained_fraction", "excess_over_oracle",
                                                  "random_crc_risk", "random_crc_retained_fraction",
                                                  "same_size_random_risk", "same_size_random_retained_fraction",
                                                  "random_to_oracle_recoverable_efficiency"]].mean().to_dict("index")
    source_paths = list(PRIMARY.glob("*.json")) + list(SUBSET.glob("*.json")) + [
        A7 / "mmp_pairs.csv", A7 / "crc_results.csv", A7 / "model_metrics.csv"]
    write_json(OUT / "summary.json", {
        "status": "analysis_complete_pending_validation",
        "fixed_budget": {"rows": len(direct), "summary": selected.to_dict("records")},
        "gate_sensitivity": {"rows": len(thresholds), "thresholds": THRESHOLDS},
        "mmp_oracle": {"pairs": len(proxy), "targets": int(oracle.dataset.nunique()), "cells": len(cells),
                       "macro_by_method": mmp_macro},
        "boundaries": [
            "fixed-budget and gate analyses reuse frozen outputs",
            "five-method results remain retrospective matched-subset evidence",
            "MoleculeACE pairs are clustered and the transformation-site proxy is not causal or complete ground truth",
            "association p-values are descriptive and unadjusted",
        ],
        "source_sha256": {str(path.relative_to(PROJECT)): sha256(path) for path in source_paths},
    })
    write_json(OUT / "environment.json", {
        "python": sys.version,
        "executable": sys.executable,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "script_sha256": sha256(__file__),
    })


if __name__ == "__main__":
    main()
