import argparse
import hashlib
import json
import os
import platform
import sys
import time
from pathlib import Path

import torch
import torch_geometric
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from torch_geometric.loader import DataLoader


HERE = Path(__file__).resolve().parent
PACKAGE_ROOT = HERE.parents[2]
PROJECT = Path(os.environ.get("MOLXAI_PROJECT_ROOT", PACKAGE_ROOT))
REVISION = PROJECT
SOURCE_CACHE = Path(os.environ.get("MOLXAI_SCORE_CACHE", "<tie-inclusive-score-cache>"))
CHECKPOINTS = PROJECT / "artifacts/experiment/gradient_grid_main/checkpoints"
sys.path.insert(0, str(PACKAGE_ROOT / "src"))

from molxai_crc import calibrate_crc, loss_table, top_fraction_set
from run_bxaic_probe import set_seed
from run_gnnexplainer_dev_gate import gnn_scores
from run_gradient_grid import BXAIC_TASKS, GOOGLE_TASKS, FRACTIONS, GraphClassifier, bxaic_partitions, google_partitions, set_metrics


TASKS = [("bxaic", task) for task in BXAIC_TASKS] + [("google", task) for task in GOOGLE_TASKS]


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def cache_path(family, task):
    return SOURCE_CACHE / f"{family}__{task}__gin__seed42.npz"


def split_cache(cache, split, method=None, limit=None):
    offsets = cache[f"{split}__offsets"]
    n_rows = len(offsets) - 1 if limit is None else min(limit, len(offsets) - 1)
    truths, scores = [], []
    for index in range(n_rows):
        start, end = int(offsets[index]), int(offsets[index + 1])
        truths.append(set(np.flatnonzero(cache[f"{split}__rationale_values"][start:end]).tolist()))
        if method:
            scores.append(cache[f"{method}__{split}__score_values"][start:end].astype(float))
    return scores, truths, cache[f"{split}__source_indices"][:n_rows].astype(int)


def variant_metrics(cal_scores, cal_truths, test_scores, test_truths):
    table = loss_table(cal_scores, cal_truths, FRACTIONS)
    crc = calibrate_crc(table, FRACTIONS, 0.10)
    return {**crc, **set_metrics(test_scores, test_truths, crc["fraction"])}


def tie_metrics(score_rows, fraction):
    expanded, inflations, realized, full = [], [], [], 0
    for scores in score_rows:
        scores = np.asarray(scores, dtype=float)
        if fraction == 0 or not len(scores):
            selected = nominal = 0
        else:
            nominal = int(np.ceil(fraction * len(scores)))
            threshold = np.partition(scores, len(scores) - nominal)[len(scores) - nominal]
            selected = int(np.sum(scores >= threshold))
        expanded.append(selected > nominal)
        inflations.append((selected - nominal) / len(scores) if len(scores) else 0.0)
        realized.append(selected / len(scores) if len(scores) else 0.0)
        full += int(selected == len(scores) and selected > nominal)
    return {
        "test_tie_expansion_rate": float(np.mean(expanded)),
        "test_mean_tie_inflation": float(np.mean(inflations)),
        "test_max_tie_inflation": float(np.max(inflations)),
        "test_mean_realized_fraction_from_scores": float(np.mean(realized)),
        "test_full_molecule_due_to_ties": full,
    }


def cached_stage():
    rows = []
    variants = [
        ("gradinput", "signed", lambda x: x),
        ("gradinput", "positive_part", lambda x: np.maximum(x, 0.0)),
        ("gradinput", "absolute", np.abs),
        ("ig", "signed", lambda x: x),
        ("ig", "positive_part", lambda x: np.maximum(x, 0.0)),
        ("ig", "absolute", np.abs),
        ("atom_occlusion", "signed_decrease", lambda x: x),
        ("atom_occlusion", "absolute_change", np.abs),
    ]
    for family, task in TASKS:
        path = cache_path(family, task)
        with np.load(path) as cache:
            for method, transform, function in variants:
                cal, cal_truths, _ = split_cache(cache, "calibration", method)
                test, test_truths, _ = split_cache(cache, "test", method)
                cal = [function(row) for row in cal]
                test = [function(row) for row in test]
                value = variant_metrics(cal, cal_truths, test, test_truths)
                ties = tie_metrics(test, value["fraction"])
                all_rows = cal + test
                rows.append({
                    "family": family, "task": task, "cell_id": f"{family}__{task}__gin__seed42",
                    "method": method, "transformation": transform, "n_calibration": len(cal), "n_test": len(test),
                    "negative_score_fraction": float(np.mean(np.concatenate(all_rows) < 0)),
                    "all_nonpositive_molecules": int(sum(np.max(row) <= 0 for row in all_rows)),
                    "selected_fraction": value["fraction"], "calibration_empirical_risk": value["empirical_risk"],
                    "calibration_corrected_risk": value["corrected_risk"], "risk": value["risk"],
                    "retained_fraction": value["mean_atom_fraction"], "precision": value["precision"], "iou": value["iou"],
                    **ties,
                    "source_cache_sha256": sha256(path),
                })
    frame = pd.DataFrame(rows)
    frame.to_csv(HERE / "cached_variants.csv", index=False)
    print(f"cached_variants={len(frame)}", flush=True)


def load_partitions(family, task):
    if family == "bxaic":
        return bxaic_partitions(PROJECT / "data/raw/bxaic/data.csv", PROJECT / "data/raw/bxaic/explanations.sdf", task)
    return google_partitions(PROJECT / "reference/graph-attribution/data", task)


def ordered_graphs(partition, source_indices):
    mapping = {int(graph.source_index): graph for graph in partition}
    missing = [int(index) for index in source_indices if int(index) not in mapping]
    if missing:
        raise ValueError(f"missing source indices: {missing[:5]}")
    return [mapping[int(index)] for index in source_indices]


def fit_atom_mean(graphs):
    total = torch.zeros(graphs[0].x.shape[1], dtype=torch.float64)
    count = 0
    for graph in graphs:
        total += graph.x.double().sum(dim=0)
        count += graph.num_nodes
    return (total / count).float()


def ig_scores(model, graphs, device, baseline_vector, steps, batch_size=16):
    rows, errors = [], []
    started = time.perf_counter()
    for batch in DataLoader(graphs, batch_size=batch_size, shuffle=False):
        batch = batch.to(device)
        input_x = batch.x.detach()
        baseline_x = baseline_vector.to(device).reshape(1, -1).expand_as(input_x)
        with torch.no_grad():
            index = torch.arange(len(batch.y), device=device)
            input_logits = model(input_x, batch.edge_index, batch.batch)[index, batch.y]
            baseline_logits = model(baseline_x, batch.edge_index, batch.batch)[index, batch.y]
        total_grad = torch.zeros_like(input_x)
        for step in range(1, steps + 1):
            x = (baseline_x + (input_x - baseline_x) * step / steps).detach().requires_grad_(True)
            logits = model(x, batch.edge_index, batch.batch)
            target = logits[index, batch.y].sum()
            total_grad += torch.autograd.grad(target, x)[0]
        atom_scores = ((input_x - baseline_x) * total_grad / steps).sum(dim=-1).detach().cpu().numpy()
        deltas = (input_logits - baseline_logits).detach().cpu().numpy()
        ptr = batch.ptr.detach().cpu().numpy()
        for row_index, (start, end) in enumerate(zip(ptr[:-1], ptr[1:])):
            row = atom_scores[start:end]
            rows.append(row)
            errors.append(abs(float(row.sum()) - float(deltas[row_index])))
    return rows, np.asarray(errors), time.perf_counter() - started


def ragged_payload(prefix, scores, errors):
    lengths = np.asarray([len(row) for row in scores], dtype=np.int64)
    return {f"{prefix}__offsets": np.concatenate([[0], np.cumsum(lengths)]),
            f"{prefix}__scores": np.concatenate(scores), f"{prefix}__completeness": errors}


def score_agreement(first, second):
    a, b = np.concatenate(first), np.concatenate(second)
    rho = spearmanr(a, b).statistic
    return float(rho), float(np.mean(np.abs(a - b))), float(np.max(np.abs(a - b)))


def ig_stage():
    out = HERE / "ig_cells"
    cache_out = HERE / "ig_score_cache"
    out.mkdir(exist_ok=True)
    cache_out.mkdir(exist_ok=True)
    for family, task in TASKS:
        cell_id = f"{family}__{task}__gin__seed42"
        result_path = out / f"{cell_id}.json"
        if result_path.exists() and json.loads(result_path.read_text(encoding="utf-8")).get("status") == "complete":
            print(f"ig_skip={cell_id}", flush=True)
            continue
        partitions = load_partitions(family, task)
        with np.load(cache_path(family, task)) as cache:
            cached_cal, cal_truths, cal_indices = split_cache(cache, "calibration", "ig")
            cached_test, test_truths, test_indices = split_cache(cache, "test", "ig")
        calibration = ordered_graphs(partitions["calibration"], cal_indices)
        test = ordered_graphs(partitions["test"], test_indices)
        baseline_mean = fit_atom_mean(partitions["fit"])
        checkpoint = CHECKPOINTS / f"{cell_id}.pt"
        device = torch.device("cuda")
        model = GraphClassifier("gin", calibration[0].x.shape[1]).to(device)
        model.load_state_dict(torch.load(checkpoint, map_location=device, weights_only=True)["state_dict"])
        model.eval()
        variants, arrays = {}, {}
        for baseline_name, baseline in [("zero", torch.zeros_like(baseline_mean)), ("fit_atom_mean", baseline_mean)]:
            for steps in [20, 50, 100]:
                name = f"{baseline_name}_{steps}"
                cal_scores, cal_errors, cal_seconds = ig_scores(model, calibration, device, baseline, steps)
                test_scores, test_errors, test_seconds = ig_scores(model, test, device, baseline, steps)
                metric = variant_metrics(cal_scores, cal_truths, test_scores, test_truths)
                variants[name] = {
                    **metric,
                    "calibration_completeness_mean": float(cal_errors.mean()),
                    "calibration_completeness_median": float(np.median(cal_errors)),
                    "test_completeness_mean": float(test_errors.mean()),
                    "test_completeness_median": float(np.median(test_errors)),
                    "test_completeness_max": float(test_errors.max()),
                    "runtime_seconds": cal_seconds + test_seconds,
                }
                arrays.update(ragged_payload(f"{name}__calibration", cal_scores, cal_errors))
                arrays.update(ragged_payload(f"{name}__test", test_scores, test_errors))
                if name == "zero_20":
                    cal_agreement = score_agreement(cached_cal, cal_scores)
                    test_agreement = score_agreement(cached_test, test_scores)
                    variants[name]["cache_score_spearman_calibration"] = cal_agreement[0]
                    variants[name]["cache_score_mae_calibration"] = cal_agreement[1]
                    variants[name]["cache_score_max_abs_calibration"] = cal_agreement[2]
                    variants[name]["cache_score_spearman_test"] = test_agreement[0]
                    variants[name]["cache_score_mae_test"] = test_agreement[1]
                    variants[name]["cache_score_max_abs_test"] = test_agreement[2]
        arrays.update({"calibration__source_indices": cal_indices, "test__source_indices": test_indices,
                       "fit_atom_mean": baseline_mean.numpy()})
        np.savez_compressed(cache_out / f"{cell_id}.npz", **arrays)
        write_json(result_path, {
            "status": "complete", "cell_id": cell_id, "family": family, "task": task,
            "model": "gin", "training_seed": 42, "checkpoint": str(checkpoint.relative_to(PROJECT)),
            "checkpoint_sha256": sha256(checkpoint), "n_calibration": len(calibration), "n_test": len(test),
            "baseline_mean": baseline_mean.tolist(), "variants": variants,
        })
        del model, partitions, calibration, test
        torch.cuda.empty_cache()
        print(f"ig_complete={cell_id}", flush=True)


def gnn_stage():
    out = HERE / "gnn_cells"
    cache_out = HERE / "gnn_score_cache"
    out.mkdir(exist_ok=True)
    cache_out.mkdir(exist_ok=True)
    for family, task in TASKS:
        cell_id = f"{family}__{task}__gin__seed42"
        partitions = load_partitions(family, task)
        with np.load(cache_path(family, task)) as cache:
            _, cal_truths, cal_indices = split_cache(cache, "calibration", limit=25)
            _, test_truths, test_indices = split_cache(cache, "test", limit=25)
        calibration = ordered_graphs(partitions["calibration"], cal_indices)
        test = ordered_graphs(partitions["test"], test_indices)
        checkpoint = CHECKPOINTS / f"{cell_id}.pt"
        device = torch.device("cuda")
        model = GraphClassifier("gin", calibration[0].x.shape[1]).to(device)
        model.load_state_dict(torch.load(checkpoint, map_location=device, weights_only=True)["state_dict"])
        model.eval()
        for init_seed in [123, 2026]:
            result_path = out / f"{cell_id}__init{init_seed}.json"
            if result_path.exists() and json.loads(result_path.read_text(encoding="utf-8")).get("status") == "complete":
                print(f"gnn_skip={cell_id} init={init_seed}", flush=True)
                continue
            set_seed(init_seed)
            cal_scores, cal_timing = gnn_scores(model, calibration, device, 100)
            test_scores, test_timing = gnn_scores(model, test, device, 100)
            value = variant_metrics(cal_scores, cal_truths, test_scores, test_truths)
            arrays = {"calibration__source_indices": cal_indices, "test__source_indices": test_indices}
            arrays.update(ragged_payload("calibration", cal_scores, np.full(len(cal_scores), np.nan)))
            arrays.update(ragged_payload("test", test_scores, np.full(len(test_scores), np.nan)))
            np.savez_compressed(cache_out / f"{cell_id}__init{init_seed}.npz", **arrays)
            write_json(result_path, {"status": "complete", "cell_id": cell_id, "family": family, "task": task,
                                     "model": "gin", "training_seed": 42, "initialization_seed": init_seed,
                                     "epochs": 100, "n_calibration": len(calibration), "n_test": len(test),
                                     "checkpoint_sha256": sha256(checkpoint), "metrics": value,
                                     "calibration_timing": cal_timing, "test_timing": test_timing})
            print(f"gnn_complete={cell_id} init={init_seed}", flush=True)
        del model, partitions, calibration, test
        torch.cuda.empty_cache()


def load_gnn_scores(cell_id, init_seed, split):
    if init_seed == 42:
        with np.load(SOURCE_CACHE / f"{cell_id}.npz") as cache:
            scores, truths, indices = split_cache(cache, split, "gnnexplainer", 25)
        return scores, truths, indices
    with np.load(HERE / "gnn_score_cache" / f"{cell_id}__init{init_seed}.npz") as cache:
        offsets = cache[f"{split}__offsets"]
        values = cache[f"{split}__scores"]
        scores = [values[int(a):int(b)] for a, b in zip(offsets[:-1], offsets[1:])]
        indices = cache[f"{split}__source_indices"]
    with np.load(SOURCE_CACHE / f"{cell_id}.npz") as source:
        _, truths, source_indices = split_cache(source, split, limit=25)
    if not np.array_equal(indices, source_indices):
        raise ValueError("GNN source-index mismatch")
    return scores, truths, indices


def aggregate():
    cached = pd.read_csv(HERE / "cached_variants.csv")
    ig_rows = []
    for path in sorted((HERE / "ig_cells").glob("*.json")):
        cell = json.loads(path.read_text(encoding="utf-8"))
        for name, value in cell["variants"].items():
            ig_rows.append({"family": cell["family"], "task": cell["task"], "cell_id": cell["cell_id"],
                            "baseline": name.rsplit("_", 1)[0], "steps": int(name.rsplit("_", 1)[1]), **value})
    ig = pd.DataFrame(ig_rows)
    ig.to_csv(HERE / "ig_variants.csv", index=False)

    gnn_rows, agreement_rows = [], []
    for family, task in TASKS:
        cell_id = f"{family}__{task}__gin__seed42"
        by_seed = {}
        for init_seed in [42, 123, 2026]:
            cal_scores, cal_truths, _ = load_gnn_scores(cell_id, init_seed, "calibration")
            test_scores, test_truths, _ = load_gnn_scores(cell_id, init_seed, "test")
            value = variant_metrics(cal_scores, cal_truths, test_scores, test_truths)
            by_seed[init_seed] = (test_scores, value["fraction"])
            gnn_rows.append({"family": family, "task": task, "cell_id": cell_id,
                             "initialization_seed": init_seed, "origin": "frozen_cache" if init_seed == 42 else "new_run",
                             **value})
        for first, second in [(42, 123), (42, 2026), (123, 2026)]:
            scores_a, fraction_a = by_seed[first]
            scores_b, fraction_b = by_seed[second]
            jaccards = []
            for a, b in zip(scores_a, scores_b):
                set_a = top_fraction_set(a, fraction_a)
                set_b = top_fraction_set(b, fraction_b)
                jaccards.append(len(set_a & set_b) / len(set_a | set_b) if set_a | set_b else 1.0)
            agreement_rows.append({"family": family, "task": task, "cell_id": cell_id,
                                   "initialization_pair": f"{first}-{second}",
                                   "mean_set_jaccard": float(np.mean(jaccards)),
                                   "median_set_jaccard": float(np.median(jaccards)), "n_test": len(jaccards)})
    gnn = pd.DataFrame(gnn_rows)
    agreement = pd.DataFrame(agreement_rows)
    gnn.to_csv(HERE / "gnn_initializations.csv", index=False)
    agreement.to_csv(HERE / "gnn_set_agreement.csv", index=False)

    cached_macro = cached.groupby(["method", "transformation"], as_index=False)[[
        "risk", "retained_fraction", "precision", "iou", "test_tie_expansion_rate",
        "test_mean_tie_inflation", "test_max_tie_inflation",
        "test_mean_realized_fraction_from_scores", "test_full_molecule_due_to_ties",
    ]].mean()
    tie_work = cached.assign(
        tie_expansion_molecules=cached.test_tie_expansion_rate * cached.n_test,
        tie_inflation_weight=cached.test_mean_tie_inflation * cached.n_test,
    )
    tie_summary = tie_work.groupby(["method", "transformation"], as_index=False).agg(
        n_test=("n_test", "sum"), tie_expansion_molecules=("tie_expansion_molecules", "sum"),
        full_molecule_due_to_ties=("test_full_molecule_due_to_ties", "sum"),
        tie_inflation_weight=("tie_inflation_weight", "sum"),
    )
    tie_summary["tie_expansion_molecules"] = tie_summary.tie_expansion_molecules.round().astype(int)
    tie_summary["tie_expansion_fraction"] = tie_summary.tie_expansion_molecules / tie_summary.n_test
    tie_summary["weighted_mean_tie_inflation"] = tie_summary.tie_inflation_weight / tie_summary.n_test
    tie_summary = tie_summary.drop(columns="tie_inflation_weight")
    ig_macro = ig.groupby(["baseline", "steps"], as_index=False).agg(
        risk=("risk", "mean"), mean_atom_fraction=("mean_atom_fraction", "mean"),
        precision=("precision", "mean"), iou=("iou", "mean"),
        test_completeness_task_macro_mean=("test_completeness_mean", "mean"),
        test_completeness_cell_max_mean=("test_completeness_max", "mean"),
    )
    completeness_rows = []
    monotonicity_rows = []
    for baseline in ["zero", "fit_atom_mean"]:
        by_step = {steps: [] for steps in [20, 50, 100]}
        for family, task in TASKS:
            cell_id = f"{family}__{task}__gin__seed42"
            with np.load(HERE / "ig_score_cache" / f"{cell_id}.npz") as score_cache:
                for steps in [20, 50, 100]:
                    by_step[steps].append(score_cache[f"{baseline}_{steps}__test__completeness"].astype(float))
        for steps, cell_arrays in by_step.items():
            pooled = np.concatenate(cell_arrays)
            completeness_rows.append({
                "baseline": baseline, "steps": steps, "n_test": len(pooled),
                "test_completeness_pooled_mean": float(pooled.mean()),
                "test_completeness_pooled_median": float(np.median(pooled)),
                "test_completeness_pooled_max": float(pooled.max()),
            })
        monotonic = sum(np.sum((middle <= first) & (last <= middle))
                        for first, middle, last in zip(by_step[20], by_step[50], by_step[100]))
        monotonicity_rows.append({
            "baseline": baseline, "n_test": sum(len(row) for row in by_step[20]),
            "n_monotonic_20_to_50_to_100": int(monotonic),
            "fraction_monotonic_20_to_50_to_100": float(monotonic / sum(len(row) for row in by_step[20])),
        })
    completeness = pd.DataFrame(completeness_rows)
    monotonicity = pd.DataFrame(monotonicity_rows)
    gnn_macro = gnn.groupby("initialization_seed", as_index=False)[["risk", "mean_atom_fraction", "precision", "iou"]].mean()
    cached_macro.to_csv(HERE / "cached_variant_macro.csv", index=False)
    tie_summary.to_csv(HERE / "cached_tie_summary.csv", index=False)
    ig_macro.to_csv(HERE / "ig_variant_macro.csv", index=False)
    completeness.to_csv(HERE / "ig_completeness_pooled.csv", index=False)
    monotonicity.to_csv(HERE / "ig_completeness_monotonicity.csv", index=False)
    gnn_macro.to_csv(HERE / "gnn_initialization_macro.csv", index=False)
    variability = gnn.groupby(["family", "task"]).agg(
        risk_sd=("risk", "std"), risk_range=("risk", lambda x: x.max() - x.min()),
        retained_fraction_sd=("mean_atom_fraction", "std"),
        retained_fraction_range=("mean_atom_fraction", lambda x: x.max() - x.min()),
        iou_sd=("iou", "std"), iou_range=("iou", lambda x: x.max() - x.min())).reset_index()
    variability.to_csv(HERE / "gnn_initialization_variability.csv", index=False)
    write_json(HERE / "summary.json", {
        "status": "complete_pending_validation",
        "surface": "11 GIN seed-42 task cells; matched at-most-100 slice, with 25 per split for GNNExplainer initialization",
        "cached_variant_macro": cached_macro.to_dict("records"),
        "cached_tie_summary": tie_summary.to_dict("records"),
        "ig_variant_macro": ig_macro.to_dict("records"),
        "ig_completeness_pooled": completeness.to_dict("records"),
        "ig_completeness_monotonicity": monotonicity.to_dict("records"),
        "gnn_initialization_macro": gnn_macro.to_dict("records"),
        "gnn_variability_mean": variability.select_dtypes("number").mean().to_dict(),
        "gnn_set_agreement_mean": float(agreement.mean_set_jaccard.mean()),
        "boundary": "retrospective one-backbone one-training-seed sensitivity; transformations are alternative score semantics rather than a fairness ground truth",
    })
    print(f"aggregate cached={len(cached)} ig={len(ig)} gnn={len(gnn)}", flush=True)


def environment():
    write_json(HERE / "environment.json", {
        "python": sys.version, "executable": sys.executable, "platform": platform.platform(),
        "torch": torch.__version__, "torch_geometric": torch_geometric.__version__,
        "numpy": np.__version__, "pandas": pd.__version__,
        "cuda_available": torch.cuda.is_available(),
        "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        "script_sha256": sha256(__file__), "contract_sha256": sha256(HERE / "run_contract.json"),
    })


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["cached", "ig", "gnn", "aggregate", "all"], default="all")
    args = parser.parse_args()
    environment()
    if args.stage in ["cached", "all"]:
        cached_stage()
    if args.stage in ["ig", "all"]:
        ig_stage()
    if args.stage in ["gnn", "all"]:
        gnn_stage()
    if args.stage in ["aggregate", "all"]:
        aggregate()


if __name__ == "__main__":
    main()
