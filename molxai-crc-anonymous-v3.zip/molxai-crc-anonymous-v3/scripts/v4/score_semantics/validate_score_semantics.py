import hashlib
import json
import os
from pathlib import Path

import torch
import numpy as np
import pandas as pd
from scipy.stats import spearmanr


HERE = Path(__file__).resolve().parent
PACKAGE_ROOT = HERE.parents[2]
PROJECT = Path(os.environ.get("MOLXAI_PROJECT_ROOT", PACKAGE_ROOT))
SOURCE_ROOT = Path(os.environ.get("MOLXAI_SCORE_SEMANTICS_ROOT", "<tie-inclusive-root>"))
SOURCE_CACHE = SOURCE_ROOT / "score_cache"
CHECKPOINTS = PROJECT / "artifacts/experiment/gradient_grid_main/checkpoints"
FRACTIONS = np.linspace(0, 1, 101)
TASKS = ([('bxaic', task) for task in ['B', 'P', 'X', 'indole', 'PAINS', 'rings-count', 'rings-max']] +
         [('google', task) for task in ['benzene', 'logic7', 'logic8', 'logic10']])


def require(condition, message, checks):
    if not condition:
        raise AssertionError(message)
    checks.append(message)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def ragged(offsets, values, limit=None):
    n_rows = len(offsets) - 1 if limit is None else min(limit, len(offsets) - 1)
    return [np.asarray(values[int(offsets[i]):int(offsets[i + 1])], dtype=float) for i in range(n_rows)]


def source_rows(cache, split, key, limit=None):
    return ragged(cache[f"{split}__offsets"], cache[key], limit)


def source_truths(cache, split, limit=None):
    return [set(np.flatnonzero(row).tolist()) for row in
            source_rows(cache, split, f"{split}__rationale_values", limit)]


def top_set(scores, fraction):
    scores = np.asarray(scores, dtype=float)
    if fraction == 0 or not len(scores):
        return set()
    nominal = int(np.ceil(fraction * len(scores)))
    threshold = np.partition(scores, len(scores) - nominal)[len(scores) - nominal]
    return set(np.flatnonzero(scores >= threshold).tolist())


def tie_stats(score_rows, fraction):
    expanded = []
    inflation = []
    realized = []
    full = 0
    for scores in score_rows:
        nominal = 0 if fraction == 0 else int(np.ceil(fraction * len(scores)))
        selected = len(top_set(scores, fraction))
        expanded.append(selected > nominal)
        inflation.append((selected - nominal) / len(scores))
        realized.append(selected / len(scores))
        full += int(selected == len(scores) and selected > nominal)
    return {
        "test_tie_expansion_rate": float(np.mean(expanded)),
        "test_mean_tie_inflation": float(np.mean(inflation)),
        "test_max_tie_inflation": float(np.max(inflation)),
        "test_mean_realized_fraction_from_scores": float(np.mean(realized)),
        "test_full_molecule_due_to_ties": full,
        "n_test": len(score_rows),
        "tie_expansion_molecules": int(sum(expanded)),
    }


def recalculate(calibration_scores, calibration_truths, test_scores, test_truths):
    losses = np.asarray([[1 - len(top_set(scores, fraction) & truth) / len(truth)
                          for fraction in FRACTIONS]
                         for scores, truth in zip(calibration_scores, calibration_truths)], dtype=float)
    n_calibration = len(losses)
    corrected = (n_calibration * losses.mean(axis=0) + 1) / (n_calibration + 1)
    index = int(np.flatnonzero(corrected <= 0.10)[0])
    fraction = float(FRACTIONS[index])
    selected = [top_set(scores, fraction) for scores in test_scores]
    return {
        "fraction": fraction,
        "empirical_risk": float(losses[:, index].mean()),
        "corrected_risk": float(corrected[index]),
        "risk": float(np.mean([1 - len(atoms & truth) / len(truth)
                               for atoms, truth in zip(selected, test_truths)])),
        "retained_fraction": float(np.mean([len(atoms) / len(scores)
                                            for atoms, scores in zip(selected, test_scores)])),
        "precision": float(np.mean([len(atoms & truth) / len(atoms) if atoms else 0
                                    for atoms, truth in zip(selected, test_truths)])),
        "iou": float(np.mean([len(atoms & truth) / len(atoms | truth)
                              for atoms, truth in zip(selected, test_truths)])),
        "sets": selected,
    }


def assert_metrics(row, result, fraction_column, retained_column, differences):
    pairs = {
        fraction_column: result["fraction"],
        "calibration_empirical_risk" if fraction_column == "selected_fraction" else "empirical_risk": result["empirical_risk"],
        "calibration_corrected_risk" if fraction_column == "selected_fraction" else "corrected_risk": result["corrected_risk"],
        "risk": result["risk"], retained_column: result["retained_fraction"],
        "precision": result["precision"], "iou": result["iou"],
    }
    differences.extend(abs(float(row[column]) - value) for column, value in pairs.items())


def frame_max_difference(expected, observed, keys):
    expected = expected.sort_values(keys).reset_index(drop=True)
    observed = observed[expected.columns].sort_values(keys).reset_index(drop=True)
    if not expected[keys].equals(observed[keys]):
        return float("inf")
    numeric = [column for column in expected.columns if column not in keys]
    return float(np.max(np.abs(expected[numeric].to_numpy(dtype=float) -
                               observed[numeric].to_numpy(dtype=float))))


def label_counts(family, task, calibration_indices, test_indices):
    if family == "bxaic":
        labels = pd.read_csv(PROJECT / "data/raw/bxaic/data.csv")[task].to_numpy(dtype=int)
    else:
        labels = np.load(PROJECT / f"reference/graph-attribution/data/{task}/y_true.npz")["y"].reshape(-1).astype(int)
    return {split: {str(label): int(np.sum(labels[indices] == label)) for label in [0, 1]}
            for split, indices in [("calibration", calibration_indices), ("test", test_indices)]}


def molecule_identity(family, task, calibration_indices, test_indices):
    if family == "bxaic":
        frame = pd.read_csv(PROJECT / "data/raw/bxaic/data.csv")
        columns = ["ChEMBL ID", "smiles"]
    else:
        frame = pd.read_csv(PROJECT / f"reference/graph-attribution/data/{task}/{task}_smiles.csv")
        columns = ["mol_id", "smiles"]
    result = {}
    for column in columns:
        calibration = frame.loc[calibration_indices, column].astype(str)
        test = frame.loc[test_indices, column].astype(str)
        result[column] = {
            "calibration_duplicates": int(calibration.duplicated().sum()),
            "test_duplicates": int(test.duplicated().sum()),
            "calibration_test_overlap": len(set(calibration) & set(test)),
        }
    return result


def main():
    checks = []
    contract = json.loads((HERE / "run_contract.json").read_text(encoding="utf-8"))
    amendment = json.loads((HERE / "contract_amendment_001.json").read_text(encoding="utf-8"))
    run_text = (HERE / "run_score_semantics.py").read_text(encoding="utf-8")
    gradient_text = (PROJECT / "src/run_bxaic_probe.py").read_text(encoding="utf-8")
    gnn_text = (PROJECT / "src/run_gnnexplainer_dev_gate.py").read_text(encoding="utf-8")
    source_runner_text = (SOURCE_ROOT.parent / "run_established_explainer_benchmark_tie_inclusive.py").read_text(encoding="utf-8")
    require(contract["ig_grid"]["target"] == "true-class logit" and
            amendment["clarifications"]["target"].startswith("dataset ground-truth class"),
            "contract and amendment identify the dataset ground-truth class as the attribution target", checks)
    require("target = logits[index, batch.y].sum()" in run_text and
            "target = logits[torch.arange(len(batch.y), device=device), batch.y].sum()" in gradient_text and
            "[0, int(source.y)]" in source_runner_text and "target=data.y.view(1)" in gnn_text,
            "IG, GradInput, occlusion, and GNNExplainer implementations target data.y rather than the predicted class", checks)
    gnn_stage_text = run_text.split("def gnn_stage():", 1)[1].split("def load_gnn_scores", 1)[0]
    require(gnn_stage_text.index("model.load_state_dict") < gnn_stage_text.index("set_seed(init_seed)") and
            gnn_stage_text.index("set_seed(init_seed)") < gnn_stage_text.index("gnn_scores(model, calibration"),
            "the seed-42 predictor checkpoint is loaded before the run-level explainer RNG seed is set", checks)

    manifest = {line.split("  ", 1)[1]: line.split("  ", 1)[0]
                for line in (SOURCE_ROOT / "FULL_MANIFEST.sha256").read_text(encoding="utf-8").splitlines()
                if "  " in line}
    cached = pd.read_csv(HERE / "cached_variants.csv")
    ig = pd.read_csv(HERE / "ig_variants.csv")
    gnn = pd.read_csv(HERE / "gnn_initializations.csv")
    agreement = pd.read_csv(HERE / "gnn_set_agreement.csv")
    ties = pd.read_csv(HERE / "cached_tie_summary.csv")
    require(len(cached) == 88 and not cached.duplicated(["cell_id", "method", "transformation"]).any(),
            "cached score semantics contain one row for each of eight variants in 11 cells", checks)
    require(len(ig) == 66 and not ig.duplicated(["cell_id", "baseline", "steps"]).any(),
            "IG factorial contains one row for each of six conditions in 11 cells", checks)
    require(len(gnn) == 33 and not gnn.duplicated(["cell_id", "initialization_seed"]).any(),
            "GNNExplainer contains three run-level RNG seeds in each of 11 cells", checks)
    require(len(agreement) == 33 and not agreement.duplicated(["cell_id", "initialization_pair"]).any(),
            "GNNExplainer independently calibrated-set agreement contains all 33 cell-pair rows", checks)

    transforms = {
        ("gradinput", "signed"): lambda values: values,
        ("gradinput", "positive_part"): lambda values: np.maximum(values, 0),
        ("gradinput", "absolute"): np.abs,
        ("ig", "signed"): lambda values: values,
        ("ig", "positive_part"): lambda values: np.maximum(values, 0),
        ("ig", "absolute"): np.abs,
        ("atom_occlusion", "signed_decrease"): lambda values: values,
        ("atom_occlusion", "absolute_change"): np.abs,
    }
    metric_differences = []
    checkpoint_hashes = {}
    source_cache_hashes = {}
    generated_cache_hashes = {}
    generated_result_hashes = {}
    observed_labels = {}
    identity_audit = {}
    replay = []
    gnn_by_cell = {}
    tie_totals = {key: {"n_test": 0, "tie_expansion_molecules": 0,
                        "full_molecule_due_to_ties": 0, "inflation_weight": 0.0}
                  for key in transforms}
    for family, task in TASKS:
        cell_id = f"{family}__{task}__gin__seed42"
        checkpoint = CHECKPOINTS / f"{cell_id}.pt"
        checkpoint_hash = sha256(checkpoint)
        checkpoint_hashes[cell_id] = checkpoint_hash
        checkpoint_payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
        require({key: checkpoint_payload[key] for key in ["family", "task", "model", "seed"]} ==
                {"family": family, "task": task, "model": "gin", "seed": 42},
                f"{cell_id} checkpoint metadata bind family, task, model, and training seed 42", checks)
        source_path = SOURCE_CACHE / f"{cell_id}.npz"
        source_hash = sha256(source_path)
        source_cache_hashes[cell_id] = source_hash
        source_cell = json.loads((SOURCE_ROOT / "cells" / f"{cell_id}.json").read_text(encoding="utf-8"))
        require(source_cell["checkpoint_sha256"] == checkpoint_hash and
                source_cell["score_cache"]["sha256"] == source_hash and
                manifest[f"score_cache/{cell_id}.npz"] == source_hash,
                f"{cell_id} source cache and checkpoint match the frozen cell JSON and manifest", checks)
        ig_cell = json.loads((HERE / "ig_cells" / f"{cell_id}.json").read_text(encoding="utf-8"))
        generated_result_hashes[f"ig_cells/{cell_id}.json"] = sha256(HERE / "ig_cells" / f"{cell_id}.json")
        require(ig_cell["training_seed"] == 42 and ig_cell["checkpoint_sha256"] == checkpoint_hash,
                f"{cell_id} IG output remains bound to the seed-42 predictor checkpoint", checks)
        ig_cache_path = HERE / "ig_score_cache" / f"{cell_id}.npz"
        generated_cache_hashes[f"ig_score_cache/{cell_id}.npz"] = sha256(ig_cache_path)
        with np.load(source_path) as source, np.load(ig_cache_path) as ig_cache:
            calibration_indices = source["calibration__source_indices"].astype(int)
            test_indices = source["test__source_indices"].astype(int)
            require(len(np.unique(calibration_indices)) == len(calibration_indices) and
                    len(np.unique(test_indices)) == len(test_indices) and
                    not set(calibration_indices) & set(test_indices),
                    f"{cell_id} has unique, disjoint calibration and test source indices", checks)
            require(np.array_equal(ig_cache["calibration__source_indices"], calibration_indices) and
                    np.array_equal(ig_cache["test__source_indices"], test_indices),
                    f"{cell_id} IG cache preserves the frozen source-index order", checks)
            observed_labels[cell_id] = label_counts(family, task, calibration_indices, test_indices)
            identity_audit[cell_id] = molecule_identity(family, task, calibration_indices, test_indices)
            require(all(value == 0 for column in identity_audit[cell_id].values() for value in column.values()),
                    f"{cell_id} has no repeated molecule identifier or SMILES within or across calibration/test", checks)
            calibration_truths = source_truths(source, "calibration")
            test_truths = source_truths(source, "test")
            require(all(calibration_truths) and all(test_truths),
                    f"{cell_id} CRC denominators are non-empty rationale atom counts", checks)
            for (method, transformation), transform in transforms.items():
                calibration_scores = [transform(row) for row in source_rows(
                    source, "calibration", f"{method}__calibration__score_values")]
                test_scores = [transform(row) for row in source_rows(
                    source, "test", f"{method}__test__score_values")]
                result = recalculate(calibration_scores, calibration_truths, test_scores, test_truths)
                row = cached[(cached.cell_id == cell_id) & (cached.method == method) &
                             (cached.transformation == transformation)].iloc[0]
                assert_metrics(row, result, "selected_fraction", "retained_fraction", metric_differences)
                tie_result = tie_stats(test_scores, result["fraction"])
                metric_differences.extend(abs(float(row[column]) - tie_result[column]) for column in [
                    "test_tie_expansion_rate", "test_mean_tie_inflation", "test_max_tie_inflation",
                    "test_mean_realized_fraction_from_scores", "test_full_molecule_due_to_ties"])
                total = tie_totals[(method, transformation)]
                total["n_test"] += tie_result["n_test"]
                total["tie_expansion_molecules"] += tie_result["tie_expansion_molecules"]
                total["full_molecule_due_to_ties"] += tie_result["test_full_molecule_due_to_ties"]
                total["inflation_weight"] += tie_result["test_mean_tie_inflation"] * tie_result["n_test"]
                require(row.source_cache_sha256 == source_hash,
                        f"{cell_id} {method}/{transformation} row binds the frozen score cache", checks)
            for baseline in ["zero", "fit_atom_mean"]:
                for steps in [20, 50, 100]:
                    name = f"{baseline}_{steps}"
                    calibration_scores = ragged(ig_cache[f"{name}__calibration__offsets"],
                                                ig_cache[f"{name}__calibration__scores"])
                    test_scores = ragged(ig_cache[f"{name}__test__offsets"],
                                         ig_cache[f"{name}__test__scores"])
                    require(np.array_equal(ig_cache[f"{name}__calibration__offsets"], source["calibration__offsets"]) and
                            np.array_equal(ig_cache[f"{name}__test__offsets"], source["test__offsets"]),
                            f"{cell_id} {name} score rows align with frozen molecule boundaries", checks)
                    result = recalculate(calibration_scores, calibration_truths, test_scores, test_truths)
                    row = ig[(ig.cell_id == cell_id) & (ig.baseline == baseline) & (ig.steps == steps)].iloc[0]
                    assert_metrics(row, result, "fraction", "mean_atom_fraction", metric_differences)
                    cell_value = ig_cell["variants"][name]
                    metric_differences.extend(abs(float(cell_value[column]) - float(row[column])) for column in [
                        "fraction", "empirical_risk", "corrected_risk", "risk", "mean_atom_fraction",
                        "precision", "iou", "test_completeness_mean", "test_completeness_max"])
            old_calibration = source_rows(source, "calibration", "ig__calibration__score_values")
            old_test = source_rows(source, "test", "ig__test__score_values")
            new_calibration = ragged(ig_cache["zero_20__calibration__offsets"],
                                     ig_cache["zero_20__calibration__scores"])
            new_test = ragged(ig_cache["zero_20__test__offsets"], ig_cache["zero_20__test__scores"])
            old_result = recalculate(old_calibration, calibration_truths, old_test, test_truths)
            new_result = recalculate(new_calibration, calibration_truths, new_test, test_truths)
            set_jaccard = [len(first & second) / len(first | second) if first | second else 1.0
                           for first, second in zip(old_result["sets"], new_result["sets"])]
            replay.append({
                "cell_id": cell_id, "old_fraction": old_result["fraction"],
                "rerun_fraction": new_result["fraction"], "old_risk": old_result["risk"],
                "rerun_risk": new_result["risk"],
                "calibration_score_spearman": float(spearmanr(np.concatenate(old_calibration),
                                                               np.concatenate(new_calibration)).statistic),
                "test_score_spearman": float(spearmanr(np.concatenate(old_test),
                                                        np.concatenate(new_test)).statistic),
                "mean_test_set_jaccard": float(np.mean(set_jaccard)),
                "max_abs_test_score_difference": float(np.max(np.abs(np.concatenate(old_test) -
                                                                      np.concatenate(new_test)))),
            })
            gnn_by_cell[cell_id] = {}
            for initialization_seed in [42, 123, 2026]:
                if initialization_seed == 42:
                    calibration_scores = source_rows(source, "calibration", "gnnexplainer__calibration__score_values", 25)
                    test_scores = source_rows(source, "test", "gnnexplainer__test__score_values", 25)
                else:
                    gnn_cache_path = HERE / "gnn_score_cache" / f"{cell_id}__init{initialization_seed}.npz"
                    generated_cache_hashes[f"gnn_score_cache/{cell_id}__init{initialization_seed}.npz"] = sha256(gnn_cache_path)
                    gnn_cell = json.loads((HERE / "gnn_cells" / f"{cell_id}__init{initialization_seed}.json").read_text(encoding="utf-8"))
                    generated_result_hashes[f"gnn_cells/{cell_id}__init{initialization_seed}.json"] = sha256(
                        HERE / "gnn_cells" / f"{cell_id}__init{initialization_seed}.json")
                    require(gnn_cell["training_seed"] == 42 and
                            gnn_cell["initialization_seed"] == initialization_seed and
                            gnn_cell["checkpoint_sha256"] == checkpoint_hash,
                            f"{cell_id} GNNExplainer RNG seed {initialization_seed} keeps the seed-42 checkpoint", checks)
                    with np.load(gnn_cache_path) as new_cache:
                        require(np.array_equal(new_cache["calibration__source_indices"], calibration_indices[:25]) and
                                np.array_equal(new_cache["test__source_indices"], test_indices[:25]),
                                f"{cell_id} GNNExplainer RNG seed {initialization_seed} preserves the first-25 source order", checks)
                        calibration_scores = ragged(new_cache["calibration__offsets"], new_cache["calibration__scores"])
                        test_scores = ragged(new_cache["test__offsets"], new_cache["test__scores"])
                result = recalculate(calibration_scores, calibration_truths[:25], test_scores, test_truths[:25])
                row = gnn[(gnn.cell_id == cell_id) &
                          (gnn.initialization_seed == initialization_seed)].iloc[0]
                assert_metrics(row, result, "fraction", "mean_atom_fraction", metric_differences)
                if initialization_seed != 42:
                    metric_differences.extend(abs(float(gnn_cell["metrics"][column]) - float(row[column]))
                                              for column in ["fraction", "empirical_risk", "corrected_risk",
                                                             "risk", "mean_atom_fraction", "precision", "iou"])
                gnn_by_cell[cell_id][initialization_seed] = (test_scores, result["fraction"])

    require(max(metric_differences) < 1e-12,
            "independent tie-inclusive CRC and test-metric reconstruction matches all 187 result rows", checks)
    tie_differences = []
    for (method, transformation), total in tie_totals.items():
        row = ties[(ties.method == method) & (ties.transformation == transformation)].iloc[0]
        expected = {
            "n_test": total["n_test"],
            "tie_expansion_molecules": total["tie_expansion_molecules"],
            "full_molecule_due_to_ties": total["full_molecule_due_to_ties"],
            "tie_expansion_fraction": total["tie_expansion_molecules"] / total["n_test"],
            "weighted_mean_tie_inflation": total["inflation_weight"] / total["n_test"],
        }
        tie_differences.extend(abs(float(row[column]) - value) for column, value in expected.items())
    require(max(tie_differences) < 1e-12,
            "all eight exact-boundary tie summaries reconstruct from molecule-level score rows", checks)
    agreement_differences = []
    for cell_id, by_seed in gnn_by_cell.items():
        for first, second in [(42, 123), (42, 2026), (123, 2026)]:
            values = []
            for first_scores, second_scores in zip(by_seed[first][0], by_seed[second][0]):
                first_set = top_set(first_scores, by_seed[first][1])
                second_set = top_set(second_scores, by_seed[second][1])
                values.append(len(first_set & second_set) / len(first_set | second_set)
                              if first_set | second_set else 1.0)
            row = agreement[(agreement.cell_id == cell_id) &
                            (agreement.initialization_pair == f"{first}-{second}")].iloc[0]
            agreement_differences.extend([abs(float(row.mean_set_jaccard) - np.mean(values)),
                                          abs(float(row.median_set_jaccard) - np.median(values))])
    require(max(agreement_differences) < 1e-12,
            "independent GNNExplainer set reconstruction matches all pairwise Jaccard summaries", checks)

    cached_macro_columns = ["risk", "retained_fraction", "precision", "iou",
                            "test_tie_expansion_rate", "test_mean_tie_inflation",
                            "test_max_tie_inflation", "test_mean_realized_fraction_from_scores",
                            "test_full_molecule_due_to_ties"]
    cached_macro = cached.groupby(["method", "transformation"], as_index=False)[cached_macro_columns].mean()
    ig_macro = ig.groupby(["baseline", "steps"], as_index=False).agg(
        risk=("risk", "mean"), mean_atom_fraction=("mean_atom_fraction", "mean"),
        precision=("precision", "mean"), iou=("iou", "mean"),
        test_completeness_task_macro_mean=("test_completeness_mean", "mean"),
        test_completeness_cell_max_mean=("test_completeness_max", "mean"))
    gnn_macro = gnn.groupby("initialization_seed", as_index=False)[
        ["risk", "mean_atom_fraction", "precision", "iou"]].mean()
    variability = gnn.groupby(["family", "task"]).agg(
        risk_sd=("risk", "std"), risk_range=("risk", lambda values: values.max() - values.min()),
        retained_fraction_sd=("mean_atom_fraction", "std"),
        retained_fraction_range=("mean_atom_fraction", lambda values: values.max() - values.min()),
        iou_sd=("iou", "std"), iou_range=("iou", lambda values: values.max() - values.min())).reset_index()
    macro_differences = [
        frame_max_difference(cached_macro, pd.read_csv(HERE / "cached_variant_macro.csv"),
                             ["method", "transformation"]),
        frame_max_difference(ig_macro, pd.read_csv(HERE / "ig_variant_macro.csv"), ["baseline", "steps"]),
        frame_max_difference(gnn_macro, pd.read_csv(HERE / "gnn_initialization_macro.csv"),
                             ["initialization_seed"]),
        frame_max_difference(variability, pd.read_csv(HERE / "gnn_initialization_variability.csv"),
                             ["family", "task"]),
    ]
    require(max(macro_differences) < 1e-12,
            "all task-macro and within-cell variability tables reconstruct from cell-level CSV rows", checks)

    pooled = pd.read_csv(HERE / "ig_completeness_pooled.csv")
    monotonicity = pd.read_csv(HERE / "ig_completeness_monotonicity.csv")
    pooled_differences = []
    for baseline in ["zero", "fit_atom_mean"]:
        by_step = {steps: [] for steps in [20, 50, 100]}
        for family, task in TASKS:
            cell_id = f"{family}__{task}__gin__seed42"
            with np.load(HERE / "ig_score_cache" / f"{cell_id}.npz") as cache:
                for steps in by_step:
                    by_step[steps].append(cache[f"{baseline}_{steps}__test__completeness"].astype(float))
        for steps, arrays in by_step.items():
            values = np.concatenate(arrays)
            row = pooled[(pooled.baseline == baseline) & (pooled.steps == steps)].iloc[0]
            pooled_differences.extend([abs(int(row.n_test) - len(values)),
                                       abs(row.test_completeness_pooled_mean - values.mean()),
                                       abs(row.test_completeness_pooled_median - np.median(values)),
                                       abs(row.test_completeness_pooled_max - values.max())])
        count = int(sum(np.sum((middle <= first) & (last <= middle))
                        for first, middle, last in zip(by_step[20], by_step[50], by_step[100])))
        row = monotonicity[monotonicity.baseline == baseline].iloc[0]
        pooled_differences.extend([abs(int(row.n_monotonic_20_to_50_to_100) - count),
                                   abs(row.fraction_monotonic_20_to_50_to_100 - count / int(row.n_test))])
    require(max(pooled_differences) < 1e-12,
            "pooled IG completeness maxima and molecule-level monotonicity are reconstructed from raw caches", checks)

    positive_ties = {method: ties[(ties.method == method) &
                                  (ties.transformation == "positive_part")].iloc[0].to_dict()
                     for method in ["gradinput", "ig"]}
    require(int(positive_ties["gradinput"]["tie_expansion_molecules"]) == 601 and
            int(positive_ties["gradinput"]["full_molecule_due_to_ties"]) == 556 and
            int(positive_ties["ig"]["tie_expansion_molecules"]) == 489 and
            int(positive_ties["ig"]["full_molecule_due_to_ties"]) == 421,
            "positive-part exact-tie expansion is retained explicitly rather than hidden in nominal fractions", checks)

    fraction_changes = sum(row["old_fraction"] != row["rerun_fraction"] for row in replay)
    risk_changes = sum(abs(row["old_risk"] - row["rerun_risk"]) > 1e-12 for row in replay)
    require(min(row["test_score_spearman"] for row in replay) > 0.999 and
            fraction_changes == 1 and risk_changes == 3,
            "zero-baseline 20-step IG is recorded as near-identical score ordering but non-exact set replay", checks)
    require(set(gnn.initialization_seed) == {42, 123, 2026} and
            set(gnn[gnn.initialization_seed == 42].origin) == {"frozen_cache"} and
            set(gnn[gnn.initialization_seed != 42].origin) == {"new_run"},
            "training seed 42 and run-level explainer RNG seeds 42/123/2026 remain distinct in metadata", checks)
    environment = json.loads((HERE / "environment.json").read_text(encoding="utf-8"))
    require(environment["script_sha256"] == sha256(HERE / "run_score_semantics.py") and
            environment["contract_sha256"] == sha256(HERE / "run_contract.json"),
            "environment metadata bind the current aggregation script and frozen run contract", checks)
    summary_path = HERE / "summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    summary_differences = [
        frame_max_difference(cached_macro, pd.DataFrame(summary["cached_variant_macro"]),
                             ["method", "transformation"]),
        frame_max_difference(ig_macro, pd.DataFrame(summary["ig_variant_macro"]), ["baseline", "steps"]),
        frame_max_difference(gnn_macro, pd.DataFrame(summary["gnn_initialization_macro"]),
                             ["initialization_seed"]),
        frame_max_difference(pooled, pd.DataFrame(summary["ig_completeness_pooled"]),
                             ["baseline", "steps"]),
        frame_max_difference(monotonicity, pd.DataFrame(summary["ig_completeness_monotonicity"]),
                             ["baseline"]),
        abs(float(summary["gnn_set_agreement_mean"]) - float(agreement.mean_set_jaccard.mean())),
    ]
    summary_differences.extend(abs(float(summary["gnn_variability_mean"][column]) -
                                   float(variability[column].mean()))
                               for column in ["risk_sd", "risk_range", "retained_fraction_sd",
                                              "retained_fraction_range", "iou_sd", "iou_range"])
    require(max(summary_differences) < 1e-12,
            "summary JSON reconstructs from the validated task-level and pooled tables", checks)

    report = {
        "status": "PASS",
        "checks": checks,
        "target": {"semantics": "dataset ground-truth class logit, not predicted class",
                   "observed_label_counts": observed_labels},
        "molecule_identity_audit": identity_audit,
        "independent_recalculation": {
            "result_rows": 187, "max_absolute_metric_difference": max(metric_differences),
            "max_absolute_set_agreement_difference": max(agreement_differences),
            "selector": "corrected CRC at alpha 0.10 with all exact kth-boundary ties included",
            "risk_denominator": "rationale atom count within each molecule; molecules averaged within each cell"},
        "ig_zero20_cache_replay": {
            "cells": replay, "fraction_change_cells": fraction_changes, "risk_change_cells": risk_changes,
            "task_macro_risk_difference_rerun_minus_cache": float(np.mean([row["rerun_risk"] - row["old_risk"] for row in replay])),
            "minimum_test_score_spearman": min(row["test_score_spearman"] for row in replay),
            "task_macro_mean_test_set_jaccard": float(np.mean([row["mean_test_set_jaccard"] for row in replay]))},
        "positive_part_exact_ties": positive_ties,
        "ig_completeness": {"pooled": pooled.to_dict("records"),
                            "monotonicity": monotonicity.to_dict("records"),
                            "warning": "task-macro mean of within-cell maxima is not a pooled global maximum"},
        "hashes": {"checkpoints": checkpoint_hashes, "frozen_source_caches": source_cache_hashes,
                   "generated_score_caches": generated_cache_hashes,
                   "generated_result_json": generated_result_hashes,
                   "run_contract": sha256(HERE / "run_contract.json"),
                   "contract_amendment": sha256(HERE / "contract_amendment_001.json"),
                   "current_analysis_script": sha256(HERE / "run_score_semantics.py")},
        "claim_update": "Observed risk-size and localization summaries vary with score semantics, IG baseline/integration settings, and run-level GNNExplainer RNG seed on this frozen slice; no effect-size threshold or population-level inference was prespecified.",
        "writeback_boundary": "Retrospective, descriptive sensitivity on 11 observed GIN training-seed-42 task cells. Positive-part results include tie-policy effects; GNN set agreement compares independently calibrated sets; no per-molecule reseeding, bitwise-reproducibility, universal ranking, or chemical-validity claim."
    }
    (HERE / "validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (HERE / "validation.md").write_text(
        "# Score-semantics validation\n\n**PASS**\n\n" +
        "\n".join(f"- {item}" for item in checks) +
        "\n\nThe PASS applies to numerical and provenance reconstruction on the frozen slice. "
        "It does not remove the reporting boundaries recorded in `validation.json`.\n", encoding="utf-8")
    summary["status"] = "complete_validated"
    summary["validation_boundary"] = report["writeback_boundary"]
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({"status": "PASS", "n_checks": len(checks),
                      "max_metric_difference": max(metric_differences)}, indent=2))


if __name__ == "__main__":
    main()
