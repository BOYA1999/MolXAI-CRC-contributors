import torch

import argparse
import hashlib
import json
import math
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from rdkit import Chem, RDLogger, rdBase
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    precision_score,
    recall_score,
    roc_auc_score,
)
from torch import nn
from torch.nn import functional as F
from torch_geometric.data import Batch, Data
from torch_geometric.nn import GCNConv, global_mean_pool


HERE = Path(__file__).resolve().parent
INPUTS = HERE / "inputs"
OUTPUTS = HERE / "outputs"
FRACTIONS = np.linspace(0.0, 1.0, 101)
ALPHA = 0.10
SALT = "molxai-crc-k4_2ar-v1"
RDLogger.DisableLog("rdApp.*")


class GCN(nn.Module):
    def __init__(self, input_dim, model_dim, n_layers, concat_conv_layers, dropout_rate, fc_hidden_dim, num_fc_layers, use_hooks=False):
        super().__init__()
        self.conv_layers = nn.ModuleList([GCNConv(input_dim, model_dim)])
        self.conv_layers.extend(GCNConv(model_dim, model_dim) for _ in range(1, n_layers))
        self.concat_conv_layers = bool(concat_conv_layers)
        self.use_hooks = use_hooks
        self.final_conv_acts = None
        self.final_conv_grads = None
        fc_input_dim = model_dim * n_layers if self.concat_conv_layers else model_dim
        layers = []
        for _ in range(num_fc_layers):
            layers.extend([nn.Linear(fc_input_dim, fc_hidden_dim), nn.ReLU(), nn.Dropout(dropout_rate)])
            fc_input_dim = fc_hidden_dim
        self.fc_stack = nn.Sequential(*layers)
        self.fc_output = nn.Linear(fc_hidden_dim, 1)
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, data):
        x = data.x
        outputs = []
        for conv in self.conv_layers:
            x = F.relu(conv(x, data.edge_index))
            x = self.dropout(x)
            outputs.append(x)
        combined = torch.cat(outputs, dim=1) if self.concat_conv_layers else x
        if self.use_hooks:
            self.final_conv_acts = combined
            if combined.requires_grad:
                combined.register_hook(self._save_grads)
        pooled = global_mean_pool(combined, data.batch)
        return self.fc_output(self.fc_stack(self.dropout(pooled)))

    def _save_grads(self, grad):
        self.final_conv_grads = grad


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, payload):
    path.write_text(json.dumps(payload, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")


def one_hot(value, values, default=None):
    if value not in values:
        if default is None:
            raise ValueError(f"unsupported value {value}")
        value = default
    return [value == item for item in values]


def atom_features(atom):
    elements = ["Br", "C", "Cl", "F", "H", "I", "N", "O", "P", "S", "Unknown"]
    hybrids = [
        Chem.rdchem.HybridizationType.SP,
        Chem.rdchem.HybridizationType.SP2,
        Chem.rdchem.HybridizationType.SP3,
        Chem.rdchem.HybridizationType.SP3D,
        Chem.rdchem.HybridizationType.SP3D2,
    ]
    values = []
    values += one_hot(atom.GetSymbol(), elements, "Unknown")
    values += one_hot(atom.GetDegree(), list(range(11)))
    values += one_hot(atom.GetImplicitValence(), list(range(7)), 6)
    values += [atom.GetFormalCharge(), atom.GetNumRadicalElectrons()]
    values += one_hot(atom.GetHybridization(), hybrids, Chem.rdchem.HybridizationType.SP3D2)
    values += [atom.GetIsAromatic()]
    values += one_hot(atom.GetTotalNumHs(), [0, 1, 2, 3, 4], 4)
    if len(values) != 42:
        raise RuntimeError(f"atom feature width {len(values)} != 42")
    return values


def graph_from_smiles(smiles, identifier=None, label=None):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, None
    edges = []
    for bond in mol.GetBonds():
        i, j = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
        edges.extend([[i, j], [j, i]])
    edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous() if edges else torch.empty((2, 0), dtype=torch.long)
    x = torch.tensor([atom_features(atom) for atom in mol.GetAtoms()], dtype=torch.float32)
    data = Data(x=x, edge_index=edge_index)
    if identifier is not None:
        data.id = str(identifier)
    if label is not None:
        data.y = torch.tensor([float(label)], dtype=torch.float32)
    return data, mol


def load_model(use_hooks=False, device="cpu"):
    checkpoint = torch.load(INPUTS / "best_model_gcn_split_close_set.pth", map_location="cpu", weights_only=False)
    hp = checkpoint["hyperparams"]
    model = GCN(
        input_dim=42,
        model_dim=hp["model_dim"],
        n_layers=hp["n_layers"],
        concat_conv_layers=hp.get("concat_conv_layers", 1),
        dropout_rate=hp["dropout_rate"],
        fc_hidden_dim=hp["fc_hidden_dim"],
        num_fc_layers=hp["num_fc_layers"],
        use_hooks=use_hooks,
    ).to(device)
    model.load_state_dict(checkpoint["state_dict"], strict=True)
    model.eval()
    return model, hp


def input_manifest():
    expected = {
        "k4_2ar_split.parquet": (531373003, "42e27f2ef90e36c636018a300984f1fca09889951483236dba1f17c8dce06db7"),
        "k4_2ar_labels.parquet": (18366664, "2b8e6cb4bfdaa8c180695d6df405c8dde8c3c25cdeda52481fb03f0ad45114cb"),
        "best_model_gcn_split_close_set.pth": (2982101, "1548a2942559b3c4705f95b510cc3dba30d23107e7f8d4ef1a76c04ad23b9c4b"),
    }
    rows = []
    for name, (size, digest) in expected.items():
        path = INPUTS / name
        actual_size = path.stat().st_size
        actual_digest = sha256_file(path)
        rows.append({"file": name, "bytes": actual_size, "sha256": actual_digest, "pass": actual_size == size and actual_digest == digest})
    if not all(row["pass"] for row in rows):
        raise RuntimeError("input hash or size mismatch")
    return rows


def run_audit():
    manifest = input_manifest()
    split_path = INPUTS / "k4_2ar_split.parquet"
    labels_path = INPUTS / "k4_2ar_labels.parquet"
    split_pf = pq.ParquetFile(split_path)
    labels_pf = pq.ParquetFile(labels_path)
    split = pq.read_table(split_path, columns=["ID", "smiles", "y", "split", "split_close_set"]).to_pandas()
    labels = pq.read_table(labels_path, columns=["ID", "y", "y_true"]).to_pandas()
    duplicate_mask = split.duplicated("ID", keep=False)
    duplicate_rows = split.loc[duplicate_mask]
    duplicate_nunique = duplicate_rows.groupby("ID", sort=False)[["smiles", "y", "split", "split_close_set"]].nunique(dropna=False)
    conflicting_smiles_ids = int(duplicate_nunique["smiles"].gt(1).sum())
    conflicting_label_ids = int(duplicate_nunique["y"].gt(1).sum())
    cross_base_split_ids = int(duplicate_nunique["split"].gt(1).sum())
    conflicting_close_ids = set(duplicate_nunique.index[duplicate_nunique["split_close_set"].gt(1)])
    positive_ids = set(labels.ID)
    positive_conflicting_close_ids = len(conflicting_close_ids & positive_ids)
    unique_split = split.drop_duplicates("ID", keep="first")
    joined = labels[["ID"]].merge(unique_split[["ID", "split", "split_close_set"]], on="ID", how="left", validate="one_to_one")
    smiles_contract = split.groupby("smiles", sort=False).agg(n_ids=("ID", "nunique"), n_base_splits=("split", "nunique"), n_labels=("y", "nunique"))
    exact_smiles_cross_base_split = int(smiles_contract.n_base_splits.gt(1).sum())
    exact_smiles_conflicting_y = int(smiles_contract.n_labels.gt(1).sum())
    checkpoint = torch.load(INPUTS / "best_model_gcn_split_close_set.pth", map_location="cpu", weights_only=False)
    state_shapes = {key: list(value.shape) for key, value in checkpoint["state_dict"].items()}
    payload = {
        "status": "PASS",
        "inputs": manifest,
        "split_schema": str(split_pf.schema_arrow),
        "label_schema": str(labels_pf.schema_arrow),
        "split_rows": int(len(split)),
        "split_unique_ids": int(split.ID.nunique()),
        "duplicate_rows_after_first": int(split.duplicated("ID").sum()),
        "duplicate_ids_with_conflicting_smiles": conflicting_smiles_ids,
        "duplicate_ids_with_conflicting_y": conflicting_label_ids,
        "duplicate_ids_crossing_base_split": cross_base_split_ids,
        "duplicate_ids_with_conflicting_close_membership": int(len(conflicting_close_ids)),
        "positive_reference_ids_with_conflicting_close_membership": int(positive_conflicting_close_ids),
        "unique_exact_smiles": int(len(smiles_contract)),
        "exact_smiles_crossing_base_split": exact_smiles_cross_base_split,
        "exact_smiles_with_conflicting_y_within_one_split": exact_smiles_conflicting_y,
        "exact_smiles_with_multiple_ids": int(smiles_contract.n_ids.gt(1).sum()),
        "base_split_counts": {f"{s}|y={int(y)}": int(n) for (s, y), n in split.groupby(["split", "y"], dropna=False).size().items()},
        "close_split_counts": {f"{s}|y={int(y)}": int(n) for (s, y), n in split.groupby(["split_close_set", "y"], dropna=False).size().items()},
        "official_test_rows_including_frozen_duplicates": int((split["split"] == "test").sum()),
        "positive_label_rows": int(len(labels)),
        "positive_label_unique_ids": int(labels.ID.nunique()),
        "positive_label_y_values": sorted(int(value) for value in labels.y.unique()),
        "positive_labels_missing_split": int(joined["split"].isna().sum()),
        "positive_unique_counts_by_base_split": {str(k): int(v) for k, v in joined.groupby("split").size().items()},
        "reference_length": {key: float(value) for key, value in labels.y_true.map(len).describe().items()},
        "reference_positive_atoms": {key: float(value) for key, value in labels.y_true.map(np.sum).describe().items()},
        "checkpoint_hyperparams": checkpoint["hyperparams"],
        "checkpoint_state_shapes": state_shapes,
    }
    if conflicting_smiles_ids or conflicting_label_ids or cross_base_split_ids or positive_conflicting_close_ids or exact_smiles_cross_base_split or joined["split"].isna().any() or labels.ID.duplicated().any() or set(labels.y) != {1}:
        payload["status"] = "FAIL"
    write_json(OUTPUTS / "data_and_checkpoint_audit.json", payload)
    if payload["status"] != "PASS":
        raise RuntimeError("data/checkpoint audit failed")
    print(json.dumps({key: payload[key] for key in ["status", "split_rows", "official_test_rows_including_frozen_duplicates", "positive_unique_counts_by_base_split"]}, indent=2))


def prediction_metrics(frame):
    y = frame["y"].to_numpy(int)
    p = frame["probability"].to_numpy(float)
    hard = (p >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, hard, labels=[0, 1]).ravel()
    return {
        "n": int(len(frame)),
        "n_negative": int((y == 0).sum()),
        "n_positive": int((y == 1).sum()),
        "roc_auc": float(roc_auc_score(y, p)),
        "average_precision": float(average_precision_score(y, p)),
        "accuracy_at_0_5": float(accuracy_score(y, hard)),
        "balanced_accuracy_at_0_5": float(balanced_accuracy_score(y, hard)),
        "precision_at_0_5": float(precision_score(y, hard, zero_division=0)),
        "recall_at_0_5": float(recall_score(y, hard, zero_division=0)),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }


def run_predictor(batch_size):
    input_manifest()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model, hp = load_model(False, device)
    parquet = pq.ParquetFile(INPUTS / "k4_2ar_split.parquet")
    output_rows = []
    source_offset = 0
    processed = 0
    invalid = []
    started = time.time()
    for record_batch in parquet.iter_batches(batch_size=8192, columns=["ID", "smiles", "y", "split"]):
        frame = record_batch.to_pandas()
        frame["source_row_index"] = np.arange(source_offset, source_offset + len(frame), dtype=np.int64)
        source_offset += len(frame)
        frame = frame.loc[frame["split"] == "test"]
        graphs, metadata = [], []
        for row in frame.itertuples(index=False):
            graph, _ = graph_from_smiles(row.smiles, row.ID, row.y)
            if graph is None:
                invalid.append({"source_row_index": int(row.source_row_index), "ID": str(row.ID)})
                continue
            graphs.append(graph)
            metadata.append(row)
            if len(graphs) == batch_size:
                batch = Batch.from_data_list(graphs).to(device)
                with torch.no_grad():
                    probs = torch.sigmoid(model(batch).view(-1)).cpu().numpy()
                output_rows.extend({"source_row_index": int(meta.source_row_index), "ID": str(meta.ID), "y": int(meta.y), "probability": float(prob)} for meta, prob in zip(metadata, probs))
                processed += len(graphs)
                graphs, metadata = [], []
        if graphs:
            batch = Batch.from_data_list(graphs).to(device)
            with torch.no_grad():
                probs = torch.sigmoid(model(batch).view(-1)).cpu().numpy()
            output_rows.extend({"source_row_index": int(meta.source_row_index), "ID": str(meta.ID), "y": int(meta.y), "probability": float(prob)} for meta, prob in zip(metadata, probs))
            processed += len(graphs)
        if processed and processed % 20000 < 8192:
            print(f"predictor processed={processed} elapsed_s={time.time() - started:.1f}", flush=True)
    predictions = pd.DataFrame(output_rows).sort_values("source_row_index").reset_index(drop=True)
    predictions.to_parquet(OUTPUTS / "predictor_predictions.parquet", index=False)
    metrics = prediction_metrics(predictions)
    unique_metrics = prediction_metrics(predictions.drop_duplicates("ID", keep="first"))
    metrics.update({
        "status": "PASS" if not invalid and metrics["n"] == 354570 else "FAIL",
        "invalid_smiles": invalid,
        "device": str(device),
        "checkpoint_hyperparams": hp,
        "elapsed_seconds": float(time.time() - started),
        "source_reported_rounded_roc_auc": 0.900,
        "absolute_difference_from_source_rounded": abs(metrics["roc_auc"] - 0.900),
        "unique_id_sensitivity": unique_metrics,
        "unique_id_sensitivity_note": "first source-row occurrence per official-test ID; sensitivity only",
    })
    write_json(OUTPUTS / "predictor_metrics.json", metrics)
    if metrics["status"] != "PASS":
        raise RuntimeError("official test prediction coverage failed")
    print(json.dumps(metrics, indent=2))


def selection_hash(identifier):
    return hashlib.sha256(f"{identifier}|{SALT}".encode()).hexdigest()


def eligible_positive_rows():
    labels = pq.read_table(INPUTS / "k4_2ar_labels.parquet").to_pandas()
    split = pq.read_table(INPUTS / "k4_2ar_split.parquet", columns=["ID", "split", "split_close_set"]).to_pandas()
    split = split.drop_duplicates("ID", keep="first")
    joined = labels.merge(split, on="ID", how="left", validate="one_to_one")
    selected = []
    eligibility = {"parsed": 0, "atom_count_match": 0, "binary_nonconstant_reference": 0, "eligible": 0}
    for row in joined.loc[joined["split"].isin(["val", "test"])].itertuples(index=False):
        mol = Chem.MolFromSmiles(row.smiles)
        if mol is None:
            continue
        eligibility["parsed"] += 1
        truth = np.asarray(row.y_true, dtype=np.int8)
        atom_match = len(truth) == mol.GetNumAtoms()
        binary_nonconstant = set(truth.tolist()) == {0, 1}
        eligibility["atom_count_match"] += int(atom_match)
        eligibility["binary_nonconstant_reference"] += int(binary_nonconstant)
        if atom_match and binary_nonconstant:
            eligibility["eligible"] += 1
            selected.append(row)
    eligible = pd.DataFrame(selected, columns=joined.columns)
    return eligible, eligibility


def freeze_slice():
    eligible, audit = eligible_positive_rows()
    rows = []
    for split_name in ["val", "test"]:
        pool = eligible.loc[eligible["split"] == split_name].copy()
        pool["selection_hash"] = pool.ID.map(selection_hash)
        pool = pool.sort_values(["selection_hash", "ID"], kind="stable").head(512)
        if len(pool) != 512:
            raise RuntimeError(f"fewer than 512 eligible {split_name} positives")
        for rank, row in enumerate(pool.itertuples(index=False), start=1):
            truth = np.asarray(row.y_true, dtype=np.int8)
            rows.append({
                "split": split_name,
                "selection_rank": rank,
                "selection_hash": row.selection_hash,
                "ID": str(row.ID),
                "n_atoms": int(len(truth)),
                "reference_atoms": int(truth.sum()),
                "reference_fraction": float(truth.mean()),
            })
    frame = pd.DataFrame(rows)
    frame.to_parquet(OUTPUTS / "selected_slice.parquet", index=False)
    audit.update({
        "eligible_by_split": {str(k): int(v) for k, v in eligible.groupby("split").size().items()},
        "selected_by_split": {str(k): int(v) for k, v in frame.groupby("split").size().items()},
        "selected_reference_fraction_mean": float(frame.reference_fraction.mean()),
        "selected_reference_fraction_range": [float(frame.reference_fraction.min()), float(frame.reference_fraction.max())],
    })
    write_json(OUTPUTS / "slice_audit.json", audit)
    return eligible, frame


def attribute_batch(model, graphs, device):
    batch = Batch.from_data_list(graphs).to(device)
    model.zero_grad(set_to_none=True)
    logits = model(batch).view(-1)
    logits.sum().backward()
    gradcam = (model.final_conv_grads * model.final_conv_acts).sum(dim=1).detach().cpu().numpy()
    probs = torch.sigmoid(logits.detach()).cpu().numpy()
    grad_batch = Batch.from_data_list(graphs).to(device)
    grad_batch.x = grad_batch.x.clone().detach().requires_grad_(True)
    model.zero_grad(set_to_none=True)
    vg_logits = model(grad_batch).view(-1)
    vg_logits.sum().backward()
    vanilla = torch.linalg.norm(grad_batch.x.grad, dim=1).detach().cpu().numpy()
    ptr = batch.ptr.detach().cpu().numpy()
    return [(gradcam[ptr[i]:ptr[i + 1]], vanilla[ptr[i]:ptr[i + 1]], float(probs[i])) for i in range(len(graphs))]


def random_scores(identifier, n_atoms):
    values = []
    for atom_index in range(n_atoms):
        digest = hashlib.sha256(f"{identifier}|{atom_index}|{SALT}|random".encode()).digest()
        values.append(int.from_bytes(digest[:8], "big") / 2**64)
    return np.asarray(values, dtype=float)


def top_fraction(scores, fraction):
    scores = np.asarray(scores, dtype=float)
    n = len(scores)
    k = min(n, max(0, int(math.ceil(fraction * n))))
    selected = np.zeros(n, dtype=bool)
    if k:
        order = np.argsort(-scores, kind="stable")
        threshold = scores[order[k - 1]]
        selected = scores >= threshold
    return selected, k


def set_values(selected, truth):
    truth = np.asarray(truth, dtype=bool)
    intersection = int(np.logical_and(selected, truth).sum())
    selected_n = int(selected.sum())
    truth_n = int(truth.sum())
    union = int(np.logical_or(selected, truth).sum())
    return {
        "risk": float(1.0 - intersection / truth_n),
        "retained_fraction": float(selected_n / len(truth)),
        "precision": float(intersection / selected_n) if selected_n else 0.0,
        "iou": float(intersection / union) if union else 0.0,
        "selected_atoms": selected_n,
    }


def score_map(row):
    truth = np.asarray(row.y_true, dtype=np.int8)
    return {
        "gradcam": np.asarray(row.gradcam, dtype=float),
        "vanilla_gradient": np.asarray(row.vanilla_gradient, dtype=float),
        "oracle": truth.astype(float),
        "random": random_scores(row.ID, len(truth)),
    }, truth


def calibrate(attributions, method):
    losses = []
    realized = []
    for row in attributions.itertuples(index=False):
        scores, truth = score_map(row)
        method_losses, method_realized = [], []
        for fraction in FRACTIONS:
            selected, nominal_count = top_fraction(scores[method], fraction)
            values = set_values(selected, truth)
            method_losses.append(values["risk"])
            method_realized.append(values["retained_fraction"] - nominal_count / len(truth))
        losses.append(method_losses)
        realized.append(method_realized)
    losses = np.asarray(losses)
    corrected = (len(losses) * losses.mean(axis=0) + 1.0) / (len(losses) + 1)
    feasible = np.flatnonzero(corrected <= ALPHA)
    index = int(feasible[0]) if len(feasible) else len(FRACTIONS) - 1
    curve = pd.DataFrame({
        "method": method,
        "fraction_index": np.arange(len(FRACTIONS)),
        "nominal_fraction": FRACTIONS,
        "calibration_empirical_risk": losses.mean(axis=0),
        "calibration_corrected_risk": corrected,
        "mean_tie_inflation": np.asarray(realized).mean(axis=0),
    })
    return index, curve


def evaluate_method(attributions, method, fraction_index):
    rows = []
    ph_scores = []
    fraction = float(FRACTIONS[fraction_index])
    for row in attributions.itertuples(index=False):
        scores, truth = score_map(row)
        selected, nominal_count = top_fraction(scores[method], fraction)
        values = set_values(selected, truth)
        ph_score = float(roc_auc_score(truth, scores[method]))
        ph_scores.append(ph_score)
        rows.append({
            "split": row.split,
            "ID": row.ID,
            "method": method,
            "nominal_fraction": fraction,
            **values,
            "nominal_atoms": int(nominal_count),
            "tie_extra_atoms": int(values["selected_atoms"] - nominal_count),
            "ph_score": ph_score,
        })
    frame = pd.DataFrame(rows)
    summary = {
        "method": method,
        "nominal_fraction": fraction,
        "fraction_index": int(fraction_index),
        "n": int(len(frame)),
        "test_risk": float(frame.risk.mean()),
        "mean_retained_fraction": float(frame.retained_fraction.mean()),
        "mean_precision": float(frame.precision.mean()),
        "mean_iou": float(frame.iou.mean()),
        "mean_ph_score": float(np.mean(ph_scores)),
        "mean_tie_inflation": float((frame.tie_extra_atoms / attributions.n_atoms.to_numpy()).mean()),
    }
    return frame, summary


def evaluate_same_size_random(attributions, primary_rows):
    selected_counts = primary_rows.set_index("ID").selected_atoms.to_dict()
    rows = []
    for row in attributions.itertuples(index=False):
        truth = np.asarray(row.y_true, dtype=np.int8)
        scores = random_scores(row.ID, len(truth))
        count = int(selected_counts[row.ID])
        order = np.argsort(-scores, kind="stable")
        selected = np.zeros(len(truth), dtype=bool)
        selected[order[:count]] = True
        values = set_values(selected, truth)
        rows.append({
            "split": row.split,
            "ID": row.ID,
            "method": "random_same_size_as_gradcam",
            "nominal_fraction": np.nan,
            **values,
            "nominal_atoms": count,
            "tie_extra_atoms": 0,
            "ph_score": float(roc_auc_score(truth, scores)),
        })
    frame = pd.DataFrame(rows)
    summary = {
        "method": "random_same_size_as_gradcam",
        "nominal_fraction": None,
        "fraction_index": None,
        "n": int(len(frame)),
        "test_risk": float(frame.risk.mean()),
        "mean_retained_fraction": float(frame.retained_fraction.mean()),
        "mean_precision": float(frame.precision.mean()),
        "mean_iou": float(frame.iou.mean()),
        "mean_ph_score": float(frame.ph_score.mean()),
        "mean_tie_inflation": 0.0,
    }
    return frame, summary


def run_explanations(batch_size, device_name):
    input_manifest()
    eligible, selected = freeze_slice()
    selected_ids = set(selected.ID)
    chosen = eligible.loc[eligible.ID.isin(selected_ids)].copy()
    chosen = chosen.merge(selected[["ID", "split", "selection_rank"]], on=["ID", "split"], how="inner", validate="one_to_one")
    chosen = chosen.sort_values(["split", "selection_rank"], kind="stable")
    device = torch.device(device_name)
    if device.type == "cpu":
        torch.set_num_threads(1)
        torch.use_deterministic_algorithms(True)
    model, _ = load_model(True, device)
    output_rows = []
    graphs, metadata = [], []
    started = time.time()
    for row in chosen.itertuples(index=False):
        graph, mol = graph_from_smiles(row.smiles, row.ID, row.y)
        truth = np.asarray(row.y_true, dtype=np.int8)
        if graph is None or graph.num_nodes != len(truth) or set(truth.tolist()) != {0, 1}:
            raise RuntimeError(f"selected atom mapping failed for {row.ID}")
        graphs.append(graph)
        metadata.append(row)
        if len(graphs) == batch_size:
            values = attribute_batch(model, graphs, device)
            for meta, graph_value in zip(metadata, values):
                gradcam, vanilla, probability = graph_value
                output_rows.append({
                    "split": meta.split,
                    "selection_rank": int(meta.selection_rank),
                    "ID": str(meta.ID),
                    "n_atoms": int(len(meta.y_true)),
                    "probability": probability,
                    "y_true": np.asarray(meta.y_true, dtype=np.int8).tolist(),
                    "gradcam": gradcam.astype(float).tolist(),
                    "vanilla_gradient": vanilla.astype(float).tolist(),
                })
            graphs, metadata = [], []
            if len(output_rows) % 256 == 0:
                print(f"attribution processed={len(output_rows)} elapsed_s={time.time() - started:.1f}", flush=True)
    if graphs:
        values = attribute_batch(model, graphs, device)
        for meta, graph_value in zip(metadata, values):
            gradcam, vanilla, probability = graph_value
            output_rows.append({
                "split": meta.split,
                "selection_rank": int(meta.selection_rank),
                "ID": str(meta.ID),
                "n_atoms": int(len(meta.y_true)),
                "probability": probability,
                "y_true": np.asarray(meta.y_true, dtype=np.int8).tolist(),
                "gradcam": gradcam.astype(float).tolist(),
                "vanilla_gradient": vanilla.astype(float).tolist(),
            })
    attributions = pd.DataFrame(output_rows).sort_values(["split", "selection_rank"], kind="stable")
    attributions.to_parquet(OUTPUTS / "attributions.parquet", index=False)
    calibration = attributions.loc[attributions.split == "val"].reset_index(drop=True)
    test = attributions.loc[attributions.split == "test"].reset_index(drop=True)
    curve_frames, set_frames, summaries = [], [], []
    for method in ["gradcam", "vanilla_gradient", "oracle", "random"]:
        index, curve = calibrate(calibration, method)
        values, summary = evaluate_method(test, method, index)
        curve_frames.append(curve)
        set_frames.append(values)
        summary.update({
            "calibration_empirical_risk": float(curve.loc[index, "calibration_empirical_risk"]),
            "calibration_corrected_risk": float(curve.loc[index, "calibration_corrected_risk"]),
        })
        summaries.append(summary)
    primary_rows = next(frame for frame in set_frames if frame.method.iloc[0] == "gradcam")
    same_size, same_size_summary = evaluate_same_size_random(test, primary_rows)
    same_size_summary.update({"calibration_empirical_risk": None, "calibration_corrected_risk": None})
    set_frames.append(same_size)
    summaries.append(same_size_summary)
    curves = pd.concat(curve_frames, ignore_index=True)
    set_metrics = pd.concat(set_frames, ignore_index=True)
    summary_frame = pd.DataFrame(summaries)
    curves.to_csv(OUTPUTS / "calibration_curves.csv", index=False)
    set_metrics.to_parquet(OUTPUTS / "test_set_metrics.parquet", index=False)
    summary_frame.to_csv(OUTPUTS / "explanation_summary.csv", index=False)
    gradcam_summary = next(item for item in summaries if item["method"] == "gradcam")
    oracle_summary = next(item for item in summaries if item["method"] == "oracle")
    random_summary = next(item for item in summaries if item["method"] == "random")
    random_denom = random_summary["mean_retained_fraction"] - oracle_summary["mean_retained_fraction"]
    recoverable = (random_summary["mean_retained_fraction"] - gradcam_summary["mean_retained_fraction"]) / random_denom if random_denom else None
    payload = {
        "status": "COMPLETE_PENDING_INDEPENDENT_VALIDATION",
        "n_calibration": int(len(calibration)),
        "n_test": int(len(test)),
        "methods": summaries,
        "gradcam_random_to_oracle_recoverable_efficiency": float(recoverable) if recoverable is not None else None,
        "device": str(device),
        "elapsed_seconds": float(time.time() - started),
        "claim_boundary": "constructed pharmacophore-computed operational reference only",
    }
    write_json(OUTPUTS / "explanation_metrics.json", payload)
    print(json.dumps(payload, indent=2))


def write_environment():
    device_name = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    payload = {
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "torch_geometric": __import__("torch_geometric").__version__,
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "pyarrow": __import__("pyarrow").__version__,
        "rdkit": rdBase.rdkitVersion,
        "cuda_available": bool(torch.cuda.is_available()),
        "cuda_runtime": torch.version.cuda,
        "gpu": device_name,
    }
    write_json(OUTPUTS / "environment.json", payload)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["audit", "predictor", "explanations", "all"], required=True)
    parser.add_argument("--predictor-batch-size", type=int, default=512)
    parser.add_argument("--attribution-batch-size", type=int, default=32)
    parser.add_argument("--attribution-device", choices=["cpu", "cuda"], default="cpu")
    args = parser.parse_args()
    OUTPUTS.mkdir(parents=True, exist_ok=True)
    write_environment()
    if args.stage in {"audit", "all"}:
        run_audit()
    if args.stage in {"predictor", "all"}:
        run_predictor(args.predictor_batch_size)
    if args.stage in {"explanations", "all"}:
        run_explanations(args.attribution_batch_size, args.attribution_device)


if __name__ == "__main__":
    main()
