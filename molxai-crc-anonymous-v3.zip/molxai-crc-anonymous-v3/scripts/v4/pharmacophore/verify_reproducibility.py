import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
RUN1 = HERE / "diagnostics" / "repro_run1"
RUN2 = HERE / "outputs"
NAMES = [
    "selected_slice.parquet",
    "slice_audit.json",
    "attributions.parquet",
    "calibration_curves.csv",
    "test_set_metrics.parquet",
    "explanation_summary.csv",
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


rows = []
for name in NAMES:
    first = digest(RUN1 / name)
    second = digest(RUN2 / name)
    rows.append({"file": name, "run1_sha256": first, "run2_sha256": second, "exact": first == second})
payload = {
    "status": "PASS_EXACT" if all(row["exact"] for row in rows) else "FAIL",
    "execution": "two independent Python processes, single-thread CPU, deterministic algorithms, batch size 32",
    "files": rows,
}
(HERE / "reproducibility.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
print(json.dumps({"status": payload["status"], "files": len(rows)}, indent=2))
if payload["status"] != "PASS_EXACT":
    raise SystemExit(1)
