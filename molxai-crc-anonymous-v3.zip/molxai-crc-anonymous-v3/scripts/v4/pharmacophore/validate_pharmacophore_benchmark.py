import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from rdkit import Chem, RDLogger
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    confusion_matrix,
    precision_score,
    recall_score,
    roc_auc_score,
)


HERE = Path(__file__).resolve().parent
INPUTS = HERE / "inputs"
OUTPUTS = HERE / "outputs"
FRACTIONS = np.linspace(0.0, 1.0, 101)
SALT = "molxai-crc-k4_2ar-v1"
RDLogger.DisableLog("rdApp.*")


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def pred_metrics(frame):
    y = frame.y.to_numpy(int)
    p = frame.probability.to_numpy(float)
    hard = (p >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, hard, labels=[0, 1]).ravel()
    return {
        "n": len(frame),
        "n_negative": int((y == 0).sum()),
        "n_positive": int((y == 1).sum()),
        "roc_auc": roc_auc_score(y, p),
        "average_precision": average_precision_score(y, p),
        "accuracy_at_0_5": accuracy_score(y, hard),
        "balanced_accuracy_at_0_5": balanced_accuracy_score(y, hard),
        "precision_at_0_5": precision_score(y, hard, zero_division=0),
        "recall_at_0_5": recall_score(y, hard, zero_division=0),
        "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
    }


def atom_random(identifier, count):
    return np.asarray([
        int.from_bytes(hashlib.sha256(f"{identifier}|{index}|{SALT}|random".encode()).digest()[:8], "big") / 2**64
        for index in range(count)
    ])


def select(scores, fraction):
    count = min(len(scores), max(0, math.ceil(fraction * len(scores))))
    chosen = np.zeros(len(scores), dtype=bool)
    if count:
        order = np.argsort(-np.asarray(scores, dtype=float), kind="stable")
        chosen = np.asarray(scores, dtype=float) >= scores[order[count - 1]]
    return chosen, count


def measures(chosen, truth):
    truth = np.asarray(truth, dtype=bool)
    both = int(np.logical_and(chosen, truth).sum())
    selected = int(chosen.sum())
    reference = int(truth.sum())
    union = int(np.logical_or(chosen, truth).sum())
    return {
        "risk": 1 - both / reference,
        "retained_fraction": selected / len(truth),
        "precision": both / selected if selected else 0.0,
        "iou": both / union if union else 0.0,
        "selected_atoms": selected,
    }


def row_scores(row, method):
    truth = np.asarray(row.y_true, dtype=np.int8)
    if method == "gradcam":
        return np.asarray(row.gradcam, dtype=float), truth
    if method == "vanilla_gradient":
        return np.asarray(row.vanilla_gradient, dtype=float), truth
    if method == "oracle":
        return truth.astype(float), truth
    if method == "random":
        return atom_random(row.ID, len(truth)), truth
    raise KeyError(method)


def recompute_method(calibration, test, method):
    matrix = []
    tie_matrix = []
    for row in calibration.itertuples(index=False):
        scores, truth = row_scores(row, method)
        risks, ties = [], []
        for fraction in FRACTIONS:
            chosen, nominal = select(scores, fraction)
            risks.append(measures(chosen, truth)["risk"])
            ties.append(chosen.sum() / len(truth) - nominal / len(truth))
        matrix.append(risks)
        tie_matrix.append(ties)
    matrix = np.asarray(matrix)
    corrected = (len(matrix) * matrix.mean(0) + 1) / (len(matrix) + 1)
    feasible = np.flatnonzero(corrected <= 0.10)
    index = int(feasible[0]) if len(feasible) else 100
    molecule_rows = []
    for row in test.itertuples(index=False):
        scores, truth = row_scores(row, method)
        chosen, nominal = select(scores, FRACTIONS[index])
        values = measures(chosen, truth)
        molecule_rows.append({
            "ID": row.ID,
            **values,
            "nominal_atoms": nominal,
            "tie_extra_atoms": values["selected_atoms"] - nominal,
            "ph_score": roc_auc_score(truth, scores),
        })
    frame = pd.DataFrame(molecule_rows)
    return {
        "method": method,
        "fraction_index": index,
        "nominal_fraction": FRACTIONS[index],
        "n": len(frame),
        "calibration_empirical_risk": matrix[:, index].mean(),
        "calibration_corrected_risk": corrected[index],
        "test_risk": frame.risk.mean(),
        "mean_retained_fraction": frame.retained_fraction.mean(),
        "mean_precision": frame.precision.mean(),
        "mean_iou": frame.iou.mean(),
        "mean_ph_score": frame.ph_score.mean(),
        "mean_tie_inflation": (frame.tie_extra_atoms / test.n_atoms.to_numpy()).mean(),
    }, frame


def close_number(left, right, atol=1e-10):
    return bool(np.isclose(float(left), float(right), atol=atol, rtol=atol))


def main():
    checks = []

    def add(name, passed, detail):
        checks.append({"name": name, "status": "PASS" if passed else "FAIL", "detail": detail})

    expected = {
        "k4_2ar_split.parquet": (531373003, "42e27f2ef90e36c636018a300984f1fca09889951483236dba1f17c8dce06db7"),
        "k4_2ar_labels.parquet": (18366664, "2b8e6cb4bfdaa8c180695d6df405c8dde8c3c25cdeda52481fb03f0ad45114cb"),
        "best_model_gcn_split_close_set.pth": (2982101, "1548a2942559b3c4705f95b510cc3dba30d23107e7f8d4ef1a76c04ad23b9c4b"),
    }
    input_ok = all((INPUTS / name).stat().st_size == size and digest(INPUTS / name) == value for name, (size, value) in expected.items())
    add("Frozen input sizes and SHA-256", input_ok, f"files={len(expected)}")

    audit = json.loads((OUTPUTS / "data_and_checkpoint_audit.json").read_text(encoding="utf-8"))
    leakage_ok = (
        audit["status"] == "PASS"
        and audit["duplicate_ids_with_conflicting_smiles"] == 0
        and audit["duplicate_ids_with_conflicting_y"] == 0
        and audit["duplicate_ids_crossing_base_split"] == 0
        and audit["positive_reference_ids_with_conflicting_close_membership"] == 0
        and audit["exact_smiles_crossing_base_split"] == 0
    )
    add("Repeated-ID leakage/conflict hard stop", leakage_ok, f"duplicate_after_first={audit['duplicate_rows_after_first']}, close_conflicts={audit['duplicate_ids_with_conflicting_close_membership']}, positive_close_conflicts={audit['positive_reference_ids_with_conflicting_close_membership']}")

    source_test = pq.read_table(INPUTS / "k4_2ar_split.parquet", columns=["ID", "y", "split"]).to_pandas()
    source_test["source_row_index"] = np.arange(len(source_test), dtype=np.int64)
    source_test = source_test.loc[source_test.split == "test", ["source_row_index", "ID", "y"]].reset_index(drop=True)
    predictions = pd.read_parquet(OUTPUTS / "predictor_predictions.parquet").reset_index(drop=True)
    coverage_ok = (
        len(predictions) == len(source_test) == 354570
        and predictions.source_row_index.equals(source_test.source_row_index)
        and predictions.ID.equals(source_test.ID)
        and predictions.y.equals(source_test.y)
        and np.isfinite(predictions.probability).all()
        and predictions.probability.between(0, 1).all()
    )
    add("Official row-level test coverage and lineage", coverage_ok, f"saved={len(predictions)}, source={len(source_test)}")

    saved_predictor = json.loads((OUTPUTS / "predictor_metrics.json").read_text(encoding="utf-8"))
    recomputed_predictor = pred_metrics(predictions)
    pred_match = all(close_number(recomputed_predictor[key], saved_predictor[key]) for key in ["roc_auc", "average_precision", "accuracy_at_0_5", "balanced_accuracy_at_0_5", "precision_at_0_5", "recall_at_0_5"])
    pred_match = pred_match and recomputed_predictor["confusion_matrix"] == saved_predictor["confusion_matrix"]
    add("Independent row-level predictor metric recomputation", pred_match, f"ROC-AUC={recomputed_predictor['roc_auc']:.9f}")

    unique_predictions = predictions.drop_duplicates("ID", keep="first")
    recomputed_unique = pred_metrics(unique_predictions)
    saved_unique = saved_predictor["unique_id_sensitivity"]
    unique_match = all(close_number(recomputed_unique[key], saved_unique[key]) for key in ["roc_auc", "average_precision", "accuracy_at_0_5", "balanced_accuracy_at_0_5", "precision_at_0_5", "recall_at_0_5"])
    unique_match = unique_match and recomputed_unique["confusion_matrix"] == saved_unique["confusion_matrix"]
    add("Unique-ID predictor sensitivity recomputation", unique_match, f"n={len(unique_predictions)}, ROC-AUC={recomputed_unique['roc_auc']:.9f}")

    diagnosis = json.loads((OUTPUTS / "predictor_metric_diagnosis.json").read_text(encoding="utf-8"))
    original_stop_retained = abs(recomputed_predictor["roc_auc"] - 0.900) > 0.015 and diagnosis["original_contract_source_proximity_gate"] == "STOP_TRIGGERED"
    add("Original continuous-AUC source-proximity STOP retained", original_stop_retained, f"ROC-AUC={recomputed_predictor['roc_auc']:.9f}, abs_delta={abs(recomputed_predictor['roc_auc'] - 0.900):.9f}")
    thresholded_auc = roc_auc_score(predictions.y.to_numpy(int), (predictions.probability.to_numpy(float) >= 0.5).astype(int))
    repaired_competence = recomputed_predictor["roc_auc"] >= 0.85 and recomputed_predictor["average_precision"] > predictions.y.mean() and abs(thresholded_auc - 0.900) <= 0.001
    add("Post-result trusted-with-caveats competence route", repaired_competence, f"continuous_AUC={recomputed_predictor['roc_auc']:.9f}, AP={recomputed_predictor['average_precision']:.9f}, thresholded_AUC={thresholded_auc:.9f}")

    labels = pq.read_table(INPUTS / "k4_2ar_labels.parquet", columns=["ID", "smiles", "y_true"]).to_pandas()
    split_unique = pq.read_table(INPUTS / "k4_2ar_split.parquet", columns=["ID", "split"]).to_pandas().drop_duplicates("ID", keep="first")
    eligible = labels.merge(split_unique, on="ID", how="left", validate="one_to_one")
    selected = pd.read_parquet(OUTPUTS / "selected_slice.parquet").sort_values(["split", "selection_rank"]).reset_index(drop=True)
    expected_ids = {}
    for split_name in ["val", "test"]:
        pool = eligible.loc[eligible.split == split_name, ["ID", "smiles", "y_true"]].copy()
        pool["selection_hash"] = pool.ID.map(lambda value: hashlib.sha256(f"{value}|{SALT}".encode()).hexdigest())
        expected_ids[split_name] = []
        for row in pool.sort_values(["selection_hash", "ID"], kind="stable").itertuples(index=False):
            mol = Chem.MolFromSmiles(row.smiles)
            truth = np.asarray(row.y_true, dtype=np.int8)
            if mol is not None and mol.GetNumAtoms() == len(truth) and set(truth.tolist()) == {0, 1}:
                expected_ids[split_name].append(row.ID)
            if len(expected_ids[split_name]) == 512:
                break
    selection_ok = all(selected.loc[selected.split == name].ID.tolist() == expected_ids[name] for name in ["val", "test"])
    selection_ok = selection_ok and selected.ID.nunique() == len(selected) == 1024 and not set(expected_ids["val"]) & set(expected_ids["test"])
    add("Prespecified hash slice and disjointness", selection_ok, f"val={(selected.split == 'val').sum()}, test={(selected.split == 'test').sum()}, unique={selected.ID.nunique()}")

    attributions = pd.read_parquet(OUTPUTS / "attributions.parquet").sort_values(["split", "selection_rank"]).reset_index(drop=True)
    arrays_ok = len(attributions) == 1024 and attributions.ID.equals(selected.ID)
    failures = 0
    for row in attributions.itertuples(index=False):
        truth = np.asarray(row.y_true, dtype=np.int8)
        gradcam = np.asarray(row.gradcam, dtype=float)
        vanilla = np.asarray(row.vanilla_gradient, dtype=float)
        source = labels.loc[labels.ID == row.ID].iloc[0]
        mol = Chem.MolFromSmiles(source.smiles)
        valid = (
            mol is not None
            and row.n_atoms == mol.GetNumAtoms() == len(truth) == len(gradcam) == len(vanilla)
            and set(truth.tolist()) == {0, 1}
            and np.array_equal(truth, np.asarray(source.y_true, dtype=np.int8))
            and np.isfinite(gradcam).all()
            and np.isfinite(vanilla).all()
            and math.isfinite(row.probability)
        )
        failures += int(not valid)
    arrays_ok = arrays_ok and failures == 0
    add("Atom-reference lineage and finite score arrays", arrays_ok, f"rows={len(attributions)}, failures={failures}")

    calibration = attributions.loc[attributions.split == "val"].reset_index(drop=True)
    test = attributions.loc[attributions.split == "test"].reset_index(drop=True)
    saved_summary = pd.read_csv(OUTPUTS / "explanation_summary.csv")
    reconstructed = []
    detailed = {}
    for method in ["gradcam", "vanilla_gradient", "oracle", "random"]:
        summary, frame = recompute_method(calibration, test, method)
        reconstructed.append(summary)
        detailed[method] = frame
    primary_counts = detailed["gradcam"].set_index("ID").selected_atoms.to_dict()
    same_size_rows = []
    for row in test.itertuples(index=False):
        truth = np.asarray(row.y_true, dtype=np.int8)
        order = np.argsort(-atom_random(row.ID, len(truth)), kind="stable")
        chosen = np.zeros(len(truth), dtype=bool)
        chosen[order[:primary_counts[row.ID]]] = True
        values = measures(chosen, truth)
        same_size_rows.append({**values, "ph_score": roc_auc_score(truth, atom_random(row.ID, len(truth)))})
    same_size = pd.DataFrame(same_size_rows)
    reconstructed.append({
        "method": "random_same_size_as_gradcam",
        "fraction_index": np.nan,
        "nominal_fraction": np.nan,
        "n": len(same_size),
        "calibration_empirical_risk": np.nan,
        "calibration_corrected_risk": np.nan,
        "test_risk": same_size.risk.mean(),
        "mean_retained_fraction": same_size.retained_fraction.mean(),
        "mean_precision": same_size.precision.mean(),
        "mean_iou": same_size.iou.mean(),
        "mean_ph_score": same_size.ph_score.mean(),
        "mean_tie_inflation": 0.0,
    })
    reconstructed = pd.DataFrame(reconstructed)
    merge = saved_summary.merge(reconstructed, on="method", suffixes=("_saved", "_independent"), validate="one_to_one")
    metric_columns = ["nominal_fraction", "fraction_index", "n", "test_risk", "mean_retained_fraction", "mean_precision", "mean_iou", "mean_ph_score", "mean_tie_inflation", "calibration_empirical_risk", "calibration_corrected_risk"]
    metric_match = len(merge) == 5
    for column in metric_columns:
        metric_match = metric_match and np.allclose(merge[f"{column}_saved"], merge[f"{column}_independent"], atol=1e-10, rtol=1e-10, equal_nan=True)
    add("Independent Ph-Score and CRC recomputation", metric_match, f"methods={len(merge)}")

    bounds_ok = all(reconstructed[column].dropna().between(0, 1).all() for column in ["nominal_fraction", "test_risk", "mean_retained_fraction", "mean_precision", "mean_iou", "mean_ph_score", "mean_tie_inflation", "calibration_empirical_risk", "calibration_corrected_risk"])
    bounds_ok = bounds_ok and (reconstructed.loc[reconstructed.method.isin(["gradcam", "vanilla_gradient", "oracle", "random"]), "calibration_corrected_risk"] <= 0.10 + 1e-12).all()
    add("Metric bounds and corrected alpha gate", bounds_ok, "five methods/controls; calibrated rows <= 0.10")

    reproducibility = json.loads((HERE / "reproducibility.json").read_text(encoding="utf-8"))
    reproducibility_ok = reproducibility["status"] == "PASS_EXACT" and len(reproducibility["files"]) == 6 and all(row["exact"] for row in reproducibility["files"])
    add("Independent-process CPU reproducibility", reproducibility_ok, f"status={reproducibility['status']}, files={len(reproducibility['files'])}")

    output_names = [
        "data_and_checkpoint_audit.json", "environment.json", "predictor_predictions.parquet", "predictor_metrics.json",
        "slice_audit.json", "selected_slice.parquet", "attributions.parquet", "calibration_curves.csv",
        "test_set_metrics.parquet", "explanation_summary.csv", "explanation_metrics.json", "predictor_metric_diagnosis.json",
    ]
    manifest = [{"file": name, "bytes": (OUTPUTS / name).stat().st_size, "sha256": digest(OUTPUTS / name)} for name in output_names]
    (OUTPUTS / "output_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    status = "TRUSTED_WITH_CAVEATS" if all(item["status"] == "PASS" for item in checks) else "FAIL"
    gradcam = reconstructed.loc[reconstructed.method == "gradcam"].iloc[0]
    random_calibrated = reconstructed.loc[reconstructed.method == "random"].iloc[0]
    adverse = bool(gradcam.mean_ph_score < 0.5 and gradcam.mean_retained_fraction > random_calibrated.mean_retained_fraction)
    payload = {
        "status": status,
        "decision": "GO_BOUNDED_EXTERNAL_SLICE_WITH_CAVEATS" if status == "TRUSTED_WITH_CAVEATS" else "STOP_CONTRACT_GATE_FAILED",
        "original_contract_gate": "STOP_TRIGGERED_AND_RETAINED",
        "baseline_status": "trusted_with_caveats" if status == "TRUSTED_WITH_CAVEATS" else "broken",
        "checks": checks,
        "row_level_predictor": {key: float(value) if isinstance(value, np.floating) else value for key, value in recomputed_predictor.items()},
        "unique_id_predictor_sensitivity": {key: float(value) if isinstance(value, np.floating) else value for key, value in recomputed_unique.items()},
        "independent_explanation_summary": reconstructed.replace({np.nan: None}).to_dict("records"),
        "adverse_explanation_result_retained": adverse,
        "claim_update": "The released GCN is predictively competent, but the frozen signed Grad-CAM slice is not better than the random controls: mean Ph-Score is below 0.5 and calibrated retained fraction is slightly larger than calibrated random. This is a negative external-boundary result on one constructed pharmacophore reference, not biological, experimental, mechanistic, or causal atom validation.",
    }
    (HERE / "validation.json").write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")
    lines = [f"# Validation: {status}", "", f"Decision: `{payload['decision']}`", ""]
    lines.extend(f"- {item['status']}: {item['name']} — {item['detail']}" for item in checks)
    lines.extend(["", "Claim boundary: " + payload["claim_update"]])
    (HERE / "validation.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"status": status, "decision": payload["decision"], "checks": len(checks)}, indent=2))
    if status == "FAIL":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
