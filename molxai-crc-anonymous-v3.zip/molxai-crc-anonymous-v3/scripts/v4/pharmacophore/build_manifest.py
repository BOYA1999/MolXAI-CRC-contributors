import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


rows = []
for path in sorted(HERE.rglob("*")):
    if not path.is_file() or "__pycache__" in path.parts or path.name == "MANIFEST.json":
        continue
    relative = path.relative_to(HERE).as_posix()
    local_only = relative.startswith(("inputs/", "outputs/", "logs/", "diagnostics/")) or relative in {"claim_update.md", "evaluation_summary.json", "dingzhen.md", "CHECKLIST.md", "validation.md", "validation.json", "reproducibility.json"}
    rows.append({"path": relative, "bytes": path.stat().st_size, "sha256": digest(path), "release_class": "local_only" if local_only else "candidate_requires_release_review"})
(HERE / "MANIFEST.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
print(json.dumps({"files": len(rows), "local_only": sum(row["release_class"] == "local_only" for row in rows), "candidate_requires_release_review": sum(row["release_class"] != "local_only" for row in rows)}, indent=2))

