import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, balanced_accuracy_score, roc_auc_score


HERE = Path(__file__).resolve().parent
predictions = pd.read_parquet(HERE / "outputs" / "predictor_predictions.parquet")
y = predictions.y.to_numpy(int)
p = predictions.probability.to_numpy(float)
hard = (p >= 0.5).astype(int)
unique = predictions.drop_duplicates("ID", keep="first")
unique_y = unique.y.to_numpy(int)
unique_p = unique.probability.to_numpy(float)
unique_hard = (unique_p >= 0.5).astype(int)
duplicates = predictions.loc[predictions.duplicated("ID", keep=False)]
duplicate_prob_ranges = duplicates.groupby("ID").probability.agg(lambda values: float(values.max() - values.min()))
payload = {
    "status": "TRUSTED_WITH_CAVEATS",
    "original_contract_source_proximity_gate": "STOP_TRIGGERED",
    "row_level": {
        "n": int(len(predictions)),
        "prevalence": float(y.mean()),
        "standard_continuous_probability_roc_auc": float(roc_auc_score(y, p)),
        "average_precision": float(average_precision_score(y, p)),
        "thresholded_class_roc_auc": float(roc_auc_score(y, hard)),
        "balanced_accuracy": float(balanced_accuracy_score(y, hard)),
        "mean_probability_positive": float(p[y == 1].mean()),
        "mean_probability_negative": float(p[y == 0].mean()),
    },
    "unique_id_sensitivity": {
        "n": int(len(unique)),
        "prevalence": float(unique_y.mean()),
        "standard_continuous_probability_roc_auc": float(roc_auc_score(unique_y, unique_p)),
        "average_precision": float(average_precision_score(unique_y, unique_p)),
        "thresholded_class_roc_auc": float(roc_auc_score(unique_y, unique_hard)),
        "balanced_accuracy": float(balanced_accuracy_score(unique_y, unique_hard)),
    },
    "duplicate_prediction_consistency": {
        "duplicate_ids": int(duplicates.ID.nunique()),
        "maximum_within_id_probability_range": float(duplicate_prob_ranges.max()),
        "all_identical": bool(np.allclose(duplicate_prob_ranges, 0.0, atol=0.0, rtol=0.0)),
        "all_within_3e_6": bool((duplicate_prob_ranges <= 3e-6).all()),
        "interpretation": "GPU batching changes repeated-row probabilities by at most low single-digit 1e-6; unique-ID metrics are therefore retained as the prespecified sensitivity analysis.",
    },
    "diagnosis": "The released source computes its quantity named ROC-AUC after thresholding probabilities at 0.5. That binary-score ROC-AUC equals balanced accuracy and reproduces the paper's rounded 0.900. The standard continuous-probability ROC-AUC is 0.9556 and is not a reproduction of the table value.",
    "continuation_basis": "Prediction direction, PR-AUC, strict checkpoint load, committed 42-feature graph reconstruction, and split-leakage audit support a bounded explanation analysis despite failure of the original source-proximity gate.",
}
(HERE / "outputs" / "predictor_metric_diagnosis.json").write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")
print(json.dumps(payload, indent=2))
