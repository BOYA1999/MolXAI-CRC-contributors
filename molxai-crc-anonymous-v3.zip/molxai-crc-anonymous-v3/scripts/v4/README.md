# V4 scripts

These repository-authored scripts document the executed V4 analyses. Full reruns require external data, score caches, and checkpoints named in the contracts. Run them only in a separate working directory because full outputs include row-level artifacts that are intentionally absent from this release.
