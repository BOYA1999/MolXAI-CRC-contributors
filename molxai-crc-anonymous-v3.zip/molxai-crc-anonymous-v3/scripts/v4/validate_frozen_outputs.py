import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parent


def require(condition, message, checks):
    if not condition:
        raise AssertionError(message)
    checks.append(message)


def main():
    checks = []
    direct = pd.read_csv(ROOT / "fixed_budget/cell_results.csv")
    summary = pd.read_csv(ROOT / "fixed_budget/method_summary.csv")
    flips = pd.read_csv(ROOT / "fixed_budget/ranking_flip_summary.csv")
    thresholds = pd.read_csv(ROOT / "gate_sensitivity/threshold_sensitivity.csv")
    proxy = pd.read_csv(ROOT / "mmp_oracle/pair_proxy_fractions.csv")
    oracle = pd.read_csv(ROOT / "mmp_oracle/target_oracle.csv")
    cells = pd.read_csv(ROOT / "mmp_oracle/cell_decomposition.csv")
    target = pd.read_csv(ROOT / "mmp_oracle/target_method_decomposition.csv")
    associations = pd.read_csv(ROOT / "mmp_oracle/competence_associations.csv")

    require(len(direct[direct.surface == "primary_full_grid"]) == 396, "primary direct rows=66 cells x 2 methods x 3 policies", checks)
    require(len(direct[direct.surface == "retrospective_matched_subset"]) == 990, "subset direct rows=66 cells x 5 methods x 3 policies", checks)
    require(direct[["risk", "retained_fraction", "precision", "iou"]].apply(np.isfinite).all().all(), "direct metrics finite", checks)
    require(((direct[["risk", "retained_fraction", "precision", "iou"]] >= -1e-12) &
             (direct[["risk", "retained_fraction", "precision", "iou"]] <= 1 + 1e-12)).all().all(), "direct metrics bounded", checks)
    require(len(summary) == 21, "budget summary has 21 method-policy rows", checks)
    require(len(flips) == 6 and (flips.ranking_reversals <= flips.non_tie_comparable).all(), "cell and task ranking-flip summaries complete", checks)
    require(set(np.round(thresholds.threshold, 2)) == {0.5, 0.6, 0.7, 0.8, 0.9}, "all five efficiency thresholds present", checks)
    primary_gate = thresholds[thresholds.surface == "primary_full_grid"]
    require(set(primary_gate.task_total) == {11} and set(primary_gate.cell_total) == {66}, "primary gate denominators are 11 tasks and 66 cells", checks)

    require(len(proxy) == 1035 and proxy.dataset.nunique() == 11, "MMP proxy table covers 1,035 pairs and 11 targets", checks)
    require(proxy.proxy_atom_fraction.between(0, 1, inclusive="both").all(), "MMP proxy fractions bounded", checks)
    require(len(oracle) == 11 and np.isfinite(oracle.select_dtypes("number")).all().all(), "MMP oracle has 11 finite target rows", checks)
    require(len(cells) == 66 and cells.dataset.nunique() == 11 and cells.method.nunique() == 2, "MMP decomposition has 66 target-seed-method cells", checks)
    require((cells.nominal_fraction + 1e-12 >= cells.oracle_nominal_fraction).all(), "oracle nominal fraction never exceeds explainer selection", checks)
    require((cells.excess_over_oracle >= -1e-12).all(), "explainer retained fraction never beats rationale-first oracle", checks)
    require((cells.random_crc_nominal_fraction + 1e-12 >= cells.oracle_nominal_fraction).all(), "calibrated analytical-random fraction never beats rationale-first oracle", checks)
    require(cells.random_crc_risk.between(0, 1, inclusive="both").all(), "calibrated analytical-random risks bounded", checks)
    require(len(target) == 22 and len(associations) == 18, "all-target summaries and competence associations complete", checks)

    report = {
        "status": "PASS",
        "checks": checks,
        "claim_update": {
            "V4-C1": "supported as a direct descriptive comparison on frozen primary and retrospective surfaces",
            "V4-C2": "supported as threshold sensitivity; no threshold gains external decision-cost validity",
            "V4-C4": "supported as an all-target decomposition; causal and population-general claims remain unsupported",
        },
    }
    (ROOT / "validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (ROOT / "validation.md").write_text("# JCIM v4 reused-output validation\n\n**PASS**\n\n" +
                                        "\n".join(f"- {item}" for item in checks) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
