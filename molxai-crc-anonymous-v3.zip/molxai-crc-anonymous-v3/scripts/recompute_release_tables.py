import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--out-dir", type=Path)
args = parser.parse_args()
OUT = args.out_dir.resolve() if args.out_dir else None
if OUT:
    OUT.mkdir(parents=True, exist_ok=True)

cells = pd.read_csv(ROOT / "results" / "established_explainers" / "cells.csv")
metrics = ["risk", "atom_fraction", "precision", "iou"]
if len(cells) != 330 or cells["cell_id"].nunique() != 66:
    raise SystemExit("Unexpected established-explainer cell table")
task_means = cells.groupby(["family", "task", "method"], as_index=False)[metrics].mean()
family = task_means.groupby(["family", "method"], as_index=False)[metrics].mean()
family.insert(1, "family_label", family["family"].map({"bxaic": "B-XAIC", "google": "Graph Attribution"}))
family.insert(2, "tasks", family["family"].map(task_means.groupby("family")["task"].nunique()))
family.insert(3, "cells", family["family"].map(cells.groupby("family")["cell_id"].nunique()))
expected = pd.read_csv(ROOT / "results" / "established_explainers" / "family_stratified_summary.csv")
columns = ["family", "family_label", "tasks", "cells", "method", *metrics]
family = family[columns].sort_values(["family", "method"]).reset_index(drop=True)
expected = expected[columns].sort_values(["family", "method"]).reset_index(drop=True)
if not family[["family", "family_label", "method"]].equals(expected[["family", "family_label", "method"]]):
    raise SystemExit("Family/method labels do not match")
if not np.allclose(family[["tasks", "cells", *metrics]], expected[["tasks", "cells", *metrics]], rtol=0, atol=1e-12):
    raise SystemExit("Family-stratified values do not reproduce")
if OUT:
    family.to_csv(OUT / "family_stratified_recomputed.csv", index=False)

polaris = ROOT / "results" / "polaris_hclint"
seed_scores = {}
for seed in [42, 123, 2026]:
    payload = json.loads((polaris / f"chemeleon_seed{seed}" / "polaris_metrics.json").read_text(encoding="utf-8"))
    seed_scores[seed] = payload["results"][0]["scores"]
ensemble = json.loads((polaris / "chemeleon_ensemble" / "polaris_metrics.json").read_text(encoding="utf-8"))
for metric in seed_scores[42]:
    values = np.array([seed_scores[seed][metric] for seed in [42, 123, 2026]], dtype=float)
    if not np.isclose(values.mean(), ensemble["seed_mean"][metric], rtol=0, atol=1e-12):
        raise SystemExit(f"Seed mean does not reproduce: {metric}")
    if not np.isclose(values.std(ddof=1), ensemble["seed_sample_sd"][metric], rtol=0, atol=1e-12):
        raise SystemExit(f"Seed SD does not reproduce: {metric}")
if OUT:
    pd.DataFrame(
        [{"seed": seed, **seed_scores[seed]} for seed in [42, 123, 2026]]
    ).to_csv(OUT / "polaris_seed_scores_recomputed.csv", index=False)

v4 = ROOT / "results" / "v4"
v4_cells = pd.read_csv(v4 / "fixed_budget" / "cell_results.csv")
value_columns = ["risk", "retained_fraction", "precision", "iou"]
v4_task = v4_cells.groupby(
    ["surface", "method", "policy", "family", "task"], as_index=False
)[value_columns].mean()
v4_rows = []
for (surface, method, policy), group in v4_cells.groupby(["surface", "method", "policy"], sort=True):
    task_group = v4_task[
        (v4_task.surface == surface) & (v4_task.method == method) & (v4_task.policy == policy)
    ]
    v4_rows.append({
        "surface": surface,
        "method": method,
        "policy": policy,
        "cells": len(group),
        "risk_pass_cells": int(group.risk_pass.astype(str).str.lower().eq("true").sum()),
        "task_macro_risk": task_group.risk.mean(),
        "task_macro_retained_fraction": task_group.retained_fraction.mean(),
        "task_macro_precision": task_group.precision.mean(),
        "task_macro_iou": task_group.iou.mean(),
    })
v4_recomputed = pd.DataFrame(v4_rows).sort_values(["surface", "method", "policy"]).reset_index(drop=True)
v4_expected = pd.read_csv(v4 / "fixed_budget" / "method_summary.csv").sort_values(
    ["surface", "method", "policy"]
).reset_index(drop=True)
label_columns = ["surface", "method", "policy"]
numeric_columns = ["cells", "risk_pass_cells", "task_macro_risk", "task_macro_retained_fraction", "task_macro_precision", "task_macro_iou"]
if not v4_recomputed[label_columns].equals(v4_expected[label_columns]):
    raise SystemExit("V4 fixed-budget labels do not reproduce")
if not np.allclose(v4_recomputed[numeric_columns], v4_expected[numeric_columns], rtol=0, atol=1e-12):
    raise SystemExit("V4 fixed-budget method summary does not reproduce")
if OUT:
    v4_recomputed.to_csv(OUT / "v4_fixed_budget_method_summary_recomputed.csv", index=False)

pharmacophore = v4 / "pharmacophore"
ph_eval = json.loads((pharmacophore / "evaluation_summary.json").read_text(encoding="utf-8"))
ph_predictor = json.loads((pharmacophore / "predictor_metrics.json").read_text(encoding="utf-8"))
ph_explanations = pd.read_csv(pharmacophore / "explanation_summary.csv")
gradcam = ph_explanations.loc[ph_explanations.method == "gradcam"].iloc[0]
if not np.isclose(
    ph_eval["experimental_results"]["predictor"]["standard_continuous_probability_roc_auc"],
    ph_predictor["roc_auc"], rtol=0, atol=1e-12,
):
    raise SystemExit("V4 pharmacophore predictor aggregate does not reproduce")
if not np.isclose(
    ph_eval["experimental_results"]["signed_gradcam"]["test_risk"],
    gradcam.test_risk, rtol=0, atol=1e-12,
):
    raise SystemExit("V4 pharmacophore explanation aggregate does not reproduce")

print("PASS: family-stratified, Polaris, V4 fixed-budget, and pharmacophore summaries reproduce")
