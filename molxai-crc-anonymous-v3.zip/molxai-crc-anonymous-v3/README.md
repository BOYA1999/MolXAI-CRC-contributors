# MolXAI-CRC anonymous reproducibility package v3

This local release candidate contains repository-authored code, sanitized experimental contracts, structure-free aggregate results, provenance records, and release checks. It was assembled from an explicit allowlist for peer review.

Manuscript and supplementary text, publication figures and tables, author identity, email addresses, affiliations, local machine paths, raw molecular structures, molecule-level predictions and attributions, checkpoints, execution logs, caches, failed attempts, and bundled third-party repositories are not included.

## Supported evidence surfaces

- Original B-XAIC and Graph Attribution audits, calibration analyses, negative controls, and hierarchy-aware resampling.
- Matched five-explainer comparison and the Polaris HCLint predictive/compatibility audit.
- A1 repeated finite-pool redraws.
- A2 mask-definition sensitivity.
- A3 subset representativeness.
- A4 bond-aware GINE architecture/representation extension.
- A5 target/null and abstention diagnostics.
- A6 atom-permutation and symmetry-closure sensitivity.
- A7 MoleculeACE matched-molecular-pair activity-cliff audit.
- V4 fixed-budget versus calibrated-set comparison and threshold sensitivity.
- V4 score-semantics and GNNExplainer-initialization checks.
- V4 all-target MMP oracle decomposition.
- V4 K4_2ar pharmacophore benchmark with a released competent GCN and an adverse explanation-localization result.
- V5 fixed-slice predictor competence, correctly predicted subset, full eligible-population comparison, 1,000 equal-size randomizations per molecule, exact hypergeometric expectations, and descriptive within-molecule AUC summaries.

A7 evaluates an experimental SAR-linked transformation-site proxy. It is not causal, mechanistic, complete, expert-annotated, or ground truth. Its clustered pairs and overlapping targets support a descriptive finite-pool stress test only.

The V4 pharmacophore benchmark uses a pharmacophore-computed operational atom reference. It is not experimental, biological, mechanistic, causal, or expert-annotated atom truth. Its predictor-competence and explanation-localization findings are a bounded single-task external slice.

## Quick checks

```bash
python -m unittest discover -s src -p "test_*.py"
python scripts/recompute_release_tables.py
python scripts/v5/pharmacophore/verify_public_aggregates.py
python scripts/verify_release.py
```

The release verifier checks the exact manifest, Python syntax, required A1--A7 and V4 surfaces, privacy and secret patterns, forbidden paths and file types, structure-bearing result schemas, license separation, and frozen summary invariants.

## Repository map

- `src/`: original method and audit implementation.
- `scripts/reference/` and `scripts/polaris/`: earlier reference experiments.
- `scripts/a_level/`: A1--A7 formal experiment code. External inputs are supplied through command-line arguments.
- `scripts/v4/`: repository-authored V4 analysis and validation code; full reruns require external inputs and must write outside this release tree.
- `scripts/v5/pharmacophore/`: V5 external-work-directory runner, reconstruction instructions, and aggregate checks.
- `contracts/`: sanitized frozen contracts and amendments.
- `data/`: public-source metadata only.
- `results/`: structure-free aggregate evidence only.
- `results/a_level/a7_moleculeace_mmp/DATA_LICENSE.md`: A7 ChEMBL-derived result license boundary.
- `results/v4/`: structure-free V4 aggregate evidence; no pair- or molecule-level rows are included.
- `results/v4/pharmacophore/DATA_LICENSE.md`: CC BY 4.0 attribution boundary for K4_2ar-derived aggregates.
- `results/v5/pharmacophore/`: aggregate V5 evidence under the same CC BY 4.0 boundary; no molecule-level records or scaffold identities.
- `DATA_SOURCES.md`: public sources, revisions, hashes, licenses, and reconstruction boundaries.
- `REPRODUCIBILITY.md`: rerun surfaces and external-input requirements.

## License boundary

The root MIT License covers only repository-authored code and documentation. Third-party assets and data-derived outputs retain their upstream terms. A7 MoleculeACE benchmark records derive from ChEMBL v29; the A7 derived result directory is explicitly separated under CC BY-SA 3.0. The V4 and V5 K4_2ar aggregates derive from the Pharmaco-Explainer dataset/checkpoint release and retain CC BY 4.0 attribution. These data-derived result directories are not covered by the root MIT License.

This is a local candidate. It does not claim that a matching remote commit or immutable archival DOI currently exists.
