# Reproducibility surfaces

## Self-contained release checks

Run these commands from the package root:

```bash
python -m unittest discover -s src -p "test_*.py"
python scripts/recompute_release_tables.py
python scripts/verify_release.py
```

They test the finite-sample correction, recompute released summaries, enforce the anonymous-release boundary, parse every Python file, and verify the exact SHA-256 manifest.

## A1--A7 execution interfaces

Every A-level experiment script exposes its external inputs through command-line arguments. Inspect the exact interface before a rerun:

```bash
python scripts/a_level/a1_repeated_redraw.py --help
python scripts/a_level/a2_mask_audit.py --help
python scripts/a_level/a3_subset_representativeness.py --help
python scripts/a_level/a4_gine.py --help
python scripts/a_level/a5_target_null.py --help
python scripts/a_level/a6_permutation_symmetry.py --help
python scripts/a_level/a7_moleculeace_mmp/build_mmp_pairs.py --help
python scripts/a_level/a7_moleculeace_mmp/train_gine.py --help
python scripts/a_level/a7_moleculeace_mmp/attribute_and_crc.py --help
python scripts/a_level/a7_moleculeace_mmp/validate_a7.py --help
```

Use the corresponding frozen contract under `contracts/a_level/`. Write regenerated artifacts to a separate working directory; do not place raw inputs, checkpoints, logs, or molecule-level outputs in this release tree.

## External input gates

Raw molecule tables are intentionally absent. Reconstruct them from the public sources and frozen revisions in `DATA_SOURCES.md`, then verify the recorded source hashes before use. A1--A6 also require the upstream score caches, checkpoints, or split artifacts specified by their contracts. A7 requires the frozen MoleculeACE checkout, ChEMBL-derived benchmark records, the recorded split manifest, and regenerated model checkpoints.

The 66-cell established-explainer run and three CheMeleon fine-tuning runs are weight-dependent. Their checkpoints are not distributed here. For CheMeleon, obtain the cited foundation checkpoint, materialize the documented training table, and use the fixed configs in `configs/`; seeds are 42, 123, and 2026 and the ensemble is the unweighted arithmetic mean fixed before hidden-test evaluation.

## V4 execution interfaces

The V4 scripts document fixed-budget, threshold, score-semantics, MMP-oracle, and pharmacophore analyses. They require excluded upstream score caches, molecule tables, or checkpoints and must write to a separate working directory:

```bash
python scripts/v4/analyze_frozen_outputs.py
python scripts/v4/validate_frozen_outputs.py
python scripts/v4/score_semantics/run_score_semantics.py --help
python scripts/v4/score_semantics/validate_score_semantics.py
python scripts/v4/pharmacophore/run_pharmacophore_benchmark.py --help
python scripts/v4/pharmacophore/validate_pharmacophore_benchmark.py
python scripts/v4/pharmacophore/verify_reproducibility.py
```

The sanitized placeholders `<tie-inclusive-root>` and `<tie-inclusive-score-cache>` must be replaced by a reconstructed external working tree before the score-semantics scripts are run. The pharmacophore route requires the exact code, data, and checkpoint revisions recorded in `DATA_SOURCES.md` and the frozen hashes in `contracts/v4/pharmacophore/`.

## V5 reconstruction and model-weight scope

The complete V5 reconstruction instructions and explicit external-directory interfaces are in `scripts/v5/pharmacophore/README.md`. `run_robustness.py` and its independent formula validator regenerate the V5 audit from external V4 tables; `verify_public_aggregates.py` checks the released aggregate identities and can compare a regenerated output directory. The package contains no row-level source cache. Full regeneration begins with the three checksum-pinned public resources, uses the unchanged released V4 score generator, and performs no new training. Historical byte replay and separately validated regenerated materialization are explicitly distinguished.

All weights are omitted from this anonymous package: both author-trained GIN, GCN, GINE, MMP regressors and fine-tuned CheMeleon checkpoints, and third-party foundation/Pharmaco-Explainer checkpoints. This is the package's distribution scope, not a claim that every omitted file is legally prohibited from redistribution. Author-trained models must be regenerated with the published scripts, seeds, data/split reconstruction rules, and configurations; third-party checkpoints must be obtained from their cited releases. The aggregate checks executed without weights do not verify a fresh end-to-end retraining of every model or certify byte-identical checkpoints across environments. Exact replication of weight-dependent original analyses therefore remains conditional on those external reconstruction steps.

## Evidence boundaries

- Established-explainer comparison: 66 matched cells, 11 task clusters, two benchmark families, two architectures, and three seeds. Family summaries are descriptive strata.
- Polaris predictivity: official 2,229/575 split; metrics are hidden-test evaluation outputs.
- Polaris explanations: label-free perturbation relevance on 100 deterministically selected hidden-test molecules, not external validation of rationale correctness.
- A7: an experimental SAR-linked transformation-site proxy evaluated as a descriptive, clustered finite-pool stress test. It is not causal ground truth and does not establish distribution-free generalization.
- V4 fixed budgets and thresholds: descriptive comparisons on frozen outputs; a changed budget or threshold can change rankings and does not establish a universal operating point.
- V4 MMP oracle: an all-target decomposition under the measured set family and transformation-site proxy; pair-level records are deliberately absent.
- V4 pharmacophore: K4_2ar Close uses a pharmacophore-computed operational reference. The released GCN is predictively competent, while signed Grad-CAM and vanilla-gradient localization do not outperform the frozen random controls on the fixed slice. This adverse result is retained and is not biological atom validation.
- Public release and archival deposit are separate. This package has no DOI until an immutable archive is actually created.
