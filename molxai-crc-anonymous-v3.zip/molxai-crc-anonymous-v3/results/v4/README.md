# V4 aggregate results

Only structure-free cell-, task-, target-, method-, threshold-, or diagnostic-level aggregates are included. Pair-level and molecule-level rows, identifiers, structures, predictions, atom scores, masks, weights, caches, logs, and article files are excluded. Pharmacophore-derived aggregates retain the adjacent CC BY 4.0 attribution notice.
