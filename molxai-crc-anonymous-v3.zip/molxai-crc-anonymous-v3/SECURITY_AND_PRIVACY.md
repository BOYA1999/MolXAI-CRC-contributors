# Release privacy statement

This candidate is built from an explicit file allowlist. It excludes manuscript and supplementary prose, publication figures, captions, Word/TeX/PDF sources, project-author names, affiliations, email addresses, project-owner account names, local absolute paths, document comments, tracked changes, raw molecule tables and strings, molecule-level predictions or attributions, caches, logs, checkpoints, model weights, failed-run artifacts, and bundled third-party repositories. Third-party author and repository names are retained only where required for source attribution and license compliance.

`scripts/verify_release.py` checks the exact manifest, denylisted file types and directories, common secret and identity patterns, local path patterns, structure-bearing tabular schemas, and required license boundaries. The final ZIP is independently extracted and the same checks are rerun on the extracted copy.

For V4, MMP pair-level tables and all pharmacophore source rows, molecule identifiers, SMILES, labels, predictions, selected slices, atom masks/scores, score caches, model checkpoints, and third-party source files are explicit exclusions. Only structure-free aggregates and repository-authored scripts are allowlisted.

Rebuild and rescan the package after any change. Author metadata, repository ownership, citation records, and paper-facing material belong only to a later unblinded deposit and are outside this anonymous candidate.
