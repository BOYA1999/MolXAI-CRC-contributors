import torch
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
SOURCE = ROOT / 'source/molxai-crc-anonymous-v3'
sys.path.insert(0, str(WORK / 'src'))
import run_gradient_grid as grid

parser = argparse.ArgumentParser()
parser.add_argument('--first-cell-only', action='store_true')
args = parser.parse_args()
contract = json.loads((ROOT / 'run_contract.json').read_text(encoding='utf-8'))
assert contract['training']['max_epochs'] == 100 and contract['training']['batch_size'] == 128
assert sys.prefix != sys.base_prefix and torch.cuda.is_available()
OUT = WORK / 'artifacts/experiment/gradient_grid_main'
OUT.mkdir(parents=True, exist_ok=True)
run_args = SimpleNamespace(out_dir=str(OUT), batch_size=128, epochs=100, surface='final')
contract_hash = grid.sha256(SOURCE / 'contracts/experiment_contract.md')
code_hash = grid.sha256(WORK / 'src/run_gradient_grid.py')
started = time.time()
partition_rows = []
for family, tasks in [('bxaic', grid.BXAIC_TASKS), ('google', grid.GOOGLE_TASKS)]:
    for task in tasks:
        print(f'load_task={family}/{task}', flush=True)
        partitions = grid.bxaic_partitions(WORK / 'data/raw/bxaic/data.csv', WORK / 'data/raw/bxaic/explanations.sdf', task) if family == 'bxaic' else grid.google_partitions(WORK / 'reference/graph-attribution/data', task)
        indices = {name: [int(g.source_index) for g in graphs] for name, graphs in partitions.items()}
        sets = [set(v) for v in indices.values()]
        assert sum(map(len, sets)) == len(set.union(*sets))
        for name, graphs in partitions.items():
            partition_rows.append({'family': family, 'task': task, 'split': name, 'n': len(graphs), 'n_positive': sum(int(g.y) for g in graphs), 'n_rationale': sum(bool(g.rationale_mask.any()) for g in graphs), 'source_indices_sha256': hashlib.sha256(json.dumps(indices[name], separators=(',', ':')).encode()).hexdigest()})
        grid.atomic_json(ROOT / 'partition_summary.json', partition_rows)
        for model in ['gin', 'gcn']:
            for seed in [42, 123, 2026]:
                cell_start = time.time()
                grid.run_cell(family, task, model, seed, partitions, run_args, contract_hash, code_hash)
                print(f'wall_cell_seconds={time.time() - cell_start:.3f}', flush=True)
                if args.first_cell_only:
                    sys.exit(0)
grid.atomic_json(OUT / 'gradient_grid_manifest.json', {'status': 'complete', 'surface': 'final', 'started_unix': started, 'finished_unix': time.time(), 'contract_sha256': contract_hash, 'code_sha256': code_hash, 'cell_count': len(list((OUT / 'cells').glob('*.json'))), 'new_retraining': True})
