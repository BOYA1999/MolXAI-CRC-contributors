import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
REF = ROOT / 'source/molxai-crc-anonymous-v3/results'
OUT = ROOT / 'interim_comparison'
OUT.mkdir(exist_ok=True)
records = []
for path in (WORK / 'artifacts/experiment/gradient_grid_main/cells').glob('*.json'):
    cell = json.loads(path.read_text(encoding='utf-8'))
    for method, value in cell['explainers'].items():
        crc = value['metrics']['alpha']['0.10']['crc']
        records.append({'cell_id': cell['cell_id'], 'explainer': method, 'family': cell['family'], 'task': cell['task'], 'test_auroc': cell['predictor']['test']['auroc'], 'fraction_grid': crc['fraction'], 'test_risk': crc['risk'], 'mean_atom_fraction': crc['mean_atom_fraction'], 'iou': crc['iou'], 'checkpoint_sha256_new': hashlib.sha256(Path(cell['checkpoint']).read_bytes()).hexdigest()})
current = pd.DataFrame(records)
reference = pd.read_csv(REF / 'original_audits/gradient_grid_phase_a/cell_alpha010.csv')
merged = current.merge(reference, on=['cell_id', 'explainer', 'family', 'task'], suffixes=('_new', '_historical'), validate='one_to_one')
assert len(merged) == len(current)
metrics = ['test_auroc', 'fraction_grid', 'test_risk', 'mean_atom_fraction', 'iou']
summary = {}
for metric in metrics:
    delta = merged[f'{metric}_new'] - merged[f'{metric}_historical']
    merged[f'{metric}_delta'] = delta
    summary[metric] = {'max_abs_delta': float(abs(delta).max()), 'mean_signed_delta': float(delta.mean()), 'rmse_delta': float(np.sqrt(np.mean(delta ** 2))), 'identical_within_1e_12_rows': int((abs(delta) <= 1e-12).sum()), 'largest_absolute_deltas': merged.assign(abs_delta=abs(delta)).nlargest(5, 'abs_delta')[['cell_id', 'explainer', f'{metric}_new', f'{metric}_historical', f'{metric}_delta']].to_dict('records')}
merged.to_csv(OUT / 'primary_completed_cells_paired.csv', index=False)
payload = {'status': 'INTERIM_ONLY', 'primary_cells': current.cell_id.nunique(), 'cell_method_rows': len(current), 'metrics': summary, 'new_checkpoint_hashes_in_csv': True, 'historical_checkpoint_hashes': 'not present in public-v3 primary aggregate CSV; no old weight file read', 'no_protocol_adjustment': True}
(OUT / 'interim_summary.json').write_text(json.dumps(payload, indent=2), encoding='utf-8')
print(json.dumps(payload, indent=2))
