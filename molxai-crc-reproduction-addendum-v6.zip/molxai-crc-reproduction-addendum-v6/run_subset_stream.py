import torch
import argparse
import json
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
sys.path.insert(0, str(WORK / 'src'))
sys.path.insert(0, str(WORK / 'scripts/reference'))
import run_established_explainer_benchmark as source

parser = argparse.ArgumentParser()
parser.add_argument('--worker', type=int, choices=[0, 1], required=True)
args = parser.parse_args()
OUT = WORK / 'results/established_explainers'
started = time.time()
cell_number = -1
for family, tasks in [('bxaic', source.BXAIC_TASKS), ('google', source.GOOGLE_TASKS)]:
    for task in tasks:
        print(f'subset_load_task={family}/{task}', flush=True)
        partitions = source.bxaic_partitions(WORK / 'data/raw/bxaic/data.csv', WORK / 'data/raw/bxaic/explanations.sdf', task) if family == 'bxaic' else source.google_partitions(WORK / 'reference/graph-attribution/data', task)
        for model in ['gin', 'gcn']:
            for seed in [42, 123, 2026]:
                cell_number += 1
                if cell_number % 2 != args.worker:
                    continue
                cell_id = f'{family}__{task}__{model}__seed{seed}'
                ready = WORK / 'artifacts/experiment/gradient_grid_main/cells' / f'{cell_id}.json'
                if not ready.exists():
                    print(f'awaiting_new_checkpoint={cell_id}', flush=True)
                while not ready.exists():
                    time.sleep(5)
                payload = json.loads(ready.read_text(encoding='utf-8'))
                assert payload['status'] == 'complete' and payload['cell_id'] == cell_id
                assert payload['code_sha256'] == source.sha256(WORK / 'src/run_gradient_grid.py')
                source.run_cell(family, task, model, seed, partitions, 100, 100, 64, OUT)
(ROOT / f'subset_worker_{args.worker}_complete.json').write_text(json.dumps({'status': 'complete', 'worker': args.worker, 'finished_unix': time.time()}), encoding='utf-8')
if args.worker == 0:
    while not (ROOT / 'subset_worker_1_complete.json').exists():
        time.sleep(5)
    assert len(list((OUT / 'cells').glob('*.json'))) == 66
    source.aggregate(OUT, time.time() - started)
    (ROOT / 'subset_stream_complete.json').write_text(json.dumps({'status': 'complete', 'cells': 66, 'finished_unix': time.time(), 'runtime_comparison_allowed': False}), encoding='utf-8')
