import torch
import importlib.util
import json
from pathlib import Path
import runpy
import sys
import time

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
SOURCE = ROOT / 'source/molxai-crc-anonymous-v3'
sys.path.insert(0, str(WORK / 'src'))
sys.path.insert(0, str(WORK / 'scripts/reference'))
import run_established_explainer_benchmark as subset

primary_cells = WORK / 'artifacts/experiment/gradient_grid_main/cells'
assert len(list(primary_cells.glob('*.json'))) == 66
runpy.run_path(str(WORK / 'src/aggregate_gradient_grid.py'), run_name='__main__')
runpy.run_path(str(WORK / 'src/analyze_oracle_crc_baseline.py'), run_name='__main__')
out = WORK / 'results/established_explainers'
sys.argv = ['run_established_explainer_benchmark.py', '--out-dir', str(out), '--limit-per-split', '100', '--gnn-epochs', '100', '--batch-size', '64']
if not (ROOT / 'subset_stream_complete.json').exists():
    subset.main()
sys.argv = ['analyze_established_explainers.py', '--cells-csv', str(out / 'cells.csv'), '--out-json', str(out / 'paired_analysis.json'), '--cells-dir', str(out / 'cells'), '--bootstraps', '2000']
runpy.run_path(str(WORK / 'scripts/reference/analyze_established_explainers.py'), run_name='__main__')
spec = importlib.util.spec_from_file_location('v4_fixed', SOURCE / 'scripts/v4/analyze_frozen_outputs.py')
fixed = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixed)
fixed.PRIMARY = primary_cells
fixed.SUBSET = out / 'cells'
primary = fixed.load_surface(primary_cells, ['gradinput', 'ig'], 'primary_full_grid')
matched = fixed.load_surface(out / 'cells', ['gradinput', 'ig', 'saliency', 'atom_occlusion', 'gnnexplainer'], 'retrospective_matched_subset')
direct = fixed.pd.concat([primary, matched], ignore_index=True)
target = WORK / 'results/fixed_budget'
target.mkdir(parents=True, exist_ok=True)
summary = fixed.summarize_budgets(direct)
preferences = fixed.pairwise_preference(direct)
for name, frame in [('cell_results', direct), ('task_macro_results', fixed.task_macro(direct)), ('method_summary', summary), ('method_rankings', fixed.method_rankings(summary)), ('ig_gradinput_cell_preferences', preferences), ('ranking_flip_summary', fixed.preference_summary(preferences, direct)), ('threshold_sensitivity', fixed.gate_sensitivity(direct))]:
    frame.to_csv(target / f'{name}.csv', index=False)
(ROOT / 'execution_complete.json').write_text(json.dumps({'status': 'execution_complete_pending_comparison', 'finished_unix': time.time(), 'primary_cells': 66, 'primary_cell_method_rows': len(primary) // 3, 'subset_cell_method_rows': len(matched) // 3, 'policy_rows': len(direct), 'scientific_scripts_modified': False}, indent=2), encoding='utf-8')
