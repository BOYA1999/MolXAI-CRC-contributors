import concurrent.futures
import hashlib
import json
from pathlib import Path
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'inputs'
jobs = []
for filename, digest in [('data.csv', '14853568ECE75E5C5666C7190E6402CE8D24B3DD3DB171460E668C82C06344FC'), ('explanations.sdf', '83C86A6366AFF1DB12A3E439CEAB9A4F275508FAF1BEB5E1B8ADB261465E70AA')]:
    jobs.append((f'https://huggingface.co/datasets/mproszewska/B-XAIC/resolve/c963b9ee34862b4115dccf7941ba55c9bee16ad0/{filename}', DATA / 'bxaic' / filename, digest))
for task in ['benzene', 'logic7', 'logic8', 'logic10']:
    for filename in [f'{task}_smiles.csv', f'{task}_traintest_indices.npz', 'y_true.npz', 'x_true.npz', 'true_raw_attribution_datadicts.npz']:
        jobs.append((f'https://raw.githubusercontent.com/google-research/graph-attribution/03e7495379df26a21395b25c6a14d92dc27fc3b0/data/{task}/{filename}', DATA / 'graph-attribution' / task / filename, None))

def fetch(job):
    url, path, expected = job
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(path)
    started = time.time()
    with urllib.request.urlopen(url, timeout=180) as response, path.open('wb') as stream:
        final_url = response.url
        for block in iter(lambda: response.read(1024 * 1024), b''):
            stream.write(block)
    digest = hashlib.sha256(path.read_bytes()).hexdigest().upper()
    if expected is not None and digest != expected:
        raise ValueError(f'checksum mismatch: {path}')
    print(f'downloaded={path.relative_to(ROOT)} bytes={path.stat().st_size}', flush=True)
    return {'path': str(path.relative_to(ROOT)), 'source_url': url, 'resolved_url': final_url, 'sha256': digest, 'expected_sha256': expected, 'bytes': path.stat().st_size, 'elapsed_seconds': time.time() - started}

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(fetch, jobs))
(ROOT / 'input_manifest.json').write_text(json.dumps({'status': 'complete', 'files': results}, indent=2), encoding='utf-8')
