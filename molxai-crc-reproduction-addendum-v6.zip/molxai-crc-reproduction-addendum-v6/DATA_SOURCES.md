# Sources, licenses, and package identity

This unpublished code-only addendum must be used together with the separate, unchanged `molxai-crc-anonymous-v3.zip` archive (SHA-256 `032b3adc582fca31cfddc88ac853a4960b89b72addb70917ad0368a7c6b605a4`). It is not a replacement archive or evidence that v3 alone contains the full preparation recipe. The 17 recipe files are preserved without changes from the frozen reconstruction snapshot. `LICENSE`, this source note, and `MANIFEST_SHA256.txt` are packaging additions.

The root MIT License covers repository-authored code and documentation only. No third-party source tree, input table, model checkpoint, molecular identifier, row-level result, or manuscript is included. Downloaded inputs and all generated outputs belong in a separate working directory; their source terms are not replaced by MIT.

## B-XAIC

- Dataset: <https://huggingface.co/datasets/mproszewska/B-XAIC>.
- Frozen revision: `c963b9ee34862b4115dccf7941ba55c9bee16ad0`.
- The frozen base package records the dataset-card license as CC BY-SA 4.0. Dataset card: <https://huggingface.co/datasets/mproszewska/B-XAIC/blob/c963b9ee34862b4115dccf7941ba55c9bee16ad0/README.md>.
- `download_inputs.py` retrieves two files from that revision and checks their expected SHA-256 values:
  - `data.csv`: `14853568ece75e5c5666c7190e6402ce8d24b3dd3db171460e668c82c06344fc`.
  - `explanations.sdf`: `83c86a6366aff1db12a3e439ceab9a4f275508faf1beb5e1b8adb261465e70aa`.
- Role: seven molecular-property tasks and their atom-rationale masks. Neither file is distributed in this addendum.

## Graph Attribution

- Repository: <https://github.com/google-research/graph-attribution>.
- Frozen commit: `03e7495379df26a21395b25c6a14d92dc27fc3b0`.
- Repository license: Apache License 2.0; frozen license: <https://github.com/google-research/graph-attribution/blob/03e7495379df26a21395b25c6a14d92dc27fc3b0/LICENSE>. Preserve the upstream LICENSE/NOTICE and applicable underlying molecule-collection terms when retrieving or reusing upstream assets.
- `download_inputs.py` retrieves five files for each of `benzene`, `logic7`, `logic8`, and `logic10`: task SMILES, task train/test indices, `y_true.npz`, `x_true.npz`, and `true_raw_attribution_datadicts.npz`.
- These 20 files are commit-pinned. Their SHA-256 values are recorded after download; the recipe does not claim to compare them with prespecified per-file checksums. No Graph Attribution data or source tree is redistributed here.

## Software and verification boundary

The Windows/Python 3.12/CUDA 12.8 dependency set is specified in `requirements-primary-lock.txt`; its extra index is the official PyTorch CUDA-wheel index. See the base archive's `DATA_SOURCES.md` and `REPRODUCIBILITY.md` for its wider provenance and third-party terms. This addendum's execution route covers only the primary B-XAIC/Graph Attribution reconstruction, not Polaris, MoleculeACE, or pharmacophore retraining.

`prepare_primary.py --help` is a side-effect-free interface check. The other Python files are execution entrypoints, not general `--help` interfaces; running them can download data, create outputs, wait for workers, or train models. Syntax and manifest checks do not establish a successful scientific reconstruction. Read the actual completed comparison/finalization records for the execution verdict. Fresh stochastic weights are not historical checkpoint replay, and no bitwise fresh-weight match is promised. No remote publication, release tag, or archival DOI is claimed.

## Known legacy field caveat

In the separate base archive, `results/original_audits/reviewer_oracle_crc/paired_cells_all_alpha.csv` contains `recoverable_efficiency_grid`, which mixes nominal CRC/oracle fractions with the realized `random_fraction`. This field is preserved for lineage only: exclude it from valid nominal-efficiency estimates and scientific comparisons. The valid nominal-minus-nominal excess and separately stored realized fractions are not invalidated by this mixed-field defect.

The separate `results/original_audits/reviewer_oracle_crc/paired_cells_alpha010.csv` field `recoverable_efficiency` consistently uses realized atom fractions in all three terms. That field, not the mixed all-alpha diagnostic, supports the reported primary recovery-efficiency results. Neither the base archive nor the 17 frozen recipe files is changed by this caveat.
