import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--source-zip', type=Path, required=True)
parser.add_argument('--work-dir', type=Path, required=True)
args = parser.parse_args()
assert sys.version_info[:2] == (3, 12), 'Use Python3.12 for the frozen environment'
archive = args.source_zip.resolve()
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '032b3adc582fca31cfddc88ac853a4960b89b72addb70917ad0368a7c6b605a4'
target = args.work_dir.resolve()
target.mkdir(parents=True, exist_ok=False)
with zipfile.ZipFile(archive) as z:
    for member in z.namelist():
        assert (target / 'source' / member).resolve().is_relative_to(target / 'source')
    z.extractall(target / 'source')
recipe = Path(__file__).resolve().parent
for name in ['download_inputs.py', 'run_primary.py', 'run_subset_stream.py', 'run_downstream.py', 'compare_outputs.py', 'record_environment.py', 'run_data_oracle.py', 'partial_audit.py', 'interim_comparison.py', 'probe_determinism.py', 'finalize_when_ready.py', 'launch_pipeline.py', 'run_contract.json', 'requirements-primary-lock.txt']:
    shutil.copy2(recipe / name, target / name)
source = target / 'source/molxai-crc-anonymous-v3'
work = target / 'work'
shutil.copytree(source / 'src', work / 'src')
(work / 'scripts/reference').mkdir(parents=True)
for name in ['run_established_explainer_benchmark.py', 'analyze_established_explainers.py']:
    shutil.copy2(source / 'scripts/reference' / name, work / 'scripts/reference' / name)
subprocess.run([sys.executable, '-u', str(target / 'download_inputs.py')], check=True, cwd=target)
shutil.copytree(target / 'inputs/bxaic', work / 'data/raw/bxaic')
shutil.copytree(target / 'inputs/graph-attribution', work / 'reference/graph-attribution/data')
subprocess.run([sys.executable, '-m', 'venv', str(target / '.venv')], check=True)
print('Prepared fresh source, public inputs, and isolated empty virtual environment. Install the locked requirements, then run record_environment.py and launch_pipeline.py with that environment.')
