import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
started = time.time()
while not (ROOT / 'work/artifacts/experiment/gradient_grid_main/gradient_grid_manifest.json').exists() or not (ROOT / 'subset_stream_complete.json').exists():
    if time.time() - started > 21600:
        raise TimeoutError('Upstream fresh runs did not finish within six hours; inspect their logs')
    time.sleep(10)
for script in ['run_downstream.py', 'compare_outputs.py', 'partial_audit.py']:
    with (ROOT / f'{Path(script).stem}.log').open('w', encoding='utf-8') as stream:
        result = subprocess.run([sys.executable, '-u', str(ROOT / script)], stdout=stream, stderr=subprocess.STDOUT, cwd=ROOT)
    if result.returncode:
        (ROOT / 'finalization_status.json').write_text(json.dumps({'status': 'failed', 'step': script, 'returncode': result.returncode}), encoding='utf-8')
        raise SystemExit(result.returncode)
(ROOT / 'finalization_status.json').write_text(json.dumps({'status': 'complete', 'finished_unix': time.time(), 'comparison': 'comparison/comparison.json'}), encoding='utf-8')
