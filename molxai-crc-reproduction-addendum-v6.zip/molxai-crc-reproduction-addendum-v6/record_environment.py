import torch
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
SOURCE = ROOT / 'source/molxai-crc-anonymous-v3'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()
contract_dest = WORK / 'artifacts/contract/experiment_contract.md'
contract_dest.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(SOURCE / 'contracts/experiment_contract.md', contract_dest)
paths = list((WORK / 'src').glob('*.py')) + list((WORK / 'data/raw/bxaic').glob('*')) + list((WORK / 'reference/graph-attribution/data').rglob('*.*')) + [contract_dest]
hashes = {str(path.relative_to(WORK)).replace('\\', '/'): sha(path) for path in paths if path.is_file()}
deployment = {str(path.relative_to(WORK)).replace('\\', '/'): sha(path) == sha(SOURCE / path.relative_to(WORK)) for path in list((WORK / 'src').glob('*.py')) + list((WORK / 'scripts/reference').glob('*.py'))}
assert all(deployment.values())
input_map = {}
for row in json.loads((ROOT / 'input_manifest.json').read_text())['files']:
    source_path = Path(row['path'])
    target_path = WORK / ('data/raw/bxaic' if source_path.parts[1] == 'bxaic' else 'reference/graph-attribution/data') / Path(*source_path.parts[2:])
    input_map[str(target_path.relative_to(WORK)).replace('\\', '/')] = sha(target_path) == row['sha256']
assert len(input_map) == 22 and all(input_map.values())
run = WORK / 'artifacts/experiment/gradient_grid_main/run_contract.json'
run.parent.mkdir(parents=True, exist_ok=True)
run.write_text(json.dumps({'status': 'frozen_before_first_full_grid', 'expected_cells': 66, 'hashes': hashes, 'fresh_retraining': True, 'protocol': json.loads((ROOT / 'run_contract.json').read_text())}, indent=2), encoding='utf-8')
env = {'python': sys.version, 'executable': sys.executable, 'prefix': sys.prefix, 'base_prefix': sys.base_prefix, 'no_system_site_packages': 'include-system-site-packages = false' in (ROOT / '.venv/pyvenv.cfg').read_text(), 'platform': platform.platform(), 'torch': torch.__version__, 'cuda_runtime': torch.version.cuda, 'gpu': torch.cuda.get_device_name(), 'gpu_memory_bytes': torch.cuda.get_device_properties(0).total_memory, 'torch_threads': torch.get_num_threads(), 'core_versions': {k: importlib.metadata.version(k) for k in ['numpy', 'pandas', 'scipy', 'scikit-learn', 'torch-geometric', 'rdkit', 'matplotlib']}, 'public_source_byte_identity': deployment, 'installed_packages': subprocess.check_output([sys.executable, '-m', 'pip', 'freeze'], text=True).splitlines()}
env['fresh_download_to_execution_input_hash_match'] = input_map
(ROOT / 'environment.json').write_text(json.dumps(env, indent=2), encoding='utf-8')
