# Frozen primary reconstruction addendum

This is a local, publication-candidate technical addendum. It contains no article text, figures, raw molecular records, molecule IDs, per-molecule scores, model weights, account details, or local execution logs. No remote release or archival DOI is claimed.

## Input and boundary

Use the unchanged `molxai-crc-anonymous-v3.zip` archive, SHA256 `032b3adc582fca31cfddc88ac853a4960b89b72addb70917ad0368a7c6b605a4`. This archive is the frozen source identity of the executed reconstruction. Its public availability remains an author-controlled release step; this addendum does not invent a download URL. The preparer verifies the entire archive hash, materializes a fresh external tree, downloads22 checksum/revision-pinned public inputs, and creates a virtual environment without system-site packages.

Public source revisions and licenses are documented in the archive's `DATA_SOURCES.md`. The root MIT License applies only to repository-authored code and documentation, not to upstream datasets or third-party assets. All generated raw inputs, IDs, weights and scores stay in the external work directory.

## Windows/Python3.12/CUDA12.8 route

Choose a new, empty work-directory path outside the public release checkout. The full grid requires a compatible NVIDIA CUDA GPU. For example:

```text
python prepare_primary.py --source-zip molxai-crc-anonymous-v3.zip --work-dir ../molxai-clean
../molxai-clean/.venv/Scripts/python.exe -m pip install --no-cache-dir -r ../molxai-clean/requirements-primary-lock.txt
../molxai-clean/.venv/Scripts/python.exe ../molxai-clean/record_environment.py
../molxai-clean/.venv/Scripts/python.exe -m unittest discover -s ../molxai-clean/work/src -p test_*.py
../molxai-clean/.venv/Scripts/python.exe ../molxai-clean/probe_determinism.py
../molxai-clean/.venv/Scripts/python.exe ../molxai-clean/run_data_oracle.py
../molxai-clean/.venv/Scripts/python.exe ../molxai-clean/launch_pipeline.py
```

The CUDA-specific PyTorch wheel is explicitly pinned. Do not substitute the default Windows CPU-only wheel. The environment probe must report CUDA availability before training.

`launch_pipeline.py` runs the original66-cell training/full-grid explanations and two disjoint five-method follow-up workers, then waits for aggregation/comparison. A subset cell can only consume its newly trained checkpoint. All scientific source functions remain byte-identical to the frozen archive; the external directory structure supplies historical path compatibility. The original100epoch maximum, batch128, model seeds42/123/2026,20-step IG,101fractions and index-based tie policy remain unchanged. The matched subset retains100 rationale-bearing molecules per split, GNNExplainer100epochs and batch64.

## Outputs and interpretation

- `comparison/si_s24_retraining_comparison.csv`: seven rows comparing historical and fresh task-macro risk, retained fraction and IoU, cell-level retained-size drift, changed grid fractions and operational gate counts.
- `comparison/predictor_retraining_comparison.json`: historical/fresh predictor task-macro AUROC and maximum cell discrepancy.
- `comparison/conclusion_audit.json`: descriptive method-order and risk-size comparisons, without inferential p-values.
- `comparison/new_checkpoint_hashes.csv`: hashes of newly trained checkpoints only.
- `comparison/metric_differences.csv`: numeric differences for every shared numerical field in the selected aggregate surfaces.
- `partial_validation.json`: completed-cell uniqueness, source-code identity and fresh-checkpoint linkage checks while the run is active.

Training and follow-up workers overlap on one GPU. These wall times are concurrent and are not comparable with the paper's historical sequential costs. Source seeding does not enforce deterministic kernels. A separate-process runtime probe records defaults; it does not introspect or alter running processes. Fresh-training differences must not be attributed to GPU nondeterminism alone without a controlled test.

This route regenerates new weights and analyses; it does not replay the historical weights. Exact data/oracle agreement and numerical agreement of weight-dependent explanations are distinct tests. Historical manuscript estimates must not be silently overwritten by a new stochastic run. Final status must be read from the actual comparison and finalization files, not inferred from a successful installation or partial run.
