import csv
import hashlib
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
primary = [json.loads(p.read_text(encoding='utf-8')) for p in sorted((WORK / 'artifacts/experiment/gradient_grid_main/cells').glob('*.json'))]
subset = [json.loads(p.read_text(encoding='utf-8')) for p in sorted((WORK / 'results/established_explainers/cells').glob('*.json'))]
expected_hash = hashlib.sha256((WORK / 'src/run_gradient_grid.py').read_bytes()).hexdigest().upper()
assert all(c['status'] == 'complete' and c['code_sha256'] == expected_hash for c in primary)
assert len({c['cell_id'] for c in primary}) == len(primary)
new_checkpoints = {c['cell_id']: hashlib.sha256(Path(c['checkpoint']).read_bytes()).hexdigest().upper() for c in primary}
assert all(c['checkpoint_sha256'] == new_checkpoints[c['cell_id']] for c in subset)
summary = {'status': 'RUNNING' if len(primary) < 66 or len(subset) < 66 else 'execution_complete_pending_final_comparison', 'updated_unix': time.time(), 'primary_complete': len(primary), 'primary_expected': 66, 'subset_complete': len(subset), 'subset_expected': 66, 'primary_unique': True, 'primary_code_hash_match': True, 'subset_new_checkpoint_hash_match': True, 'current_primary_predictor_competence_pass': sum(c['predictor_competence_pass'] for c in primary), 'completed_primary_cells': [c['cell_id'] for c in primary], 'completed_subset_cells': [c['cell_id'] for c in subset], 'runtime': 'training and subset overlap; do not compare these wall times to historical sequential benchmark'}
(ROOT / 'partial_validation.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in summary.items() if not k.startswith('completed_')}, indent=2))
