import torch
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'work/src'))
import run_gradient_grid
result = {'observation_scope': 'Separate process in the same isolated environment after importing the exact training module; not an inspection or modification of running processes', 'torch_version': torch.__version__, 'cuda_runtime': torch.version.cuda, 'deterministic_algorithms_enabled': torch.are_deterministic_algorithms_enabled(), 'cudnn_deterministic': torch.backends.cudnn.deterministic, 'cudnn_benchmark': torch.backends.cudnn.benchmark, 'cuda_matmul_allow_tf32': torch.backends.cuda.matmul.allow_tf32, 'cudnn_allow_tf32': torch.backends.cudnn.allow_tf32, 'float32_matmul_precision': torch.get_float32_matmul_precision(), 'source_rule': 'Public set_seed sets Python, NumPy, torch and CUDA random seeds; no deterministic-algorithm enforcement is added by the execution wrappers', 'causal_attribution': 'This does not prove that GPU nondeterminism alone caused the observed historical-versus-fresh differences.'}
(ROOT / 'determinism_probe.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps(result, indent=2))
