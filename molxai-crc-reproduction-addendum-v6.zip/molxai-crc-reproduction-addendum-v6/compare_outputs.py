import torch
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
NEW = ROOT / 'work/results'
REF = ROOT / 'source/molxai-crc-anonymous-v3/results'
OUT = ROOT / 'comparison'
OUT.mkdir(exist_ok=True)
assert json.loads((ROOT / 'execution_complete.json').read_text())['primary_cells'] == 66

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

pairs = [
    ('gradient_grid_phase_a/cell_alpha010.csv', 'original_audits/gradient_grid_phase_a/cell_alpha010.csv', ['cell_id', 'explainer']),
    ('gradient_grid_phase_a/cell_all_alpha.csv', 'original_audits/gradient_grid_phase_a/cell_all_alpha.csv', ['cell_id', 'explainer', 'alpha']),
    ('gradient_grid_phase_a/task_alpha010.csv', 'original_audits/gradient_grid_phase_a/task_alpha010.csv', ['family', 'task', 'explainer']),
    ('reviewer_oracle_crc/task_oracle_all_alpha.csv', 'original_audits/reviewer_oracle_crc/task_oracle_all_alpha.csv', ['family', 'task', 'alpha']),
    ('reviewer_oracle_crc/paired_cells_alpha010.csv', 'original_audits/reviewer_oracle_crc/paired_cells_alpha010.csv', ['cell_id', 'explainer']),
    ('established_explainers/cells.csv', 'established_explainers/cells.csv', ['cell_id', 'method']),
    ('fixed_budget/cell_results.csv', 'v4/fixed_budget/cell_results.csv', ['surface', 'cell_id', 'method', 'policy']),
    ('fixed_budget/task_macro_results.csv', 'v4/fixed_budget/task_macro_results.csv', ['surface', 'family', 'task', 'method', 'policy']),
    ('fixed_budget/method_summary.csv', 'v4/fixed_budget/method_summary.csv', ['surface', 'method', 'policy']),
]
files, differences = [], []
for current, historical, keys in pairs:
    a, b = pd.read_csv(NEW / current), pd.read_csv(REF / historical)
    assert not a.duplicated(keys).any() and not b.duplicated(keys).any()
    merged = a.merge(b, on=keys, suffixes=('_new', '_reference'), how='outer', indicator=True, validate='one_to_one')
    assert merged['_merge'].eq('both').all(), current
    numeric = [c for c in a.columns.intersection(b.columns) if c not in keys and pd.api.types.is_numeric_dtype(a[c]) and not pd.api.types.is_bool_dtype(a[c])]
    for column in numeric:
        x = merged[f'{column}_new'].to_numpy(dtype=float)
        y = merged[f'{column}_reference'].to_numpy(dtype=float)
        assert np.array_equal(np.isnan(x), np.isnan(y)), (current, column)
        valid = np.isfinite(x) & np.isfinite(y)
        delta = x[valid] - y[valid]
        differences.append({'file': current, 'metric': column, 'n': int(valid.sum()), 'max_abs_delta': float(np.abs(delta).max()) if len(delta) else None, 'mean_signed_delta': float(delta.mean()) if len(delta) else None, 'rmse_delta': float(np.sqrt(np.mean(delta ** 2))) if len(delta) else None, 'within_1e_12': int((np.abs(delta) <= 1e-12).sum()), 'equal_3decimals': int((np.round(x[valid], 3) == np.round(y[valid], 3)).sum())})
    merged.to_csv(OUT / (Path(current).parent.name + '__' + Path(current).stem + '__paired.csv'), index=False)
    files.append({'file': current, 'historical': historical, 'rows': len(a), 'key_match': True, 'new_sha256': sha(NEW / current), 'historical_sha256': sha(REF / historical), 'byte_identical': sha(NEW / current) == sha(REF / historical)})
pd.DataFrame(differences).to_csv(OUT / 'metric_differences.csv', index=False)
checkpoints = ROOT / 'work/artifacts/experiment/gradient_grid_main/checkpoints'
checkpoint_hashes = [{'cell_id': p.stem, 'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(checkpoints.glob('*.pt'))]
assert len(checkpoint_hashes) == 66
pd.DataFrame(checkpoint_hashes).to_csv(OUT / 'new_checkpoint_hashes.csv', index=False)
primary = pd.read_csv(NEW / 'gradient_grid_phase_a/cell_alpha010.csv')
subset = pd.read_csv(NEW / 'established_explainers/cells.csv')
macro_rows = []
for label, frame, method, metrics in [('primary', primary, 'explainer', ['test_auroc', 'test_risk', 'mean_atom_fraction', 'iou']), ('subset', subset, 'method', ['risk', 'atom_fraction', 'iou'])]:
    for name, group in frame.groupby(method):
        means = group.groupby(['family', 'task'])[metrics].mean()
        macro_rows.append({'surface': label, 'method': name, **means.mean().to_dict(), 'cells': len(group)})
pd.DataFrame(macro_rows).to_csv(OUT / 'fresh_task_macro_summary.csv', index=False)
si_rows = []
for label, current, historical, method, metrics, fraction in [
    ('primary_full_grid', primary, pd.read_csv(REF / 'original_audits/gradient_grid_phase_a/cell_alpha010.csv'), 'explainer', ['test_risk', 'mean_atom_fraction', 'iou'], 'fraction_grid'),
    ('retrospective_matched_subset', subset, pd.read_csv(REF / 'established_explainers/cells.csv'), 'method', ['risk', 'atom_fraction', 'iou'], 'selected_grid_fraction')
]:
    for name, group in current.groupby(method):
        old = historical[historical[method] == name]
        paired = group.merge(old, on=['cell_id', 'family', 'task'], suffixes=('_fresh', '_original'), validate='one_to_one')
        record = {'surface': label, 'method': name, 'cells': len(group), 'tasks': group[['family', 'task']].drop_duplicates().shape[0]}
        for column, canonical in zip(metrics, ['risk', 'retained_fraction', 'iou']):
            record[f'original_task_macro_{canonical}'] = float(old.groupby(['family', 'task'])[column].mean().mean())
            record[f'fresh_task_macro_{canonical}'] = float(group.groupby(['family', 'task'])[column].mean().mean())
        retained = metrics[1]
        record['max_abs_cell_retained_delta'] = float(abs(paired[f'{retained}_fresh'] - paired[f'{retained}_original']).max())
        record['grid_fraction_changed_cells'] = int((abs(paired[f'{fraction}_fresh'] - paired[f'{fraction}_original']) > 1e-12).sum())
        for version, frame in [('original', old), ('fresh', group)]:
            risk_pass = frame[metrics[0]] <= 0.10
            size_pass = frame[retained] < 0.80
            record[f'{version}_risk_pass_cells'] = int(risk_pass.sum())
            record[f'{version}_size_pass_cells'] = int(size_pass.sum())
            record[f'{version}_joint_pass_cells'] = int((risk_pass & size_pass).sum())
        si_rows.append(record)
pd.DataFrame(si_rows).to_csv(OUT / 'si_s24_retraining_comparison.csv', index=False)
old_primary = pd.read_csv(REF / 'original_audits/gradient_grid_phase_a/cell_alpha010.csv')
predictors = primary.drop_duplicates('cell_id').merge(old_primary.drop_duplicates('cell_id'), on=['cell_id', 'family', 'task'], suffixes=('_fresh', '_original'), validate='one_to_one')
predictor_summary = {'cells': len(predictors), 'fresh_task_macro_auroc': float(predictors.groupby(['family', 'task']).test_auroc_fresh.mean().mean()), 'original_task_macro_auroc': float(predictors.groupby(['family', 'task']).test_auroc_original.mean().mean()), 'max_abs_cell_auroc_delta': float(abs(predictors.test_auroc_fresh - predictors.test_auroc_original).max()), 'fresh_competence_pass_cells': int((predictors.test_auroc_fresh > 0.65).sum()), 'original_competence_pass_cells': int((predictors.test_auroc_original > 0.65).sum())}
(OUT / 'predictor_retraining_comparison.json').write_text(json.dumps(predictor_summary, indent=2), encoding='utf-8')
fresh_fixed, original_fixed = pd.read_csv(NEW / 'fixed_budget/method_summary.csv'), pd.read_csv(REF / 'v4/fixed_budget/method_summary.csv')
order_checks = []
for (surface, policy), group in fresh_fixed.groupby(['surface', 'policy']):
    old = original_fixed[(original_fixed.surface == surface) & (original_fixed.policy == policy)]
    metric = 'task_macro_retained_fraction' if policy == 'calibrated_alpha_0.10' else 'task_macro_iou'
    ascending = policy == 'calibrated_alpha_0.10'
    new_order = group.sort_values([metric, 'method'], ascending=[ascending, True]).method.tolist()
    old_order = old.sort_values([metric, 'method'], ascending=[ascending, True]).method.tolist()
    order_checks.append({'surface': surface, 'policy': policy, 'ranking_metric': metric, 'fresh_order': new_order, 'original_order': old_order, 'same_order': new_order == old_order})
tradeoffs = []
for method, group in fresh_fixed[fresh_fixed.surface == 'primary_full_grid'].groupby('method'):
    indexed = group.set_index('policy')
    for policy in ['fixed_20', 'fixed_50']:
        tradeoffs.append({'method': method, 'reference_policy': policy, 'crc_minus_fixed_macro_risk': float(indexed.loc['calibrated_alpha_0.10', 'task_macro_risk'] - indexed.loc[policy, 'task_macro_risk']), 'crc_minus_fixed_macro_retained_fraction': float(indexed.loc['calibrated_alpha_0.10', 'task_macro_retained_fraction'] - indexed.loc[policy, 'task_macro_retained_fraction'])})
(OUT / 'conclusion_audit.json').write_text(json.dumps({'method_order_checks': order_checks, 'fresh_primary_risk_size_tradeoffs': tradeoffs, 'gates': si_rows, 'interpretation': 'Descriptive finite-grid fresh-retraining sensitivity only; no inferential p-values and no causal attribution of drift to a single runtime setting.'}, indent=2), encoding='utf-8')
oracle = next(x for x in files if x['file'] == 'reviewer_oracle_crc/task_oracle_all_alpha.csv')
summary = {'status': 'executed_comparison_complete', 'classification': 'fresh_stochastic_retraining_comparison', 'files': files, 'primary_cells': int(primary.cell_id.nunique()), 'primary_rows': len(primary), 'subset_cells': int(subset.cell_id.nunique()), 'subset_rows': len(subset), 'oracle_data_only_numeric_match': all(x['max_abs_delta'] is None or x['max_abs_delta'] <= 1e-12 for x in differences if x['file'] == oracle['file']), 'new_checkpoints': len(checkpoint_hashes), 'checkpoint_byte_match_claim': False, 'interpretation': 'Public data and scientific code are frozen; fresh stochastic GPU model weights are not historical checkpoint replay. Quantitative differences are reported without replacing historical manuscript estimates.'}
(OUT / 'comparison.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
print(json.dumps(summary, indent=2))
