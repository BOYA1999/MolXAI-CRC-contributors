import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
assert sys.prefix != sys.base_prefix
assert (ROOT / 'environment.json').exists(), 'Run record_environment.py after installing dependencies'
jobs = [('run_primary.py', []), ('run_subset_stream.py', ['--worker', '0']), ('run_subset_stream.py', ['--worker', '1']), ('finalize_when_ready.py', [])]
processes = []
for number, (script, arguments) in enumerate(jobs):
    stream = (ROOT / f'pipeline_{number}_{Path(script).stem}.log').open('w', encoding='utf-8')
    process = subprocess.Popen([sys.executable, '-u', str(ROOT / script), *arguments], stdout=stream, stderr=subprocess.STDOUT, cwd=ROOT, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    processes.append((script, process, stream))
failed = []
for script, process, stream in processes:
    code = process.wait()
    stream.close()
    if code:
        failed.append({'script': script, 'returncode': code})
        for _, pending, _ in processes:
            if pending.poll() is None:
                pending.terminate()
        break
(ROOT / 'launcher_status.json').write_text(json.dumps({'status': 'failed' if failed else 'complete', 'failures': failed}, indent=2), encoding='utf-8')
raise SystemExit(bool(failed))
