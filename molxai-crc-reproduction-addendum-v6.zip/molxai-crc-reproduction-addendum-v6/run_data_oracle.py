import torch
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
sys.path.insert(0, str(WORK / 'src'))
import analyze_oracle_crc_baseline as oracle
rows = []
for family, tasks in [('bxaic', oracle.BXAIC_TASKS), ('google', oracle.GOOGLE_TASKS)]:
    for task in tasks:
        print(f'oracle_task={family}/{task}', flush=True)
        partitions = oracle.bxaic_partitions(WORK / 'data/raw/bxaic/data.csv', WORK / 'data/raw/bxaic/explanations.sdf', task) if family == 'bxaic' else oracle.google_partitions(WORK / 'reference/graph-attribution/data', task)
        table = oracle.oracle_loss_table(partitions['calibration'])
        for alpha in oracle.ALPHAS:
            crc = oracle.calibrate_crc(table, oracle.FRACTIONS, alpha)
            metrics = oracle.oracle_test_metrics(partitions['test'], crc['fraction'])
            rows.append({'family': family, 'task': task, 'alpha': alpha, 'oracle_fraction': crc['fraction'], 'oracle_calibration_risk': crc['empirical_risk'], 'oracle_corrected_risk': crc['corrected_risk'], 'oracle_n_calibration_rationale': crc['n_calibration'], **{f'oracle_{k}': v for k, v in metrics.items()}})
frame = oracle.pd.DataFrame(rows)
frame.to_csv(ROOT / 'fresh_data_oracle.csv', index=False)
reference = oracle.pd.read_csv(ROOT / 'source/molxai-crc-anonymous-v3/results/original_audits/reviewer_oracle_crc/task_oracle_all_alpha.csv')
keys = ['family', 'task', 'alpha']
a, b = frame.set_index(keys).sort_index(), reference.set_index(keys).sort_index()
assert a.index.equals(b.index) and a.columns.equals(b.columns)
difference = abs(a - b).to_numpy().max()
assert difference <= 1e-12
(ROOT / 'data_oracle_validation.json').write_text(json.dumps({'status': 'PASS', 'rows': len(frame), 'tasks': frame[['family', 'task']].drop_duplicates().shape[0], 'max_abs_delta': difference, 'data_only_oracle': True, 'weight_dependent_excess_comparison': 'pending'}, indent=2), encoding='utf-8')
print(f'oracle_numeric_PASS max_delta={difference}', flush=True)
